package com.proyectox.registry;

import com.proyectox.ProyectoX;
import com.proyectox.entity.MicroRocket;
import com.proyectox.entity.PlasmaBolt;
import com.proyectox.entity.RailTrail;
import com.proyectox.entity.Singularity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Entidades efímeras de las armas: ninguna se guarda en el mundo. */
public final class PXEntities {
    private PXEntities() {}

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, ProyectoX.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<PlasmaBolt>> PLASMA = ENTITIES.register("plasma",
            () -> EntityType.Builder.<PlasmaBolt>of(PlasmaBolt::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(6).updateInterval(1).noSave().fireImmune()
                    .build(ProyectoX.MODID + ":plasma"));

    public static final DeferredHolder<EntityType<?>, EntityType<MicroRocket>> MICROCOHETE = ENTITIES.register("microcohete",
            () -> EntityType.Builder.<MicroRocket>of(MicroRocket::new, MobCategory.MISC)
                    .sized(0.3F, 0.3F).clientTrackingRange(8).updateInterval(1).noSave().fireImmune()
                    .build(ProyectoX.MODID + ":microcohete"));

    public static final DeferredHolder<EntityType<?>, EntityType<Singularity>> SINGULARIDAD = ENTITIES.register("singularidad",
            () -> EntityType.Builder.<Singularity>of(Singularity::new, MobCategory.MISC)
                    .sized(0.5F, 0.5F).clientTrackingRange(8).updateInterval(1).noSave().fireImmune()
                    .build(ProyectoX.MODID + ":singularidad"));

    public static final DeferredHolder<EntityType<?>, EntityType<RailTrail>> ESTELA = ENTITIES.register("estela",
            () -> EntityType.Builder.<RailTrail>of(RailTrail::new, MobCategory.MISC)
                    .sized(0.1F, 0.1F).clientTrackingRange(10).updateInterval(40).noSave().fireImmune().noSummon()
                    .build(ProyectoX.MODID + ":estela"));
}
