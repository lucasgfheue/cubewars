package com.proyectox.registry;

import com.proyectox.ProyectoX;
import javax.annotation.Nullable;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

/** Tipos de daño propios (data/proyectox/damage_type) con sus mensajes de muerte. */
public final class PXDamage {
    private PXDamage() {}

    public static final ResourceKey<DamageType> IMPACTO = key("impacto");
    public static final ResourceKey<DamageType> RIEL = key("riel");
    public static final ResourceKey<DamageType> PLASMA = key("plasma");
    public static final ResourceKey<DamageType> PURGA = key("purga");
    public static final ResourceKey<DamageType> MICROCOHETE = key("microcohete");
    public static final ResourceKey<DamageType> COLAPSO = key("colapso");

    private static ResourceKey<DamageType> key(String name) {
        return ResourceKey.create(Registries.DAMAGE_TYPE, ProyectoX.id(name));
    }

    public static DamageSource source(Level level, ResourceKey<DamageType> type, @Nullable Entity direct, @Nullable Entity causing) {
        Holder<DamageType> holder = level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(type);
        return new DamageSource(holder, direct, causing);
    }
}
