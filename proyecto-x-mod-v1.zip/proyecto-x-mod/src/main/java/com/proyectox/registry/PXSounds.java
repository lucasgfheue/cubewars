package com.proyectox.registry;

import com.proyectox.ProyectoX;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Eventos de sonido propios. En assets/proyectox/sounds.json cada uno se compone a partir de
 * sonidos de Minecraft con su propio tono y volumen, así que pueden sustituirse por .ogg propios
 * sin tocar el código.
 */
public final class PXSounds {
    private PXSounds() {}

    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, ProyectoX.MODID);

    public static final DeferredHolder<SoundEvent, SoundEvent> VACIO = reg("arma.vacia");
    public static final DeferredHolder<SoundEvent, SoundEvent> LISTO = reg("arma.lista");

    public static final DeferredHolder<SoundEvent, SoundEvent> MARTINETE_PRESION = reg("martinete.presion");
    public static final DeferredHolder<SoundEvent, SoundEvent> MARTINETE_CARGA = reg("martinete.carga");
    public static final DeferredHolder<SoundEvent, SoundEvent> MARTINETE_RUPTURA = reg("martinete.ruptura");

    public static final DeferredHolder<SoundEvent, SoundEvent> AGUJA_CARGA = reg("aguja.carga");
    public static final DeferredHolder<SoundEvent, SoundEvent> AGUJA_DISPARO = reg("aguja.disparo");
    public static final DeferredHolder<SoundEvent, SoundEvent> AGUJA_RIEL = reg("aguja.riel");

    public static final DeferredHolder<SoundEvent, SoundEvent> AVISPON_DISPARO = reg("avispon.disparo");
    public static final DeferredHolder<SoundEvent, SoundEvent> AVISPON_IMPACTO = reg("avispon.impacto");
    public static final DeferredHolder<SoundEvent, SoundEvent> AVISPON_SOBRECALOR = reg("avispon.sobrecalor");
    public static final DeferredHolder<SoundEvent, SoundEvent> AVISPON_PURGA = reg("avispon.purga");

    public static final DeferredHolder<SoundEvent, SoundEvent> COLMENA_FIJAR = reg("colmena.fijar");
    public static final DeferredHolder<SoundEvent, SoundEvent> COLMENA_LANZAR = reg("colmena.lanzar");
    public static final DeferredHolder<SoundEvent, SoundEvent> COLMENA_EXPLOSION = reg("colmena.explosion");

    public static final DeferredHolder<SoundEvent, SoundEvent> VORTICE_DISPARO = reg("vortice.disparo");
    public static final DeferredHolder<SoundEvent, SoundEvent> VORTICE_ABRIR = reg("vortice.abrir");
    public static final DeferredHolder<SoundEvent, SoundEvent> VORTICE_COLAPSO = reg("vortice.colapso");
    public static final DeferredHolder<SoundEvent, SoundEvent> VORTICE_ANCLA = reg("vortice.ancla");

    public static final DeferredHolder<SoundEvent, SoundEvent> CIZALLA_TAJO = reg("cizalla.tajo");
    public static final DeferredHolder<SoundEvent, SoundEvent> CIZALLA_VIBRO = reg("cizalla.vibro");
    public static final DeferredHolder<SoundEvent, SoundEvent> TALADRO_CARGA = reg("taladro.carga");
    public static final DeferredHolder<SoundEvent, SoundEvent> TALADRO_EMBESTIDA = reg("taladro.embestida");
    public static final DeferredHolder<SoundEvent, SoundEvent> SERPENTINA_LATIGO = reg("serpentina.latigo");
    public static final DeferredHolder<SoundEvent, SoundEvent> SERPENTINA_ARCO = reg("serpentina.arco");
    public static final DeferredHolder<SoundEvent, SoundEvent> CHISPA_DISPARO = reg("chispa.disparo");
    public static final DeferredHolder<SoundEvent, SoundEvent> REMACHE_DISPARO = reg("remache.disparo");
    public static final DeferredHolder<SoundEvent, SoundEvent> TRITURADORA_LANZAR = reg("trituradora.lanzar");
    public static final DeferredHolder<SoundEvent, SoundEvent> TRITURADORA_REBOTE = reg("trituradora.rebote");
    public static final DeferredHolder<SoundEvent, SoundEvent> TRITURADORA_EXPLOSION = reg("trituradora.explosion");
    public static final DeferredHolder<SoundEvent, SoundEvent> ROTOR_GIRO = reg("rotor.giro");
    public static final DeferredHolder<SoundEvent, SoundEvent> ROTOR_DISPARO = reg("rotor.disparo");
    public static final DeferredHolder<SoundEvent, SoundEvent> HALCON_DESPLIEGUE = reg("halcon.despliegue");
    public static final DeferredHolder<SoundEvent, SoundEvent> HALCON_DISPARO = reg("halcon.disparo");
    public static final DeferredHolder<SoundEvent, SoundEvent> HALCON_RETIRADA = reg("halcon.retirada");
    public static final DeferredHolder<SoundEvent, SoundEvent> TRUENO_MARCAR = reg("trueno.marcar");
    public static final DeferredHolder<SoundEvent, SoundEvent> TRUENO_IMPACTO = reg("trueno.impacto");
    public static final DeferredHolder<SoundEvent, SoundEvent> TRUENO_BENGALA = reg("trueno.bengala");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOPLETE_CHORRO = reg("soplete.chorro");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOPLETE_NAPALM = reg("soplete.napalm");
    public static final DeferredHolder<SoundEvent, SoundEvent> ESCARCHA_RAYO = reg("escarcha.rayo");
    public static final DeferredHolder<SoundEvent, SoundEvent> ESCARCHA_CONGELAR = reg("escarcha.congelar");
    public static final DeferredHolder<SoundEvent, SoundEvent> ESCARCHA_NOVA = reg("escarcha.nova");
    public static final DeferredHolder<SoundEvent, SoundEvent> ECO_CARGA = reg("eco.carga");
    public static final DeferredHolder<SoundEvent, SoundEvent> ECO_ONDA = reg("eco.onda");
    public static final DeferredHolder<SoundEvent, SoundEvent> BASTION_PULSO = reg("bastion.pulso");
    public static final DeferredHolder<SoundEvent, SoundEvent> COLIBRI_DISPARO = reg("colibri.disparo");
    public static final DeferredHolder<SoundEvent, SoundEvent> SIERRA_LANZAR = reg("sierra.lanzar");
    public static final DeferredHolder<SoundEvent, SoundEvent> SIERRA_REBOTE = reg("sierra.rebote");
    public static final DeferredHolder<SoundEvent, SoundEvent> SIERRA_CORTE = reg("sierra.corte");

    private static DeferredHolder<SoundEvent, SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(ProyectoX.id(name)));
    }
}
