package com.proyectox.registry;

import com.proyectox.ProyectoX;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Eventos de sonido propios. En assets/proyectox/sounds.json cada uno se compone a partir de
 * sonidos de Minecraft con su propio tono y volumen, así que pueden sustituirse por .ogg propios
 * sin tocar el código.
 */
public final class PXSounds {
    private PXSounds() {}

    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, ProyectoX.MODID);

    public static final DeferredHolder<SoundEvent, SoundEvent> VACIO = reg("arma.vacia");
    public static final DeferredHolder<SoundEvent, SoundEvent> LISTO = reg("arma.lista");

    public static final DeferredHolder<SoundEvent, SoundEvent> MARTINETE_PRESION = reg("martinete.presion");
    public static final DeferredHolder<SoundEvent, SoundEvent> MARTINETE_CARGA = reg("martinete.carga");
    public static final DeferredHolder<SoundEvent, SoundEvent> MARTINETE_RUPTURA = reg("martinete.ruptura");

    public static final DeferredHolder<SoundEvent, SoundEvent> AGUJA_CARGA = reg("aguja.carga");
    public static final DeferredHolder<SoundEvent, SoundEvent> AGUJA_DISPARO = reg("aguja.disparo");
    public static final DeferredHolder<SoundEvent, SoundEvent> AGUJA_RIEL = reg("aguja.riel");

    public static final DeferredHolder<SoundEvent, SoundEvent> AVISPON_DISPARO = reg("avispon.disparo");
    public static final DeferredHolder<SoundEvent, SoundEvent> AVISPON_IMPACTO = reg("avispon.impacto");
    public static final DeferredHolder<SoundEvent, SoundEvent> AVISPON_SOBRECALOR = reg("avispon.sobrecalor");
    public static final DeferredHolder<SoundEvent, SoundEvent> AVISPON_PURGA = reg("avispon.purga");

    public static final DeferredHolder<SoundEvent, SoundEvent> COLMENA_FIJAR = reg("colmena.fijar");
    public static final DeferredHolder<SoundEvent, SoundEvent> COLMENA_LANZAR = reg("colmena.lanzar");
    public static final DeferredHolder<SoundEvent, SoundEvent> COLMENA_EXPLOSION = reg("colmena.explosion");

    public static final DeferredHolder<SoundEvent, SoundEvent> VORTICE_DISPARO = reg("vortice.disparo");
    public static final DeferredHolder<SoundEvent, SoundEvent> VORTICE_ABRIR = reg("vortice.abrir");
    public static final DeferredHolder<SoundEvent, SoundEvent> VORTICE_COLAPSO = reg("vortice.colapso");
    public static final DeferredHolder<SoundEvent, SoundEvent> VORTICE_ANCLA = reg("vortice.ancla");

    private static DeferredHolder<SoundEvent, SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(ProyectoX.id(name)));
    }
}
