package com.proyectox.registry;

import com.proyectox.ProyectoX;
import com.proyectox.item.AgujaItem;
import com.proyectox.item.ArponItem;
import com.proyectox.item.AvisponItem;
import com.proyectox.item.BastionItem;
import com.proyectox.item.CausticaItem;
import com.proyectox.item.CenizaItem;
import com.proyectox.item.CentellaItem;
import com.proyectox.item.ChispaItem;
import com.proyectox.item.CiclonItem;
import com.proyectox.item.CizallaItem;
import com.proyectox.item.ColibriItem;
import com.proyectox.item.ColmenaItem;
import com.proyectox.item.EcoItem;
import com.proyectox.item.EnjambreItem;
import com.proyectox.item.EscarchaItem;
import com.proyectox.item.EsquirlaItem;
import com.proyectox.item.GuadanaItem;
import com.proyectox.item.HalconItem;
import com.proyectox.item.MartineteItem;
import com.proyectox.item.MeleeItem;
import com.proyectox.item.MinadorItem;
import com.proyectox.item.MorteroItem;
import com.proyectox.item.PXWeapon;
import com.proyectox.item.PicaItem;
import com.proyectox.item.PrismaItem;
import com.proyectox.item.RemacheItem;
import com.proyectox.item.RotorItem;
import com.proyectox.item.SaetaItem;
import com.proyectox.item.SerpentinaItem;
import com.proyectox.item.SierraItem;
import com.proyectox.item.SolarItem;
import com.proyectox.item.SopleteItem;
import com.proyectox.item.TaladroItem;
import com.proyectox.item.TempestadItem;
import com.proyectox.item.TrituradoraItem;
import com.proyectox.item.TruenoItem;
import com.proyectox.item.VorticeItem;
import com.proyectox.item.XeranioCoreItem;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class PXItems {
    private PXItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ProyectoX.MODID);

    /** Componente de fabricación: el cristal energético que alimenta todo el arsenal. */
    public static final DeferredItem<XeranioCoreItem> NUCLEO_XERANIO = ITEMS.register("nucleo_xeranio",
            () -> new XeranioCoreItem(new Item.Properties().stacksTo(16).rarity(Rarity.RARE).fireResistant()));

    public static final DeferredItem<MartineteItem> MARTINETE = ITEMS.register("martinete",
            () -> new MartineteItem(MeleeItem.meleeProperties(2400).attributes(MeleeItem.attributes(32.0, 0.9, 0.0))));

    public static final DeferredItem<AgujaItem> AGUJA = ITEMS.register("aguja",
            () -> new AgujaItem(PXWeapon.baseProperties()));

    public static final DeferredItem<AvisponItem> AVISPON = ITEMS.register("avispon",
            () -> new AvisponItem(PXWeapon.baseProperties()));

    public static final DeferredItem<ColmenaItem> COLMENA = ITEMS.register("colmena",
            () -> new ColmenaItem(PXWeapon.baseProperties()));

    public static final DeferredItem<VorticeItem> VORTICE = ITEMS.register("vortice",
            () -> new VorticeItem(PXWeapon.baseProperties()));

    public static final DeferredItem<CizallaItem> CIZALLA = ITEMS.register("cizalla",
            () -> new CizallaItem(MeleeItem.meleeProperties(2000).attributes(MeleeItem.attributes(22.0, 1.8, 0.0))));

    public static final DeferredItem<TaladroItem> TALADRO = ITEMS.register("taladro",
            () -> new TaladroItem(MeleeItem.meleeProperties(3000).attributes(TaladroItem.attributes())
                    .component(DataComponents.TOOL, TaladroItem.tool())));

    public static final DeferredItem<SerpentinaItem> SERPENTINA = ITEMS.register("serpentina",
            () -> new SerpentinaItem(MeleeItem.meleeProperties(2000).attributes(MeleeItem.attributes(6.0, 1.6, 3.0))));

    public static final DeferredItem<ChispaItem> CHISPA = ITEMS.register("chispa",
            () -> new ChispaItem(PXWeapon.baseProperties()));

    public static final DeferredItem<RemacheItem> REMACHE = ITEMS.register("remache",
            () -> new RemacheItem(PXWeapon.baseProperties()));

    public static final DeferredItem<TrituradoraItem> TRITURADORA = ITEMS.register("trituradora",
            () -> new TrituradoraItem(PXWeapon.baseProperties()));

    public static final DeferredItem<RotorItem> ROTOR = ITEMS.register("rotor",
            () -> new RotorItem(PXWeapon.baseProperties()));

    public static final DeferredItem<HalconItem> HALCON = ITEMS.register("halcon",
            () -> new HalconItem(PXWeapon.baseProperties()));

    public static final DeferredItem<TruenoItem> TRUENO = ITEMS.register("trueno",
            () -> new TruenoItem(PXWeapon.baseProperties()));

    public static final DeferredItem<SopleteItem> SOPLETE = ITEMS.register("soplete",
            () -> new SopleteItem(PXWeapon.baseProperties()));

    public static final DeferredItem<EscarchaItem> ESCARCHA = ITEMS.register("escarcha",
            () -> new EscarchaItem(PXWeapon.baseProperties()));

    public static final DeferredItem<EcoItem> ECO = ITEMS.register("eco",
            () -> new EcoItem(PXWeapon.baseProperties()));

    public static final DeferredItem<BastionItem> BASTION = ITEMS.register("bastion",
            () -> new BastionItem(PXWeapon.baseProperties()));

    public static final DeferredItem<ColibriItem> COLIBRI = ITEMS.register("colibri",
            () -> new ColibriItem(PXWeapon.baseProperties()));

    public static final DeferredItem<SierraItem> SIERRA = ITEMS.register("sierra",
            () -> new SierraItem(PXWeapon.baseProperties()));

    // ------------------------------------------------------------------ serie PX-2x / PX-3x (v4)

    public static final DeferredItem<CentellaItem> CENTELLA = ITEMS.register("centella",
            () -> new CentellaItem(PXWeapon.baseProperties()));

    public static final DeferredItem<ArponItem> ARPON = ITEMS.register("arpon",
            () -> new ArponItem(PXWeapon.baseProperties()));

    public static final DeferredItem<MorteroItem> MORTERO = ITEMS.register("mortero",
            () -> new MorteroItem(PXWeapon.baseProperties()));

    public static final DeferredItem<PrismaItem> PRISMA = ITEMS.register("prisma",
            () -> new PrismaItem(PXWeapon.baseProperties()));

    public static final DeferredItem<EnjambreItem> ENJAMBRE = ITEMS.register("enjambre",
            () -> new EnjambreItem(PXWeapon.baseProperties()));

    public static final DeferredItem<CausticaItem> CAUSTICA = ITEMS.register("caustica",
            () -> new CausticaItem(PXWeapon.baseProperties()));

    public static final DeferredItem<SolarItem> SOLAR = ITEMS.register("solar",
            () -> new SolarItem(PXWeapon.baseProperties()));

    public static final DeferredItem<TempestadItem> TEMPESTAD = ITEMS.register("tempestad",
            () -> new TempestadItem(PXWeapon.baseProperties()));

    public static final DeferredItem<EsquirlaItem> ESQUIRLA = ITEMS.register("esquirla",
            () -> new EsquirlaItem(PXWeapon.baseProperties()));

    public static final DeferredItem<CiclonItem> CICLON = ITEMS.register("ciclon",
            () -> new CiclonItem(PXWeapon.baseProperties()));

    public static final DeferredItem<MinadorItem> MINADOR = ITEMS.register("minador",
            () -> new MinadorItem(PXWeapon.baseProperties()));

    public static final DeferredItem<CenizaItem> CENIZA = ITEMS.register("ceniza",
            () -> new CenizaItem(PXWeapon.baseProperties()));

    public static final DeferredItem<SaetaItem> SAETA = ITEMS.register("saeta",
            () -> new SaetaItem(PXWeapon.baseProperties()));

    public static final DeferredItem<GuadanaItem> GUADANA = ITEMS.register("guadana",
            () -> new GuadanaItem(MeleeItem.meleeProperties(2500).attributes(GuadanaItem.attributes())));

    public static final DeferredItem<PicaItem> PICA = ITEMS.register("pica",
            () -> new PicaItem(MeleeItem.meleeProperties(2500).attributes(PicaItem.attributes())));
}
