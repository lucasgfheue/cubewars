package com.proyectox.registry;

import com.proyectox.ProyectoX;
import com.proyectox.item.AgujaItem;
import com.proyectox.item.AvisponItem;
import com.proyectox.item.ColmenaItem;
import com.proyectox.item.MartineteItem;
import com.proyectox.item.PXWeapon;
import com.proyectox.item.VorticeItem;
import com.proyectox.item.XeranioCoreItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class PXItems {
    private PXItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ProyectoX.MODID);

    /** Componente de fabricación: el cristal energético que alimenta todo el arsenal. */
    public static final DeferredItem<XeranioCoreItem> NUCLEO_XERANIO = ITEMS.register("nucleo_xeranio",
            () -> new XeranioCoreItem(new Item.Properties().stacksTo(16).rarity(Rarity.RARE).fireResistant()));

    public static final DeferredItem<MartineteItem> MARTINETE = ITEMS.register("martinete",
            () -> new MartineteItem(PXWeapon.baseProperties().durability(2400).attributes(MartineteItem.attributes())));

    public static final DeferredItem<AgujaItem> AGUJA = ITEMS.register("aguja",
            () -> new AgujaItem(PXWeapon.baseProperties().stacksTo(1)));

    public static final DeferredItem<AvisponItem> AVISPON = ITEMS.register("avispon",
            () -> new AvisponItem(PXWeapon.baseProperties().stacksTo(1)));

    public static final DeferredItem<ColmenaItem> COLMENA = ITEMS.register("colmena",
            () -> new ColmenaItem(PXWeapon.baseProperties().stacksTo(1).attributes(ColmenaItem.attributes())));

    public static final DeferredItem<VorticeItem> VORTICE = ITEMS.register("vortice",
            () -> new VorticeItem(PXWeapon.baseProperties().stacksTo(1)));
}
