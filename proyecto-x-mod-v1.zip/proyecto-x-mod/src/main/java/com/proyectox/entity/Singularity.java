package com.proyectox.entity;

import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXEntities;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Singularidad del VÓRTICE. Vuela despacio; al impactar (o tras 2,5 s) abre un vórtice de 3 s
 * que atrae a todas las criaturas en radio 6 —también al usuario— y después colapsa:
 * 8 de daño en radio 3 y levitación.
 */
public class Singularity extends ThrowableProjectile {
    private static final EntityDataAccessor<Boolean> OPEN = SynchedEntityData.defineId(Singularity.class, EntityDataSerializers.BOOLEAN);
    public static final int FLIGHT_TICKS = 50;
    public static final int VORTEX_TICKS = 60;
    public static final double PULL_RADIUS = 6.0;
    public static final double COLLAPSE_RADIUS = 3.0;

    private int openTicks;

    public Singularity(EntityType<? extends Singularity> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public static Singularity create(ServerLevel level, LivingEntity owner, Vec3 pos, Vec3 velocity) {
        Singularity s = new Singularity(PXEntities.SINGULARIDAD.get(), level);
        s.setOwner(owner);
        s.setPos(pos.x, pos.y, pos.z);
        s.setDeltaMovement(velocity);
        ProjectileAim.face(s, velocity);
        return s;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(OPEN, false);
    }

    public boolean isOpen() {
        return this.entityData.get(OPEN);
    }

    /** Ticks desde que se abrió el vórtice (el cliente lleva su propia cuenta para animar). */
    public int openTicks() {
        return this.openTicks;
    }

    @Override
    public void tick() {
        if (isOpen()) {
            this.baseTick();
            this.setDeltaMovement(Vec3.ZERO);
            this.openTicks++;
            if (this.level() instanceof ServerLevel level) {
                vortex(level);
                if (this.openTicks >= VORTEX_TICKS) collapse(level);
            } else {
                swirl();
            }
            return;
        }
        super.tick();
        if (this.level().isClientSide) {
            this.level().addParticle(ParticleTypes.REVERSE_PORTAL, this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
        } else if (this.tickCount >= FLIGHT_TICKS) {
            open(this.position());
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity e = result.getEntity();
        if (!this.level().isClientSide) open(e.getBoundingBox().getCenter());
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!this.level().isClientSide) {
            // se separa un poco de la cara golpeada para no quedar dentro del bloque
            Vec3 n = Vec3.atLowerCornerOf(result.getDirection().getNormal());
            open(result.getLocation().add(n.scale(0.6)));
        }
    }

    @Override
    protected void onHit(HitResult result) {
        if (isOpen()) return;
        super.onHit(result);
    }

    private void open(Vec3 at) {
        if (isOpen()) return;
        this.setPos(at.x, at.y, at.z);
        this.setDeltaMovement(Vec3.ZERO);
        this.noPhysics = true;
        this.entityData.set(OPEN, true);
        this.openTicks = 0;
        FX.sound(this.level(), at, PXSounds.VORTICE_ABRIR.get(), 1.2F, 0.8F);
    }

    private void vortex(ServerLevel level) {
        Vec3 c = this.position();
        AABB box = new AABB(c, c).inflate(PULL_RADIUS);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> x.isAlive() && !x.isSpectator())) {
            if (e instanceof Player p && (p.isCreative() || p.getAbilities().flying)) continue;
            Vec3 to = c.subtract(e.position().add(0.0, e.getBbHeight() * 0.5, 0.0));
            double d = to.length();
            if (d > PULL_RADIUS || d < 0.5) continue;
            double strength = 0.075 + 0.07 * (1.0 - d / PULL_RADIUS);
            Vec3 pull = to.normalize().scale(strength);
            e.setDeltaMovement(e.getDeltaMovement().scale(0.88).add(pull));
            e.resetFallDistance();
            e.hurtMarked = true;
        }
        if (this.openTicks % 10 == 0) {
            FX.burst(level, ParticleTypes.PORTAL, c, 20, 1.5, 0.6);
        }
    }

    private void swirl() {
        Vec3 c = this.position();
        for (int i = 0; i < 6; i++) {
            double a = this.random.nextDouble() * Math.PI * 2.0;
            double r = 3.0 + this.random.nextDouble() * 3.0;
            double y = (this.random.nextDouble() - 0.5) * 3.0;
            // las partículas de portal viajan desde (pos + vel) hasta pos: convergen en el centro
            this.level().addParticle(ParticleTypes.PORTAL, c.x, c.y, c.z, Math.cos(a) * r, y, Math.sin(a) * r);
        }
        if (this.random.nextInt(3) == 0) {
            this.level().addParticle(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 0.0, 0.0, 0.0);
        }
    }

    private void collapse(ServerLevel level) {
        Vec3 c = this.position();
        Entity owner = this.getOwner();
        DamageSource source = PXDamage.source(level, PXDamage.COLAPSO, this, owner);
        for (LivingEntity e : Aim.sphere(level, this, c, COLLAPSE_RADIUS)) {
            if (e == owner) continue;
            e.invulnerableTime = 0;
            e.hurt(source, 8.0F);
            e.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 40, 0), owner);
        }
        FX.burst(level, ParticleTypes.REVERSE_PORTAL, c, 120, 0.6, 0.35);
        FX.burst(level, ParticleTypes.SONIC_BOOM, c, 1, 0.0, 0.0);
        FX.burst(level, FX.dust(0xAA5AFF, 2.0F), c, 30, 1.2, 0.1);
        FX.sound(level, c, PXSounds.VORTICE_COLAPSO.get(), 1.5F, 0.9F);
        this.discard();
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 128.0 * 128.0;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

}
