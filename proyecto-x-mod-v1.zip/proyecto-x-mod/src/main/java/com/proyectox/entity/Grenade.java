package com.proyectox.entity;

import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXEntities;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Proyectiles parabólicos: granada de racimo y bombetas (TRITURADORA) y globo de napalm (SOPLETE).
 * La granada rebota dos veces y estalla al tocar una criatura o al agotarse la espoleta.
 */
public class Grenade extends ThrowableProjectile {
    public static final int GRENADE = 0;
    public static final int BOMBLET = 1;
    public static final int NAPALM = 2;

    private static final EntityDataAccessor<Integer> KIND = SynchedEntityData.defineId(Grenade.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> BURNING = SynchedEntityData.defineId(Grenade.class, EntityDataSerializers.BOOLEAN);

    private int fuse = 40;
    private int bounces;
    private int burnTicks;

    public Grenade(EntityType<? extends Grenade> type, Level level) {
        super(type, level);
    }

    public static Grenade create(ServerLevel level, Entity owner, int kind, Vec3 pos, Vec3 velocity, int fuse) {
        Grenade g = new Grenade(PXEntities.GRANADA.get(), level);
        g.setOwner(owner);
        g.setPos(pos.x, pos.y, pos.z);
        g.setDeltaMovement(velocity);
        g.fuse = fuse;
        g.entityData.set(KIND, kind);
        ProjectileAim.face(g, velocity);
        return g;
    }

    public int kind() {
        return this.entityData.get(KIND);
    }

    public boolean burning() {
        return this.entityData.get(BURNING);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(KIND, GRENADE);
        builder.define(BURNING, false);
    }

    /** Detonación remota: hace estallar todas las granadas de un jugador en 64 bloques. */
    public static int detonateAll(ServerLevel level, Player owner) {
        List<Grenade> list = level.getEntitiesOfClass(Grenade.class, owner.getBoundingBox().inflate(64.0),
                g -> g.kind() == GRENADE && g.getOwner() == owner && g.isAlive());
        for (Grenade g : list) g.explode(null);
        return list.size();
    }

    @Override
    public void tick() {
        if (burning()) {
            this.baseTick();
            this.setDeltaMovement(Vec3.ZERO);
            if (this.level() instanceof ServerLevel level) {
                burnTicks++;
                if (burnTicks % 10 == 0) burnArea(level);
                if (burnTicks > 80) this.discard();
            } else {
                for (int i = 0; i < 3; i++) {
                    double a = this.random.nextDouble() * Math.PI * 2;
                    double r = this.random.nextDouble() * 2.4;
                    this.level().addParticle(i == 0 ? ParticleTypes.LARGE_SMOKE : ParticleTypes.FLAME,
                            this.getX() + Math.cos(a) * r, this.getY() + 0.1, this.getZ() + Math.sin(a) * r, 0.0, 0.04, 0.0);
                }
            }
            return;
        }
        super.tick();
        if (this.level().isClientSide) {
            this.level().addParticle(kind() == NAPALM ? ParticleTypes.FLAME : ParticleTypes.SMOKE, this.getX(), this.getY(), this.getZ(), 0.0, 0.01, 0.0);
        } else if (this.tickCount >= this.fuse) {
            if (kind() == NAPALM) ignite(this.position());
            else explode(null);
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (this.level().isClientSide) return;
        if (kind() == NAPALM) ignite(this.position());
        else explode(result.getEntity());
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (this.level().isClientSide) return;
        if (kind() == NAPALM) {
            ignite(result.getLocation());
            return;
        }
        if (kind() == GRENADE && bounces < 2) {
            // rebote amortiguado sobre la cara golpeada
            bounces++;
            Vec3 v = this.getDeltaMovement();
            Vec3 n = Vec3.atLowerCornerOf(result.getDirection().getNormal());
            Vec3 r = v.subtract(n.scale(2.0 * v.dot(n))).scale(0.45);
            this.setDeltaMovement(r);
            Vec3 p = result.getLocation().add(n.scale(0.15));
            this.setPos(p.x, p.y, p.z);
            FX.sound(this.level(), p, PXSounds.TRITURADORA_REBOTE.get(), 0.6F, 1.2F);
            return;
        }
        explode(null);
    }

    private void explode(Entity direct) {
        if (!(this.level() instanceof ServerLevel level) || !this.isAlive()) return;
        Vec3 p = this.position();
        boolean big = kind() == GRENADE;
        double radius = big ? 3.0 : 2.0;
        float dmg = big ? 7.0F : 3.0F;
        Entity owner = this.getOwner();
        DamageSource source = PXDamage.source(level, PXDamage.METRALLA, this, owner);
        for (LivingEntity e : Aim.sphere(level, this, p, radius)) {
            double d = e.getBoundingBox().getCenter().distanceTo(p);
            float f = (float) Math.max(0.35, 1.0 - d / (radius + 1.0));
            if (e == direct) f = 1.0F;
            e.invulnerableTime = 0;
            e.hurt(source, dmg * f);
            Vec3 push = e.position().subtract(p);
            push = push.lengthSqr() < 1.0E-4 ? new Vec3(0, 1, 0) : push.normalize();
            e.setDeltaMovement(e.getDeltaMovement().add(push.x * 0.5 * f, 0.3 * f, push.z * 0.5 * f));
            e.hurtMarked = true;
        }
        FX.burst(level, big ? ParticleTypes.EXPLOSION_EMITTER : ParticleTypes.EXPLOSION, p, 1, 0.0, 0.0);
        FX.burst(level, ParticleTypes.LARGE_SMOKE, p, big ? 10 : 4, radius * 0.3, 0.03);
        FX.burst(level, FX.dust(0xB7C34A, 1.4F), p, big ? 16 : 6, radius * 0.4, 0.05);
        FX.sound(level, p, PXSounds.TRITURADORA_EXPLOSION.get(), big ? 1.4F : 0.7F, big ? 0.9F : 1.4F);
        if (big) {
            // racimo: cuatro bombetas que estallan medio segundo después
            for (int i = 0; i < 4; i++) {
                double a = Math.PI / 2 * i + this.random.nextDouble() * 0.6;
                Vec3 v = new Vec3(Math.cos(a) * 0.32, 0.42, Math.sin(a) * 0.32);
                level.addFreshEntity(create(level, owner == null ? this : owner, BOMBLET, p.add(0, 0.3, 0), v, 12 + this.random.nextInt(6)));
            }
        }
        this.discard();
    }

    private void ignite(Vec3 at) {
        if (burning()) return;
        this.setPos(at.x, at.y, at.z);
        this.setDeltaMovement(Vec3.ZERO);
        this.setNoGravity(true);
        this.noPhysics = true;
        this.entityData.set(BURNING, true);
        this.burnTicks = 0;
        if (this.level() instanceof ServerLevel level) {
            FX.burst(level, ParticleTypes.FLAME, at, 30, 1.2, 0.05);
            FX.sound(level, at, PXSounds.SOPLETE_NAPALM.get(), 1.0F, 0.8F);
            burnArea(level);
        }
    }

    private void burnArea(ServerLevel level) {
        Vec3 c = this.position();
        DamageSource source = PXDamage.source(level, PXDamage.LLAMA, this, this.getOwner());
        AABB box = new AABB(c, c).inflate(2.5, 1.5, 2.5);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> Aim.targetable(this, x))) {
            e.igniteForSeconds(4.0F);
            e.invulnerableTime = 0;
            e.hurt(source, 2.0F);
        }
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 128.0 * 128.0;
    }

    @Override
    public boolean isPickable() {
        return false;
    }
}
