package com.proyectox.entity;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Orienta un proyectil según su velocidad (para que se dibuje bien desde el primer tick). */
final class ProjectileAim {
    private ProjectileAim() {}

    static void face(Entity entity, Vec3 velocity) {
        double horizontal = velocity.horizontalDistance();
        entity.setYRot((float) (Mth.atan2(velocity.x, velocity.z) * (180.0 / Math.PI)));
        entity.setXRot((float) (Mth.atan2(velocity.y, horizontal) * (180.0 / Math.PI)));
        entity.yRotO = entity.getYRot();
        entity.xRotO = entity.getXRot();
    }
}
