package com.proyectox.entity;

import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXEntities;
import com.proyectox.util.FX;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/** Onda de plasma en media luna de la CIZALLA: atraviesa a todos los enemigos durante 16 bloques. */
public class SlashWave extends ThrowableProjectile {
    private static final int MAX_LIFE = 10;
    private static final float DAMAGE = 8.0F;
    private final Set<Integer> hit = new HashSet<>();

    public SlashWave(EntityType<? extends SlashWave> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public static SlashWave create(ServerLevel level, LivingEntity owner, Vec3 pos, Vec3 velocity) {
        SlashWave w = new SlashWave(PXEntities.TAJO.get(), level);
        w.setOwner(owner);
        w.setPos(pos.x, pos.y, pos.z);
        w.setDeltaMovement(velocity);
        ProjectileAim.face(w, velocity);
        return w;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {}

    @Override
    public void tick() {
        super.tick();
        if (this.level() instanceof ServerLevel level) {
            // el filo es ancho: además del rayo de movimiento, barre una caja alrededor
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(0.9, 0.5, 0.9),
                    x -> x != this.getOwner() && x.isAlive() && !x.isSpectator())) {
                slash(level, e);
            }
            if (this.tickCount > MAX_LIFE) this.discard();
        } else {
            this.level().addParticle(ParticleTypes.SWEEP_ATTACK, this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
        }
    }

    private void slash(ServerLevel level, Entity target) {
        if (!hit.add(target.getId())) return;
        DamageSource source = PXDamage.source(level, PXDamage.CORTE, this, this.getOwner());
        target.invulnerableTime = 0;
        target.hurt(source, DAMAGE);
        FX.burst(level, FX.dust(0xFF2E7E, 1.2F), target.getBoundingBox().getCenter(), 10, 0.3, 0.05);
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        return super.canHitEntity(target) && !hit.contains(target.getId());
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (this.level() instanceof ServerLevel level) slash(level, result.getEntity());
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (this.level() instanceof ServerLevel level) {
            FX.burst(level, FX.dust(0xFF2E7E, 1.0F), result.getLocation(), 10, 0.2, 0.05);
            this.discard();
        }
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 96.0 * 96.0;
    }

    @Override
    public boolean isPickable() {
        return false;
    }
}
