package com.proyectox.entity;

import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXEntities;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import javax.annotation.Nullable;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Microcohete buscador de la COLMENA. Acelera, corrige el rumbo hacia su objetivo y explota
 * (9 de daño directo + onda de radio 2). No se arma hasta recorrer 4 bloques.
 */
public class MicroRocket extends ThrowableProjectile {
    private static final double ARM_DISTANCE = 4.0;
    private static final int MAX_LIFE = 90;
    private static final float DIRECT_DAMAGE = 9.0F;
    private static final float SPLASH_DAMAGE = 5.0F;
    private static final double SPLASH_RADIUS = 2.0;

    private int targetId = -1;
    private Vec3 origin = Vec3.ZERO;
    private boolean exploded;

    public MicroRocket(EntityType<? extends MicroRocket> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public static MicroRocket create(ServerLevel level, LivingEntity owner, Vec3 pos, Vec3 velocity, @Nullable LivingEntity target) {
        MicroRocket rocket = new MicroRocket(PXEntities.MICROCOHETE.get(), level);
        rocket.setOwner(owner);
        rocket.setPos(pos.x, pos.y, pos.z);
        rocket.setDeltaMovement(velocity);
        rocket.origin = pos;
        rocket.targetId = target == null ? -1 : target.getId();
        ProjectileAim.face(rocket, velocity);
        return rocket;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {}

    private boolean armed() {
        return this.position().distanceTo(this.origin) >= ARM_DISTANCE;
    }

    @Override
    public void tick() {
        if (!this.level().isClientSide) steer();
        super.tick();
        if (this.level().isClientSide) {
            // estela: llama en la tobera y humo detrás
            Vec3 v = this.getDeltaMovement();
            for (int i = 0; i < 2; i++) {
                double t = i * 0.5;
                this.level().addParticle(ParticleTypes.SMOKE, this.getX() - v.x * t, this.getY() - v.y * t, this.getZ() - v.z * t, 0.0, 0.01, 0.0);
            }
            this.level().addParticle(ParticleTypes.FLAME, this.getX(), this.getY(), this.getZ(), -v.x * 0.05, -v.y * 0.05, -v.z * 0.05);
        } else if (this.tickCount > MAX_LIFE && !this.exploded) {
            detonate(null);
        }
    }

    private void steer() {
        Vec3 v = this.getDeltaMovement();
        double speed = Math.min(2.1, 0.85 + this.tickCount * 0.09);
        Vec3 dir = v.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : v.normalize();
        Entity target = this.targetId >= 0 ? this.level().getEntity(this.targetId) : null;
        if (target instanceof LivingEntity living && living.isAlive() && this.tickCount > 2) {
            Vec3 want = living.getBoundingBox().getCenter().subtract(this.position()).normalize();
            double turn = Math.min(0.35, 0.12 + this.tickCount * 0.01);
            dir = dir.scale(1.0 - turn).add(want.scale(turn)).normalize();
        }
        this.setDeltaMovement(dir.scale(speed));
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        return super.canHitEntity(target) && !(target instanceof MicroRocket);
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (this.level().isClientSide || this.exploded) return;
        detonate(result instanceof EntityHitResult ehr ? ehr.getEntity() : null);
    }

    private void detonate(@Nullable Entity direct) {
        this.exploded = true;
        if (!(this.level() instanceof ServerLevel level)) return;
        Vec3 p = this.position();
        Entity owner = this.getOwner();
        if (!armed()) {
            // sin armar: el cohete se rompe sin explotar
            if (direct != null) direct.hurt(PXDamage.source(level, PXDamage.MICROCOHETE, this, owner), 2.0F);
            FX.burst(level, ParticleTypes.SMOKE, p, 8, 0.15, 0.03);
            FX.burst(level, ParticleTypes.ELECTRIC_SPARK, p, 6, 0.1, 0.2);
            FX.sound(level, p, PXSounds.VACIO.get(), 0.6F, 0.6F);
            this.discard();
            return;
        }
        DamageSource source = PXDamage.source(level, PXDamage.MICROCOHETE, this, owner);
        if (direct != null) {
            direct.invulnerableTime = 0;
            direct.hurt(source, DIRECT_DAMAGE);
        }
        for (LivingEntity e : Aim.sphere(level, this, p, SPLASH_RADIUS)) {
            if (e == direct) continue;
            double d = e.getBoundingBox().getCenter().distanceTo(p);
            float dmg = (float) (SPLASH_DAMAGE * Math.max(0.3, 1.0 - d / (SPLASH_RADIUS + 1.0)));
            e.invulnerableTime = 0;
            e.hurt(source, dmg);
            Vec3 push = e.position().subtract(p).normalize();
            e.setDeltaMovement(e.getDeltaMovement().add(push.x * 0.4, 0.25, push.z * 0.4));
            e.hurtMarked = true;
        }
        FX.burst(level, ParticleTypes.EXPLOSION, p, 1, 0.0, 0.0);
        FX.burst(level, ParticleTypes.FLAME, p, 14, 0.3, 0.08);
        FX.burst(level, ParticleTypes.LARGE_SMOKE, p, 8, 0.4, 0.03);
        FX.burst(level, FX.dust(0xFF3C3C, 1.5F), p, 12, 0.5, 0.05);
        FX.sound(level, p, PXSounds.COLMENA_EXPLOSION.get(), 1.3F, 0.95F + this.random.nextFloat() * 0.2F);
        this.discard();
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 128.0 * 128.0;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

}
