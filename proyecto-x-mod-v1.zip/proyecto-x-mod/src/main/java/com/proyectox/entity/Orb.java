package com.proyectox.entity;

import com.proyectox.fx.Fx;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXEntities;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.Blast;
import com.proyectox.util.FX;
import com.proyectox.util.Hits;
import javax.annotation.Nullable;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Proyectiles de la serie PX-2x que actúan al chocar: el obús del MORTERO (parábola alta hasta el punto de
 * mira, 35 de daño en radio 5), el sol del SOLAR (de 20 a 60 de daño en radio 3–6 según la carga), la cápsula
 * del ENJAMBRE (suelta el enjambre cazador), el glóbulo de la CÁUSTICA (8 de daño, salpica y deja un charco)
 * y el cristal de la ESQUIRLA (22 de daño y se parte en 7 esquirlas de 8). Nunca dañan a su tirador.
 */
public class Orb extends PXProjectile {
    public static final int SHELL = 0;
    public static final int SOLAR = 1;
    public static final int POD = 2;
    public static final int ACID = 3;
    public static final int CRYSTAL = 4;
    public static final int SHARD = 5;

    public static final float SHELL_DAMAGE = 35.0F;
    public static final double SHELL_RADIUS = 5.0;
    /** Gravedad del obús por tick (sin rozamiento: ver {@link #tick()}). */
    public static final double SHELL_GRAVITY = 0.08;
    public static final float SOLAR_MIN = 20.0F;
    public static final float SOLAR_MAX = 60.0F;
    public static final float ACID_DAMAGE = 8.0F;
    public static final double ACID_SPLASH = 1.8;
    public static final float CRYSTAL_DAMAGE = 22.0F;
    public static final float SHARD_DAMAGE = 8.0F;
    public static final int SHARDS = 7;

    private static final EntityDataAccessor<Integer> KIND = SynchedEntityData.defineId(Orb.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> POWER = SynchedEntityData.defineId(Orb.class, EntityDataSerializers.FLOAT);

    /** Criatura que una esquirla no vuelve a herir (la que partió el cristal). */
    private int ignore = -1;

    public Orb(EntityType<? extends Orb> type, Level level) {
        super(type, level);
    }

    public static Orb create(ServerLevel level, @Nullable Entity owner, int kind, Vec3 pos, Vec3 velocity, float damage, int life, float power) {
        Orb o = new Orb(PXEntities.ORBE.get(), level);
        o.entityData.set(KIND, kind);
        o.entityData.set(POWER, power);
        o.setNoGravity(gravity(kind) <= 0.0);
        o.launch(owner, pos, velocity);
        o.damage = damage;
        o.maxLife = life;
        return o;
    }

    public int kind() {
        return this.entityData.get(KIND);
    }

    /** Carga del sol (0–1). */
    public float power() {
        return this.entityData.get(POWER);
    }

    /** Gravedad efectiva por tick de cada tipo. */
    public static double gravity(int kind) {
        return switch (kind) {
            case SHELL -> SHELL_GRAVITY;
            case ACID -> 0.035;
            case POD -> 0.025;
            default -> 0.0;
        };
    }

    /** Radio de la explosión del sol según su carga. */
    public static double solarRadius(float power) {
        return 3.0 + 3.0 * power;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(KIND, SHELL);
        builder.define(POWER, 0.0F);
    }

    @Override
    protected double getDefaultGravity() {
        return gravity(kind());
    }

    @Override
    public void tick() {
        super.tick();
        // el obús vuela sin rozamiento para caer justo donde se apuntó
        if (this.isAlive() && kind() == SHELL && !this.isInWater()) {
            this.setDeltaMovement(this.getDeltaMovement().scale(1.0 / 0.99));
        }
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        return target.getId() != this.ignore && super.canHitEntity(target);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (!(this.level() instanceof ServerLevel level) || !this.isAlive()) return;
        Entity target = result.getEntity();
        Vec3 at = contact(target);
        switch (kind()) {
            case SHELL -> shellBlast(level, at, target);
            case SOLAR -> sunBlast(level, at, target);
            case POD -> releaseSwarm(level, at);
            case ACID -> {
                strike(level, target, PXDamage.ACIDO, this.damage);
                Vec3 ground = Blast.ground(level, this, target.position().add(0.0, 0.5, 0.0), 6.0);
                splash(level, at, target, ground);
            }
            case CRYSTAL -> {
                strike(level, target, PXDamage.ESQUIRLA, this.damage);
                shatter(level, at, this.heading(), null, target.getId());
            }
            default -> {
                strike(level, target, PXDamage.ESQUIRLA, this.damage);
                Fx.impact(level, Fx.ESQUIRLA, at, this.heading().reverse());
                this.discard();
            }
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (!(this.level() instanceof ServerLevel level) || !this.isAlive()) return;
        Vec3 n = normal(result);
        Vec3 at = result.getLocation().add(n.scale(0.2));
        switch (kind()) {
            case SHELL -> shellBlast(level, at, null);
            case SOLAR -> sunBlast(level, at, null);
            case POD -> releaseSwarm(level, result.getLocation().add(n.scale(0.6)));
            case ACID -> splash(level, at, null, n.y > 0.5 ? result.getLocation().add(0.0, 0.02, 0.0) : Blast.ground(level, this, at, 6.0));
            case CRYSTAL -> shatter(level, result.getLocation().add(n.scale(0.15)), this.heading(), n, -1);
            default -> {
                Fx.impact(level, Fx.ESQUIRLA, result.getLocation(), n);
                this.discard();
            }
        }
    }

    @Override
    protected void expire() {
        if (!(this.level() instanceof ServerLevel level)) return;
        Vec3 p = this.position();
        switch (kind()) {
            case SHELL -> shellBlast(level, p, null);
            case SOLAR -> sunBlast(level, p, null);
            case POD -> releaseSwarm(level, p);
            case ACID -> splash(level, p, null, null);
            case CRYSTAL -> shatter(level, p, this.heading(), null, -1);
            default -> this.discard();
        }
    }

    // ------------------------------------------------------------------ efectos

    private void shellBlast(ServerLevel level, Vec3 at, @Nullable Entity direct) {
        Blast.damage(level, this, this.getOwner(), at, SHELL_RADIUS, this.damage, direct, PXDamage.MORTERO, 0.5F);
        Fx.explosion(level, Fx.MORTERO, at, (float) SHELL_RADIUS);
        FX.sound(level, at, PXSounds.MORTERO_EXPLOSION.get(), 2.4F, 0.8F + this.random.nextFloat() * 0.1F);
        this.discard();
    }

    private void sunBlast(ServerLevel level, Vec3 at, @Nullable Entity direct) {
        float p = power();
        double radius = solarRadius(p);
        float amount = SOLAR_MIN + (SOLAR_MAX - SOLAR_MIN) * p;
        Blast.damage(level, this, this.getOwner(), at, radius, amount, direct, PXDamage.FUSION, 0.55F);
        Fx.explosion(level, Fx.SOLAR, at, (float) radius);
        FX.sound(level, at, PXSounds.SOLAR_EXPLOSION.get(), 1.6F + p, 1.0F - 0.3F * p);
        this.discard();
    }

    private void releaseSwarm(ServerLevel level, Vec3 at) {
        level.addFreshEntity(Field.create(level, this.getOwner(), Field.SWARM, at, Vec3.ZERO));
        Fx.explosion(level, Fx.ENJAMBRE, at, 1.5F);
        FX.sound(level, at, PXSounds.ENJAMBRE_ZUMBIDO.get(), 1.2F, 1.2F);
        this.discard();
    }

    /** Glóbulo de ácido: salpica alrededor (la mitad del daño) y deja un charco o refuerza el que ya hay. */
    private void splash(ServerLevel level, Vec3 at, @Nullable Entity direct, @Nullable Vec3 ground) {
        Entity owner = this.getOwner();
        DamageSource ds = PXDamage.source(level, PXDamage.ACIDO, this, owner);
        for (LivingEntity e : Aim.sphere(level, owner != null ? owner : this, at, ACID_SPLASH)) {
            if (e != direct && e != owner) Hits.hurt(e, ds, this.damage * 0.5F, owner);
        }
        if (ground != null) {
            Field pool = null;
            for (Field f : level.getEntitiesOfClass(Field.class, new AABB(ground, ground).inflate(1.4), f -> f.type() == Field.ACID_POOL)) {
                pool = f;
                break;
            }
            if (pool != null) pool.refresh();
            else level.addFreshEntity(Field.create(level, owner, Field.ACID_POOL, ground, Vec3.ZERO));
        }
        Fx.explosion(level, Fx.CAUSTICA, at, (float) ACID_SPLASH);
        if (this.random.nextInt(3) == 0) FX.sound(level, at, PXSounds.CAUSTICA_SALPICAR.get(), 0.8F, 1.3F + this.random.nextFloat() * 0.4F);
        this.discard();
    }

    /**
     * El cristal se parte en esquirlas: si atravesó a una criatura siguen hacia delante en abanico; si chocó
     * contra un bloque rebotan hacia fuera de la pared.
     */
    private void shatter(ServerLevel level, Vec3 at, Vec3 dir, @Nullable Vec3 normal, int ignoreId) {
        Entity owner = this.getOwner();
        for (int i = 0; i < SHARDS; i++) {
            Vec3 d;
            if (normal == null) {
                d = Aim.spread(dir, this.random, 16.0);
            } else {
                Vec3 refl = dir.subtract(normal.scale(2.0 * dir.dot(normal)));
                d = Aim.spread(refl.add(normal.scale(0.6)).normalize(), this.random, 32.0);
                if (d.dot(normal) < 0.15) d = d.add(normal.scale(0.4)).normalize();
            }
            Orb shard = create(level, owner, SHARD, at.add(d.scale(0.25)), d.scale(2.8), SHARD_DAMAGE, 16, 0.0F);
            shard.ignore = ignoreId;
            level.addFreshEntity(shard);
        }
        Fx.explosion(level, Fx.ESQUIRLA, at, 1.2F);
        FX.sound(level, at, PXSounds.ESQUIRLA_ESTALLIDO.get(), 1.2F, 1.1F + this.random.nextFloat() * 0.3F);
        this.discard();
    }
}
