package com.proyectox.entity;

import com.proyectox.item.SierraItem;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXEntities;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.FX;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Disco de sierra de la SIERRA: atraviesa enemigos (cada uno recibe un golpe cada 10 ticks),
 * rebota hasta 3 veces en los bloques y puede volver al lanzador.
 */
public class SawDisc extends ThrowableProjectile {
    private static final EntityDataAccessor<Boolean> RETURNING = SynchedEntityData.defineId(SawDisc.class, EntityDataSerializers.BOOLEAN);
    private static final int MAX_LIFE = 60;
    private static final float DAMAGE = 6.0F;

    private final Map<Integer, Integer> lastHit = new HashMap<>();
    private int bounces;

    public SawDisc(EntityType<? extends SawDisc> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public static SawDisc create(ServerLevel level, LivingEntity owner, Vec3 pos, Vec3 velocity) {
        SawDisc d = new SawDisc(PXEntities.DISCO.get(), level);
        d.setOwner(owner);
        d.setPos(pos.x, pos.y, pos.z);
        d.setDeltaMovement(velocity);
        ProjectileAim.face(d, velocity);
        return d;
    }

    /** Recuperación: todos los discos del jugador vuelven hacia él. */
    public static int recallAll(ServerLevel level, Player owner) {
        List<SawDisc> list = level.getEntitiesOfClass(SawDisc.class, owner.getBoundingBox().inflate(64.0), d -> d.getOwner() == owner && d.isAlive());
        for (SawDisc d : list) d.entityData.set(RETURNING, true);
        return list.size();
    }

    public boolean returning() {
        return this.entityData.get(RETURNING);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(RETURNING, false);
    }

    @Override
    public void tick() {
        if (!this.level().isClientSide) {
            Entity owner = this.getOwner();
            if (returning()) {
                if (owner == null || !owner.isAlive()) {
                    this.discard();
                    return;
                }
                Vec3 to = owner.getEyePosition().add(0, -0.4, 0).subtract(this.position());
                if (to.length() < 1.4) {
                    refund(owner);
                    this.discard();
                    return;
                }
                this.noPhysics = true;
                this.setDeltaMovement(to.normalize().scale(1.6));
            } else if (this.tickCount > MAX_LIFE) {
                FX.burst((ServerLevel) this.level(), ParticleTypes.ELECTRIC_SPARK, this.position(), 6, 0.1, 0.1);
                this.discard();
                return;
            }
        }
        super.tick();
        if (returning()) cutAlongPath();
        if (this.level().isClientSide && this.tickCount % 2 == 0) {
            this.level().addParticle(ParticleTypes.ELECTRIC_SPARK, this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
        }
    }

    /** Al volver no colisiona: corta a quien encuentre en el camino. */
    private void cutAlongPath() {
        if (!(this.level() instanceof ServerLevel level)) return;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(0.4),
                x -> x != this.getOwner() && x.isAlive() && !x.isSpectator())) {
            cut(level, e);
        }
    }

    private void cut(ServerLevel level, Entity target) {
        Integer last = lastHit.get(target.getId());
        if (last != null && this.tickCount - last < 10) return;
        lastHit.put(target.getId(), this.tickCount);
        DamageSource source = PXDamage.source(level, PXDamage.DISCO, this, this.getOwner());
        target.invulnerableTime = 0;
        target.hurt(source, DAMAGE);
        FX.burst(level, FX.dust(0x2EE6A0, 1.0F), target.getBoundingBox().getCenter(), 8, 0.25, 0.05);
        FX.sound(level, this.position(), PXSounds.SIERRA_CORTE.get(), 0.8F, 1.0F + this.random.nextFloat() * 0.3F);
    }

    private void refund(Entity owner) {
        if (!(owner instanceof Player player)) return;
        for (ItemStack stack : new ItemStack[]{player.getMainHandItem(), player.getOffhandItem()}) {
            if (stack.getItem() instanceof SierraItem sierra) {
                long now = player.level().getGameTime();
                sierra.setCharge(stack, now, Math.min(sierra.maxCharge(), sierra.charge(stack, now) + 1), 0);
                return;
            }
        }
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        return !returning() && super.canHitEntity(target);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (this.level() instanceof ServerLevel level) cut(level, result.getEntity());
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (this.level().isClientSide || returning()) return;
        if (bounces >= 3) {
            FX.burst((ServerLevel) this.level(), ParticleTypes.ELECTRIC_SPARK, result.getLocation(), 10, 0.1, 0.2);
            this.discard();
            return;
        }
        bounces++;
        Vec3 v = this.getDeltaMovement();
        Vec3 n = Vec3.atLowerCornerOf(result.getDirection().getNormal());
        Vec3 r = v.subtract(n.scale(2.0 * v.dot(n)));
        this.setDeltaMovement(r);
        Vec3 p = result.getLocation().add(n.scale(0.2));
        this.setPos(p.x, p.y, p.z);
        FX.burst((ServerLevel) this.level(), ParticleTypes.ELECTRIC_SPARK, result.getLocation(), 8, 0.05, 0.25);
        FX.sound(this.level(), p, PXSounds.SIERRA_REBOTE.get(), 0.7F, 1.6F + this.random.nextFloat() * 0.2F);
    }

    @Override
    protected void onHit(HitResult result) {
        // no se destruye al impactar: el disco atraviesa criaturas y rebota en bloques
        super.onHit(result);
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 96.0 * 96.0;
    }

    @Override
    public boolean isPickable() {
        return false;
    }
}
