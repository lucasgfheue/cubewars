package com.proyectox.entity;

import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXEntities;
import com.proyectox.util.FX;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Proyectil de energía genérico de las armas automáticas nuevas:
 * trazadora (ROTOR), aguja tóxica (COLIBRÍ) y pulso del dron (HALCÓN).
 */
public class EnergyBolt extends ThrowableProjectile {
    public static final int TRACER = 0;
    public static final int NEEDLE = 1;
    public static final int DRONE = 2;

    private static final EntityDataAccessor<Integer> STYLE = SynchedEntityData.defineId(EnergyBolt.class, EntityDataSerializers.INT);
    /** Agujas acumuladas por objetivo (COLIBRÍ): cada 5 aplican veneno. */
    private static final Map<Entity, Integer> TOXIN = new WeakHashMap<>();

    private float damage = 2.0F;
    private double falloffRange = 40.0;
    private int maxLife = 24;
    private Vec3 origin = Vec3.ZERO;

    public EnergyBolt(EntityType<? extends EnergyBolt> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public static EnergyBolt create(ServerLevel level, LivingEntity owner, int style, Vec3 pos, Vec3 velocity, float damage, double falloff, int life) {
        EnergyBolt bolt = new EnergyBolt(PXEntities.BOLT.get(), level);
        bolt.setOwner(owner);
        bolt.setPos(pos.x, pos.y, pos.z);
        bolt.setDeltaMovement(velocity);
        bolt.damage = damage;
        bolt.falloffRange = falloff;
        bolt.maxLife = life;
        bolt.origin = pos;
        bolt.entityData.set(STYLE, style);
        ProjectileAim.face(bolt, velocity);
        return bolt;
    }

    public int style() {
        return this.entityData.get(STYLE);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(STYLE, TRACER);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.tickCount > this.maxLife) this.discard();
    }

    private ResourceKey<DamageType> damageType() {
        return switch (style()) {
            case NEEDLE -> PXDamage.AGUJA_TOXICA;
            case DRONE -> PXDamage.DRON;
            default -> PXDamage.TRAZADORA;
        };
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (!(this.level() instanceof ServerLevel level)) return;
        Entity target = result.getEntity();
        float dealt = this.origin.distanceTo(target.position()) > this.falloffRange ? this.damage * 0.5F : this.damage;
        target.invulnerableTime = 0;
        boolean hurt = target.hurt(PXDamage.source(level, damageType(), this, this.getOwner()), dealt);
        if (hurt && target instanceof LivingEntity living) {
            switch (style()) {
                case TRACER -> living.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false), this.getOwner());
                case NEEDLE -> {
                    int n = TOXIN.getOrDefault(living, 0) + 1;
                    if (n >= 5) {
                        MobEffectInstance cur = living.getEffect(MobEffects.POISON);
                        int dur = cur == null ? 60 : Math.min(200, cur.getDuration() + 60);
                        living.addEffect(new MobEffectInstance(MobEffects.POISON, dur, 0), this.getOwner());
                        n = 0;
                    }
                    TOXIN.put(living, n);
                }
                default -> { }
            }
        }
        FX.burst(level, style() == NEEDLE ? FX.dust(0xFF8FD0, 0.7F) : ParticleTypes.ELECTRIC_SPARK, result.getLocation(), 3, 0.08, 0.06);
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (this.level() instanceof ServerLevel level) {
            FX.burst(level, ParticleTypes.ELECTRIC_SPARK, result.getLocation(), 2, 0.05, 0.08);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide) this.discard();
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 96.0 * 96.0;
    }

    @Override
    public boolean isPickable() {
        return false;
    }
}
