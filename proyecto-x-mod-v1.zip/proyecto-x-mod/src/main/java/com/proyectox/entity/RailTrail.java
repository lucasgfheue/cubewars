package com.proyectox.entity;

import com.proyectox.registry.PXEntities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Estela luminosa de un disparo instantáneo (rayo). Solo es visual: guarda el punto final,
 * el color, el grosor y la duración, y se borra sola.
 */
public class RailTrail extends Entity {
    private static final EntityDataAccessor<Float> DX = SynchedEntityData.defineId(RailTrail.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DY = SynchedEntityData.defineId(RailTrail.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DZ = SynchedEntityData.defineId(RailTrail.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> WIDTH = SynchedEntityData.defineId(RailTrail.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(RailTrail.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> LIFE = SynchedEntityData.defineId(RailTrail.class, EntityDataSerializers.INT);

    public RailTrail(EntityType<? extends RailTrail> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public static void spawn(ServerLevel level, Vec3 from, Vec3 to, int color, float width, int life) {
        RailTrail trail = new RailTrail(PXEntities.ESTELA.get(), level);
        trail.setPos(from.x, from.y, from.z);
        Vec3 d = to.subtract(from);
        trail.entityData.set(DX, (float) d.x);
        trail.entityData.set(DY, (float) d.y);
        trail.entityData.set(DZ, (float) d.z);
        trail.entityData.set(WIDTH, width);
        trail.entityData.set(COLOR, color);
        trail.entityData.set(LIFE, life);
        level.addFreshEntity(trail);
    }

    public Vec3 delta() {
        return new Vec3(this.entityData.get(DX), this.entityData.get(DY), this.entityData.get(DZ));
    }

    public float width() {
        return this.entityData.get(WIDTH);
    }

    public int color() {
        return this.entityData.get(COLOR);
    }

    public int life() {
        return Math.max(1, this.entityData.get(LIFE));
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DX, 0.0F);
        builder.define(DY, 0.0F);
        builder.define(DZ, 0.0F);
        builder.define(WIDTH, 0.1F);
        builder.define(COLOR, 0xFFFFFF);
        builder.define(LIFE, 12);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.tickCount > life()) this.discard();
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 192.0 * 192.0;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }


    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}
}
