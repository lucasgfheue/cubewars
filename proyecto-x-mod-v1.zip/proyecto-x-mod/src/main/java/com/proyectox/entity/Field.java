package com.proyectox.entity;

import com.proyectox.client.ClientOnly;
import com.proyectox.fx.Fx;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXEntities;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.Blast;
import com.proyectox.util.FX;
import com.proyectox.util.Hits;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Zonas de efecto que dejan algunas armas: el charco de la CÁUSTICA (2 de daño cada 0,5 s), la nube de la
 * TEMPESTAD (lanza un rayo de 12 cada 0,3 s a las criaturas que tiene debajo), el tornado del CICLÓN (avanza
 * 3 s, atrae y hace 6 cada 0,25 s) y el enjambre del ENJAMBRE (caza a la criatura más cercana durante 5 s,
 * 3 cada 0,25 s). Nunca dañan ni atraen a su tirador.
 */
public class Field extends Entity {
    public static final int ACID_POOL = 0;
    public static final int STORM = 1;
    public static final int TORNADO = 2;
    public static final int SWARM = 3;

    public static final float POOL_RADIUS = 1.6F;
    public static final float POOL_MAX_RADIUS = 2.6F;
    public static final int POOL_LIFE = 80;
    public static final float POOL_DAMAGE = 2.0F;

    public static final int STORM_LIFE = 80;
    public static final double STORM_RADIUS = 6.0;
    public static final float STORM_DAMAGE = 12.0F;
    public static final int STORM_EVERY = 6;

    public static final int TORNADO_LIFE = 60;
    public static final double TORNADO_SPEED = 0.35;
    public static final double TORNADO_PULL = 5.5;
    public static final double TORNADO_CORE = 2.4;
    public static final double TORNADO_HEIGHT = 5.0;
    public static final float TORNADO_DAMAGE = 6.0F;

    public static final int SWARM_LIFE = 100;
    public static final double SWARM_SPEED = 0.55;
    public static final double SWARM_SEEK = 24.0;
    public static final double SWARM_RADIUS = 1.8;
    public static final float SWARM_DAMAGE = 3.0F;

    private static final EntityDataAccessor<Integer> TYPE = SynchedEntityData.defineId(Field.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> SIZE = SynchedEntityData.defineId(Field.class, EntityDataSerializers.FLOAT);
    /** Tick (de su propia cuenta) en que la zona se acaba. */
    private static final EntityDataAccessor<Integer> END = SynchedEntityData.defineId(Field.class, EntityDataSerializers.INT);

    @Nullable
    private UUID ownerId;
    private Vec3 heading = Vec3.ZERO;
    private Vec3 home = Vec3.ZERO;
    private int targetId = -1;

    public Field(EntityType<? extends Field> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public static Field create(ServerLevel level, @Nullable Entity owner, int type, Vec3 pos, Vec3 heading) {
        Field f = new Field(PXEntities.CAMPO.get(), level);
        f.setPos(pos.x, pos.y, pos.z);
        f.entityData.set(TYPE, type);
        f.ownerId = owner != null ? owner.getUUID() : null;
        f.heading = new Vec3(heading.x, 0.0, heading.z);
        if (f.heading.lengthSqr() > 1.0E-6) f.heading = f.heading.normalize();
        f.home = pos;
        f.entityData.set(END, switch (type) {
            case ACID_POOL -> POOL_LIFE;
            case STORM -> STORM_LIFE;
            case TORNADO -> TORNADO_LIFE;
            default -> SWARM_LIFE;
        });
        f.entityData.set(SIZE, type == ACID_POOL ? POOL_RADIUS : 1.0F);
        return f;
    }

    public int type() {
        return this.entityData.get(TYPE);
    }

    /** Radio del charco (crece si le caen más glóbulos). */
    public float size() {
        return this.entityData.get(SIZE);
    }

    /** Tick en que se acaba la zona (el cliente lo usa para el fundido). */
    public int end() {
        return this.entityData.get(END);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(TYPE, ACID_POOL);
        builder.define(SIZE, 1.0F);
        builder.define(END, 60);
    }

    /** Un glóbulo nuevo cae sobre el charco: dura más y se ensancha un poco. */
    public void refresh() {
        this.entityData.set(END, this.tickCount + POOL_LIFE);
        this.entityData.set(SIZE, Math.min(POOL_MAX_RADIUS, size() + 0.12F));
    }

    @Nullable
    private Entity owner(ServerLevel level) {
        return this.ownerId == null ? null : level.getEntity(this.ownerId);
    }

    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel level)) {
            ClientOnly.fieldTick(this);
            return;
        }
        if (this.tickCount > end()) {
            this.discard();
            return;
        }
        Entity owner = owner(level);
        Entity filter = owner != null ? owner : this;
        switch (type()) {
            case ACID_POOL -> pool(level, owner, filter);
            case STORM -> storm(level, owner, filter);
            case TORNADO -> tornado(level, owner, filter);
            default -> swarm(level, owner, filter);
        }
    }

    // ------------------------------------------------------------------ CÁUSTICA

    private void pool(ServerLevel level, @Nullable Entity owner, Entity filter) {
        if (this.tickCount % 10 != 0) return;
        Vec3 c = this.position();
        double r = size();
        DamageSource ds = PXDamage.source(level, PXDamage.ACIDO, this, owner);
        AABB box = new AABB(c.x - r - 1, c.y - 0.5, c.z - r - 1, c.x + r + 1, c.y + 1.4, c.z + r + 1);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> Aim.targetable(filter, x))) {
            double dx = e.getX() - c.x;
            double dz = e.getZ() - c.z;
            if (Math.sqrt(dx * dx + dz * dz) <= r + e.getBbWidth() * 0.5) Hits.hurt(e, ds, POOL_DAMAGE, owner);
        }
    }

    // ------------------------------------------------------------------ TEMPESTAD

    private void storm(ServerLevel level, @Nullable Entity owner, Entity filter) {
        if (this.tickCount < 8 || this.tickCount % STORM_EVERY != 0) return;
        Vec3 c = this.position();
        AABB box = new AABB(c.x - STORM_RADIUS, c.y - 18.0, c.z - STORM_RADIUS, c.x + STORM_RADIUS, c.y + 1.0, c.z + STORM_RADIUS);
        List<LivingEntity> under = level.getEntitiesOfClass(LivingEntity.class, box, x -> Aim.targetable(filter, x));
        LivingEntity victim = under.isEmpty() ? null : under.get(this.random.nextInt(under.size()));
        Vec3 target;
        if (victim != null) {
            target = victim.getBoundingBox().getCenter();
        } else {
            double a = this.random.nextDouble() * Math.PI * 2.0;
            double d = this.random.nextDouble() * 4.5;
            target = Blast.ground(level, this, c.add(Math.cos(a) * d, -0.5, Math.sin(a) * d), 18.0);
            if (target == null) return;
        }
        Vec3 from = c.add((this.random.nextDouble() - 0.5) * 3.0, -0.6, (this.random.nextDouble() - 0.5) * 3.0);
        DamageSource ds = PXDamage.source(level, PXDamage.TORMENTA, this, owner);
        if (victim != null) Hits.hurt(victim, ds, STORM_DAMAGE, owner);
        for (LivingEntity e : Aim.sphere(level, filter, target, 1.6)) {
            if (e != victim) Hits.hurt(e, ds, STORM_DAMAGE, owner);
        }
        Fx.line(level, Fx.LIGHTNING, Fx.TEMPESTAD, from, target, 1.0F, -1);
        FX.sound(level, target, PXSounds.TEMPESTAD_RAYO.get(), 1.6F, 0.85F + this.random.nextFloat() * 0.35F);
    }

    // ------------------------------------------------------------------ CICLÓN

    private void tornado(ServerLevel level, @Nullable Entity owner, Entity filter) {
        Vec3 p = this.position();
        if (this.heading.lengthSqr() > 1.0E-6) {
            Vec3 next = p.add(this.heading.scale(TORNADO_SPEED));
            BlockHitResult g = level.clip(new ClipContext(next.add(0.0, 2.5, 0.0), next.subtract(0.0, 4.0, 0.0),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
            if (g.getType() != HitResult.Type.MISS) next = new Vec3(next.x, g.getLocation().y, next.z);
            BlockPos wall = BlockPos.containing(next.x, next.y + 0.6, next.z);
            if (level.getBlockState(wall).getCollisionShape(level, wall).isEmpty()) {
                this.setPos(next.x, next.y, next.z);
                p = next;
            } else {
                this.heading = Vec3.ZERO;
            }
        }
        if (this.tickCount % 20 == 1) FX.sound(level, p, PXSounds.CICLON_VIENTO.get(), 1.2F, 0.7F + this.random.nextFloat() * 0.2F);
        DamageSource ds = PXDamage.source(level, PXDamage.TORBELLINO, this, owner);
        boolean hitTick = this.tickCount % 5 == 0;
        AABB box = new AABB(p.x - TORNADO_PULL, p.y - 1.0, p.z - TORNADO_PULL, p.x + TORNADO_PULL, p.y + TORNADO_HEIGHT + 1.0, p.z + TORNADO_PULL);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> Aim.targetable(filter, x))) {
            if (e instanceof Player pl && pl.getAbilities().flying) continue;
            double dx = p.x - e.getX();
            double dz = p.z - e.getZ();
            double dh = Math.sqrt(dx * dx + dz * dz);
            if (dh > TORNADO_PULL) continue;
            double rel = e.getY() - p.y;
            // atrae hacia el eje y hace girar; dentro del núcleo lo levanta un poco
            Vec3 inward = dh < 1.0E-3 ? Vec3.ZERO : new Vec3(dx / dh, 0.0, dz / dh);
            Vec3 swirl = new Vec3(-inward.z, 0.0, inward.x);
            double pull = 0.06 + 0.12 * (1.0 - dh / TORNADO_PULL);
            double lift = dh < TORNADO_CORE && rel < 3.2 ? 0.1 : 0.0;
            e.setDeltaMovement(e.getDeltaMovement().scale(0.6).add(inward.scale(pull)).add(swirl.scale(0.16)).add(0.0, lift, 0.0));
            e.resetFallDistance();
            e.hurtMarked = true;
            if (hitTick && dh <= TORNADO_CORE + e.getBbWidth() * 0.5 && rel > -1.0 && rel < TORNADO_HEIGHT) Hits.hurt(e, ds, TORNADO_DAMAGE, owner);
        }
    }

    // ------------------------------------------------------------------ ENJAMBRE

    private void swarm(ServerLevel level, @Nullable Entity owner, Entity filter) {
        Vec3 p = this.position();
        Entity target = this.targetId >= 0 ? level.getEntity(this.targetId) : null;
        if (target == null || !target.isAlive() || this.tickCount % 10 == 0) {
            LivingEntity best = null;
            double bestD = SWARM_SEEK * SWARM_SEEK;
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(p, p).inflate(SWARM_SEEK), x -> Aim.targetable(filter, x))) {
                double d = e.distanceToSqr(p);
                if (d < bestD) {
                    bestD = d;
                    best = e;
                }
            }
            target = best;
            this.targetId = best != null ? best.getId() : -1;
        }
        Vec3 goal;
        if (target != null) {
            goal = target.getBoundingBox().getCenter();
        } else {
            float t = this.tickCount * 0.12F;
            goal = this.home.add(Mth.cos(t) * 1.5, 1.4 + Mth.sin(t * 0.7F) * 0.4, Mth.sin(t) * 1.5);
        }
        Vec3 d = goal.subtract(p);
        double len = d.length();
        if (len > 1.0E-3) {
            Vec3 step = d.scale(Math.min(len, SWARM_SPEED) / len);
            this.setPos(p.x + step.x, p.y + step.y, p.z + step.z);
        }
        if (this.tickCount % 5 == 0) {
            DamageSource ds = PXDamage.source(level, PXDamage.ENJAMBRE, this, owner);
            for (LivingEntity e : Aim.sphere(level, filter, this.position(), SWARM_RADIUS)) Hits.hurt(e, ds, SWARM_DAMAGE, owner);
        }
        if (this.tickCount % 16 == 2) FX.sound(level, this.position(), PXSounds.ENJAMBRE_ZUMBIDO.get(), 0.9F, 1.4F + this.random.nextFloat() * 0.3F);
    }

    // ------------------------------------------------------------------ entidad

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 192.0 * 192.0;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return this.getBoundingBox().inflate(type() == STORM ? 7.0 : 4.0, type() == TORNADO ? 6.0 : 3.0, type() == STORM ? 7.0 : 4.0);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}
}
