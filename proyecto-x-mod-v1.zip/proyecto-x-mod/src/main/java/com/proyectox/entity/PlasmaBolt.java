package com.proyectox.entity;

import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXEntities;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.FX;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Pulso de plasma del AVISPÓN: rápido, sin gravedad, pierde la mitad del daño más allá de 24 bloques. */
public class PlasmaBolt extends ThrowableProjectile {
    private static final EntityDataAccessor<Boolean> HOT = SynchedEntityData.defineId(PlasmaBolt.class, EntityDataSerializers.BOOLEAN);
    public static final double FALLOFF_RANGE = 24.0;
    private static final int MAX_LIFE = 22;

    private float damage = 3.5F;
    private Vec3 origin = Vec3.ZERO;

    public PlasmaBolt(EntityType<? extends PlasmaBolt> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public static PlasmaBolt create(ServerLevel level, LivingEntity owner, Vec3 pos, Vec3 velocity, float damage, boolean incendiary) {
        PlasmaBolt bolt = new PlasmaBolt(PXEntities.PLASMA.get(), level);
        bolt.setOwner(owner);
        bolt.setPos(pos.x, pos.y, pos.z);
        bolt.setDeltaMovement(velocity);
        bolt.damage = damage;
        bolt.origin = pos;
        bolt.entityData.set(HOT, incendiary);
        ProjectileAim.face(bolt, velocity);
        return bolt;
    }

    public boolean isHot() {
        return this.entityData.get(HOT);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(HOT, false);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.tickCount > MAX_LIFE) this.discard();
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (!(this.level() instanceof ServerLevel level)) return;
        Entity target = result.getEntity();
        double dist = this.origin.distanceTo(target.position());
        float dealt = dist > FALLOFF_RANGE ? this.damage * 0.5F : this.damage;
        // cadencia de 10 pulsos/s: se anula la invulnerabilidad de 0,5 s para que cada pulso cuente
        target.invulnerableTime = 0;
        if (target.hurt(PXDamage.source(level, PXDamage.PLASMA, this, this.getOwner()), dealt) && isHot()) {
            target.igniteForSeconds(3.0F);
        }
        FX.burst(level, isHot() ? ParticleTypes.FLAME : ParticleTypes.ELECTRIC_SPARK, result.getLocation(), 4, 0.1, 0.08);
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (this.level() instanceof ServerLevel level) {
            Vec3 p = result.getLocation();
            FX.burst(level, FX.dust(isHot() ? 0xFFB020 : 0x96FF28, 0.8F), p, 5, 0.08, 0.02);
            FX.burst(level, ParticleTypes.SMOKE, p, 2, 0.05, 0.01);
            if (this.random.nextInt(3) == 0) FX.sound(level, p, PXSounds.AVISPON_IMPACTO.get(), 0.35F, 1.4F + this.random.nextFloat() * 0.3F);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide) this.discard();
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 96.0 * 96.0;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

}
