package com.proyectox.item;

import com.proyectox.ProyectoX;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.FX;
import com.proyectox.util.FallGuard;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.component.Tool;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-07 TALADRO — perforadora de asedio.
 * Pico y pala de netherita a la vez. Mantener clic derecho 0,75 s y soltar: embestida de 8 bloques.
 */
public class TaladroItem extends PXWeapon {
    public static final int WINDUP = 15;
    private static final Map<UUID, Dash> DASHES = new HashMap<>();

    private record Dash(long until, Vec3 dir, Set<Integer> hit) {}

    public TaladroItem(Properties properties) {
        super("taladro", "PX-07", 0xFFE119, properties);
    }

    public static ItemAttributeModifiers attributes() {
        return ItemAttributeModifiers.builder()
                .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_ID, 7.0, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_ID, -3.0, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .build();
    }

    public static Tool tool() {
        return new Tool(List.of(
                Tool.Rule.deniesDrops(BlockTags.INCORRECT_FOR_NETHERITE_TOOL),
                Tool.Rule.minesAndDrops(BlockTags.MINEABLE_WITH_PICKAXE, 9.0F),
                Tool.Rule.minesAndDrops(BlockTags.MINEABLE_WITH_SHOVEL, 9.0F)), 1.0F, 1);
    }

    public static void forget(Player player) {
        DASHES.remove(player.getUUID());
    }

    @Override
    public int maxCharge() {
        return 3;
    }

    @Override
    public int regenTicks() {
        return 100;
    }

    @Override
    protected boolean chargeBar() {
        return false;
    }

    @Override
    public int getEnchantmentValue() {
        return 14;
    }

    @Override
    public boolean isValidRepairItem(ItemStack stack, ItemStack repairCandidate) {
        return repairCandidate.is(Items.NETHERITE_INGOT);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        return true;
    }

    @Override
    public void postHurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        stack.hurtAndBreak(1, attacker, EquipmentSlot.MAINHAND);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (charge(stack, level.getGameTime()) <= 0) {
            emptyClick(level, player, "message.proyectox.taladro.sin_par");
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        if (!level.isClientSide) FX.sound(level, player, PXSounds.TALADRO_CARGA.get(), 0.9F, 1.0F);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        int used = getUseDuration(stack, entity) - remaining;
        if (!level.isClientSide && used == WINDUP) FX.sound(level, entity, PXSounds.LISTO.get(), 0.7F, 1.2F);
        if (level.isClientSide && used % 2 == 0) {
            Vec3 p = entity.getEyePosition().add(entity.getLookAngle().scale(1.2)).add(0, -0.4, 0);
            level.addParticle(ParticleTypes.SMOKE, p.x, p.y, p.z, 0.0, 0.02, 0.0);
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        int used = getUseDuration(stack, entity) - timeLeft;
        if (used < WINDUP || !(entity instanceof Player player)) return;
        long now = level.getGameTime();
        if (level.isClientSide) {
            // el movimiento del jugador lo calcula el cliente: se aplica también aquí para que responda al instante
            if (charge(stack, now) > 0) player.setDeltaMovement(dashVelocity(player));
            return;
        }
        if (!consume(stack, now, 1, 0)) return;
        Vec3 v = dashVelocity(player);
        player.setDeltaMovement(v);
        player.hurtMarked = true;
        FallGuard.protect(player, 40);
        DASHES.put(player.getUUID(), new Dash(now + 10, new Vec3(v.x, 0, v.z).normalize(), new HashSet<>()));
        FX.sound(level, player, PXSounds.TALADRO_EMBESTIDA.get(), 1.2F, 0.9F);
        FX.burst((ServerLevel) level, ParticleTypes.CLOUD, player.position(), 12, 0.3, 0.05);
        player.getCooldowns().addCooldown(this, 10);
    }

    private static Vec3 dashVelocity(Player player) {
        Vec3 look = player.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : flat.normalize();
        return flat.scale(2.3).add(0, 0.22, 0);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (!(level instanceof ServerLevel server) || !(entity instanceof ServerPlayer player)) return;
        Dash dash = DASHES.get(player.getUUID());
        if (dash == null) return;
        if (level.getGameTime() > dash.until()) {
            DASHES.remove(player.getUUID());
            return;
        }
        DamageSource source = PXDamage.source(server, PXDamage.EMBESTIDA, player, player);
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(1.2),
                x -> x != player && x.isAlive() && !x.isSpectator() && !player.isAlliedTo(x))) {
            if (!dash.hit().add(e.getId())) continue;
            e.invulnerableTime = 0;
            e.hurt(source, 9.0F);
            e.setDeltaMovement(e.getDeltaMovement().add(dash.dir().x * 1.4, 0.45, dash.dir().z * 1.4));
            e.hurtMarked = true;
            FX.burst(server, ParticleTypes.CRIT, e.getBoundingBox().getCenter(), 12, 0.3, 0.3);
        }
        server.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 0.5, player.getZ(), 2, 0.2, 0.2, 0.2, 0.01);
    }

    @Override
    protected void appendStatus(ItemStack stack, long now, List<Component> lines) {
        lines.add(Component.translatable("tooltip.proyectox.taladro.carga", charge(stack, now), maxCharge()).withColor(color()));
    }
}
