package com.proyectox.item;

import com.proyectox.entity.PlasmaBolt;
import com.proyectox.network.PXNetwork;
import com.proyectox.registry.PXComponents;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import java.util.List;
import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-03 AVISPÓN — carabina de pulsos de plasma, automática (10 pulsos/s).
 * Mantener clic derecho dispara sin penalización de movimiento. El calor sube con cada pulso:
 * por encima del 60 % incendia, al 100 % se bloquea 3 s. Agachado + clic derecho: purga de calor.
 */
public class AvisponItem extends PXWeapon implements AutoFire {
    public static final float HEAT_PER_SHOT = 2.75F;
    public static final int LOCK_TICKS = 60;
    public static final float IGNITE_HEAT = 60.0F;

    public AvisponItem(Properties properties) {
        super("avispon", "PX-03", 0x96FF28, properties);
    }

    @Override
    public int maxCharge() {
        return 40;
    }

    @Override
    public int regenTicks() {
        return 3;
    }

    // ------------------------------------------------------------------ calor

    public boolean overheated(ItemStack stack, long now) {
        return now < stack.getOrDefault(PXComponents.READY_AT.get(), 0L);
    }

    /** Calor actual 0–100: durante el bloqueo baja de forma lineal; si no, se disipa tras 0,5 s sin disparar. */
    public float heat(ItemStack stack, long now) {
        long lockEnd = stack.getOrDefault(PXComponents.READY_AT.get(), 0L);
        if (now < lockEnd) return 100.0F * (lockEnd - now) / LOCK_TICKS;
        int stored = stack.getOrDefault(PXComponents.HEAT.get(), 0);
        long stamp = stack.getOrDefault(PXComponents.HEAT_STAMP.get(), now);
        long idle = Math.max(0L, now - stamp - 10L);
        return Math.max(0.0F, stored / 10.0F - idle * 2.0F);
    }

    private static void setHeat(ItemStack stack, long now, float heat) {
        stack.set(PXComponents.HEAT.get(), Math.round(heat * 10.0F));
        stack.set(PXComponents.HEAT_STAMP.get(), now);
    }

    // ------------------------------------------------------------------ disparo automático

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        // "selected" también es true para la mano izquierda cuando está elegida la ranura 0: se exige la mano principal
        if (selected && !level.isClientSide && entity instanceof ServerPlayer player && level instanceof ServerLevel server
                && player.getMainHandItem() == stack) {
            long now = level.getGameTime();
            if (PXNetwork.triggerHeld(player, now)) triggerTick(player, stack, server, now);
        }
    }

    @Override
    public void triggerTick(ServerPlayer player, ItemStack stack, ServerLevel level, long now) {
        if (now % 2L != 0L || player.getCooldowns().isOnCooldown(this) || player.isSpectator()) return;
        if (overheated(stack, now)) {
            if (now % 10L == 0L) FX.sound(level, player, PXSounds.VACIO.get(), 0.5F, 0.6F);
            return;
        }
        if (!consume(stack, now, 1, 10)) {
            if (now % 8L == 0L) emptyClick(level, player, "message.proyectox.camara_vacia");
            return;
        }
        float heat = heat(stack, now) + HEAT_PER_SHOT;
        boolean incendiary = heat > IGNITE_HEAT;
        if (heat >= 100.0F) {
            stack.set(PXComponents.READY_AT.get(), now + LOCK_TICKS);
            setHeat(stack, now + LOCK_TICKS, 0.0F);
            FX.sound(level, player, PXSounds.AVISPON_SOBRECALOR.get(), 1.0F, 1.0F);
            FX.burst(level, ParticleTypes.CLOUD, Aim.muzzle(player, 0.6, 0.3, 0.25), 10, 0.2, 0.04);
            player.displayClientMessage(Component.translatable("message.proyectox.avispon.sobrecalentado").withStyle(ChatFormatting.RED), true);
        } else {
            setHeat(stack, now, heat);
        }

        Vec3 muzzle = Aim.muzzle(player, 0.95, 0.27, 0.22);
        Vec3 dir = Aim.spread(Aim.converge(player, muzzle, 64.0), level.random, 1.1);
        PlasmaBolt bolt = PlasmaBolt.create(level, player, muzzle, dir.scale(4.0), 3.5F, incendiary);
        level.addFreshEntity(bolt);
        level.sendParticles(incendiary ? ParticleTypes.FLAME : ParticleTypes.ELECTRIC_SPARK, muzzle.x, muzzle.y, muzzle.z, 2, 0.03, 0.03, 0.03, 0.02);
        FX.sound(level, player, PXSounds.AVISPON_DISPARO.get(), 0.55F, 0.9F + level.random.nextFloat() * 0.2F + heat * 0.003F);
    }

    // ------------------------------------------------------------------ purga de calor

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        // sin agacharse, el clic derecho lo gestiona el gatillo automático
        if (!player.isSecondaryUseActive()) return InteractionResultHolder.fail(stack);
        long now = level.getGameTime();
        float heat = heat(stack, now);
        if (heat < 10.0F) {
            emptyClick(level, player, "message.proyectox.avispon.sin_calor");
            return InteractionResultHolder.fail(stack);
        }
        if (level instanceof ServerLevel server) purge(server, player, heat);
        stack.set(PXComponents.READY_AT.get(), 0L);
        setHeat(stack, now, 0.0F);
        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public boolean guardsInteractions() {
        return true;
    }

    @Override
    public net.minecraft.world.InteractionResult onItemUseFirst(ItemStack stack, net.minecraft.world.item.context.UseOnContext context) {
        Player player = context.getPlayer();
        if (player == null) return net.minecraft.world.InteractionResult.PASS;
        // agachado → la purga sigue el flujo normal; de pie → no interactuar con bloques mientras se dispara
        return player.isSecondaryUseActive() ? net.minecraft.world.InteractionResult.PASS : net.minecraft.world.InteractionResult.FAIL;
    }

    private void purge(ServerLevel level, Player player, float heat) {
        float k = heat / 100.0F;
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        DamageSource source = PXDamage.source(level, PXDamage.PURGA, player, player);
        for (LivingEntity e : Aim.cone(level, player, eye, look, 5.0, 40.0)) {
            e.invulnerableTime = 0;
            e.hurt(source, 3.0F + 13.0F * k);
            e.igniteForSeconds(2.0F + 4.0F * k);
            e.knockback(0.6 + 0.9 * k, -look.x, -look.z);
        }
        for (int i = 0; i < 40; i++) {
            Vec3 d = Aim.spread(look, level.random, 28.0);
            double speed = 0.25 + level.random.nextDouble() * 0.35;
            Vec3 p = eye.add(look.scale(0.8)).add(0, -0.25, 0);
            level.sendParticles(i % 3 == 0 ? ParticleTypes.FLAME : ParticleTypes.CLOUD, p.x, p.y, p.z, 0, d.x, d.y, d.z, speed);
        }
        FX.burst(level, FX.dust(0x96FF28, 1.4F), eye.add(look.scale(2.5)), 30, 1.0, 0.05);
        FX.sound(level, player, PXSounds.AVISPON_PURGA.get(), 1.0F, 1.2F - 0.4F * k);
    }

    // ------------------------------------------------------------------ presentación

    @Override
    protected void appendStatus(ItemStack stack, long now, List<Component> lines) {
        super.appendStatus(stack, now, lines);
        float heat = heat(stack, now);
        ChatFormatting tone = overheated(stack, now) ? ChatFormatting.RED : heat > IGNITE_HEAT ? ChatFormatting.GOLD : ChatFormatting.GRAY;
        lines.add(Component.translatable("tooltip.proyectox.avispon.calor", String.format(Locale.ROOT, "%.0f", heat)).withStyle(tone));
    }

    @Override
    public int getBarColor(ItemStack stack) {
        long now = com.proyectox.util.Times.client();
        float heat = heat(stack, now);
        if (overheated(stack, now)) return 0xFF3020;
        if (heat > IGNITE_HEAT) return 0xFFB020;
        return color();
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        long now = com.proyectox.util.Times.client();
        return super.isBarVisible(stack) || heat(stack, now) > 1.0F;
    }
}
