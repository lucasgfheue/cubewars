package com.proyectox.item;

import com.proyectox.entity.Singularity;
import com.proyectox.registry.PXComponents;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * PX-05 VÓRTICE — proyector gravitacional.
 * Clic derecho: lanza una singularidad lenta que abre un vórtice de 3 s y colapsa.
 * Agachado + clic derecho apuntando a un bloque (32 m): el ancla te lanza hacia él y anula
 * el daño por caída durante 3 s. Recarga del ancla: 6 s.
 */
public class VorticeItem extends PXWeapon {
    public static final double ANCHOR_RANGE = 32.0;
    public static final int ANCHOR_COOLDOWN = 120;
    private static final Map<UUID, Long> FALL_GUARD = new ConcurrentHashMap<>();

    public VorticeItem(Properties properties) {
        super("vortice", "PX-05", 0xAA5AFF, properties);
    }

    @Override
    public int maxCharge() {
        return 3;
    }

    @Override
    public int regenTicks() {
        return 160;
    }

    @Override
    protected boolean guardsBlocks() {
        return true;
    }

    /** El ancla protege de la caída hasta este tick. */
    public static boolean fallProtected(Entity entity) {
        Long until = FALL_GUARD.get(entity.getUUID());
        if (until == null) return false;
        if (entity.level().getGameTime() > until) {
            FALL_GUARD.remove(entity.getUUID());
            return false;
        }
        return true;
    }

    public static void forget(Player player) {
        FALL_GUARD.remove(player.getUUID());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        return player.isSecondaryUseActive() ? anchor(level, player, stack) : launch(level, player, stack);
    }

    private InteractionResultHolder<ItemStack> launch(Level level, Player player, ItemStack stack) {
        long now = level.getGameTime();
        if (charge(stack, now) <= 0) {
            emptyClick(level, player, "message.proyectox.vortice.sin_nucleo");
            return InteractionResultHolder.fail(stack);
        }
        if (level instanceof ServerLevel server) {
            consume(stack, now, 1, 0);
            Vec3 muzzle = Aim.muzzle(player, 0.9, 0.25, 0.2);
            Vec3 dir = Aim.converge(player, muzzle, 48.0);
            server.addFreshEntity(Singularity.create(server, player, muzzle, dir.scale(0.75)));
            FX.burst(server, ParticleTypes.REVERSE_PORTAL, muzzle, 14, 0.1, 0.05);
            FX.sound(level, player, PXSounds.VORTICE_DISPARO.get(), 1.0F, 0.9F + level.random.nextFloat() * 0.2F);
        }
        player.getCooldowns().addCooldown(this, 12);
        return InteractionResultHolder.consume(stack);
    }

    private InteractionResultHolder<ItemStack> anchor(Level level, Player player, ItemStack stack) {
        long now = level.getGameTime();
        long ready = stack.getOrDefault(PXComponents.READY_AT.get(), 0L);
        if (now < ready) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.translatable("message.proyectox.vortice.ancla_recarga",
                        String.format(Locale.ROOT, "%.1f", (ready - now) / 20.0)).withStyle(ChatFormatting.LIGHT_PURPLE), true);
            }
            return InteractionResultHolder.fail(stack);
        }
        HitResult hit = player.pick(ANCHOR_RANGE, 1.0F, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            emptyClick(level, player, "message.proyectox.vortice.sin_superficie");
            return InteractionResultHolder.fail(stack);
        }
        Vec3 target = hit.getLocation();
        Vec3 delta = target.subtract(player.getEyePosition());
        double dist = delta.length();
        Vec3 velocity = delta.normalize().scale(Math.min(3.0, 0.8 + dist * 0.085)).add(0.0, 0.22, 0.0);
        // el jugador controla su propio movimiento: se aplica en ambos lados para que responda al instante
        player.setDeltaMovement(velocity);
        player.resetFallDistance();
        if (level instanceof ServerLevel server) {
            player.hurtMarked = true;
            FALL_GUARD.put(player.getUUID(), now + 60L);
            stack.set(PXComponents.READY_AT.get(), now + ANCHOR_COOLDOWN);
            FX.line(server, ParticleTypes.REVERSE_PORTAL, player.getEyePosition().add(0, -0.3, 0), target, 0.7, 0.05);
            FX.burst(server, FX.dust(0xAA5AFF, 1.5F), target, 16, 0.3, 0.02);
            FX.sound(level, player, PXSounds.VORTICE_ANCLA.get(), 1.0F, 1.0F);
        }
        return InteractionResultHolder.consume(stack);
    }

    @Override
    protected void appendStatus(ItemStack stack, long now, List<Component> lines) {
        super.appendStatus(stack, now, lines);
        long ready = stack.getOrDefault(PXComponents.READY_AT.get(), 0L);
        if (now < ready) {
            lines.add(Component.translatable("tooltip.proyectox.vortice.ancla",
                    String.format(Locale.ROOT, "%.1f", (ready - now) / 20.0)).withStyle(ChatFormatting.DARK_PURPLE));
        } else {
            lines.add(Component.translatable("tooltip.proyectox.vortice.ancla_lista").withStyle(ChatFormatting.DARK_PURPLE));
        }
    }
}
