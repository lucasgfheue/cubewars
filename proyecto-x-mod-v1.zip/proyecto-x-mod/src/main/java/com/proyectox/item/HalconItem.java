package com.proyectox.item;

import com.proyectox.entity.Drone;
import com.proyectox.registry.PXComponents;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import com.proyectox.util.Times;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * PX-13 HALCÓN — dron de combate desplegable.
 * Clic derecho: despliega el dron (o marca un objetivo si ya vuela). Agachado + clic derecho: lo retira.
 */
public class HalconItem extends PXWeapon {
    public HalconItem(Properties properties) {
        super("halcon", "PX-13", 0xFFB13B, properties);
    }

    @Override
    public int maxCharge() {
        return 30;
    }

    @Override
    public int regenTicks() {
        return 40;
    }

    @Override
    protected boolean guardsBlocks() {
        return true;
    }

    @Nullable
    public static Drone deployed(ItemStack stack, Level level, Player player) {
        Integer id = stack.get(PXComponents.LINK.get());
        if (id == null) return null;
        Entity e = level.getEntity(id);
        return e instanceof Drone d && d.isAlive() && (level.isClientSide || d.owner() == player) ? d : null;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        long now = level.getGameTime();
        Drone drone = deployed(stack, level, player);
        if (player.isSecondaryUseActive()) {
            if (drone == null) {
                emptyClick(level, player, "message.proyectox.halcon.sin_dron");
                return InteractionResultHolder.fail(stack);
            }
            if (level instanceof ServerLevel server) {
                int refund = drone.remainingTicks() / 20;
                FX.burst(server, net.minecraft.core.particles.ParticleTypes.POOF, drone.position(), 8, 0.2, 0.02);
                drone.discard();
                stack.remove(PXComponents.LINK.get());
                setCharge(stack, now, Math.min(maxCharge(), refund), 0);
                FX.sound(level, player, PXSounds.HALCON_RETIRADA.get(), 1.0F, 1.0F);
            }
            return InteractionResultHolder.consume(stack);
        }
        if (drone != null) {
            if (level instanceof ServerLevel server) {
                Aim.Ray ray = Aim.pierce(server, player, player.getEyePosition(), player.getLookAngle(), 32.0, 1);
                if (!ray.hits().isEmpty() && ray.hits().get(0) instanceof LivingEntity target) {
                    drone.mark(target);
                    target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, false, false), player);
                    player.displayClientMessage(Component.translatable("message.proyectox.halcon.marcado").withColor(color()), true);
                    FX.sound(level, player, PXSounds.COLMENA_FIJAR.get(), 0.7F, 1.4F);
                } else {
                    player.displayClientMessage(Component.translatable("message.proyectox.halcon.sin_objetivo").withStyle(ChatFormatting.YELLOW), true);
                }
            }
            player.getCooldowns().addCooldown(this, 6);
            return InteractionResultHolder.consume(stack);
        }
        int seconds = charge(stack, now);
        if (seconds < 5) {
            emptyClick(level, player, "message.proyectox.halcon.bateria_baja");
            return InteractionResultHolder.fail(stack);
        }
        if (level instanceof ServerLevel server) {
            int life = seconds * 20;
            Drone d = Drone.create(server, player, life);
            server.addFreshEntity(d);
            stack.set(PXComponents.LINK.get(), d.getId());
            setCharge(stack, now, 0, life);
            FX.sound(level, player, PXSounds.HALCON_DESPLIEGUE.get(), 1.0F, 1.0F);
        }
        player.getCooldowns().addCooldown(this, 10);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    protected void appendStatus(ItemStack stack, long now, List<Component> lines) {
        lines.add(Component.translatable("tooltip.proyectox.halcon.carga", charge(stack, now), maxCharge()).withColor(color()));
        if (stack.get(PXComponents.LINK.get()) != null && Times.shiftDown()) {
            lines.add(Component.translatable("tooltip.proyectox.halcon.desplegado").withStyle(ChatFormatting.GOLD));
        }
    }
}
