package com.proyectox.item;

import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-17 ECO — cañón sónico. Mantener 1 s y soltar: onda que atraviesa bloques e ignora armadura.
 */
public class EcoItem extends PXWeapon {
    public static final int CHARGE_TICKS = 20;
    public static final double RANGE = 24.0;

    public EcoItem(Properties properties) {
        super("eco", "PX-17", 0xE6BEFF, properties);
    }

    @Override
    public int maxCharge() {
        return 3;
    }

    @Override
    public int regenTicks() {
        return 120;
    }

    @Override
    protected boolean guardsBlocks() {
        return true;
    }

    public static float chargeFraction(int ticks) {
        return Mth.clamp(ticks / (float) CHARGE_TICKS, 0.0F, 1.0F);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (charge(stack, level.getGameTime()) <= 0) {
            emptyClick(level, player, "message.proyectox.resonador_vacio");
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        if (!level.isClientSide) FX.sound(level, player, PXSounds.ECO_CARGA.get(), 0.9F, 1.0F);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        int used = getUseDuration(stack, entity) - remaining;
        if (!level.isClientSide && used == CHARGE_TICKS) FX.sound(level, entity, PXSounds.LISTO.get(), 0.7F, 0.7F);
        if (level.isClientSide && used % 3 == 0) {
            Vec3 m = Aim.muzzle(entity, 1.0, 0.25, 0.15);
            level.addParticle(ParticleTypes.REVERSE_PORTAL, m.x, m.y, m.z, 0.0, 0.0, 0.0);
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        int used = getUseDuration(stack, entity) - timeLeft;
        if (used < CHARGE_TICKS || !(level instanceof ServerLevel server)) return;
        long now = level.getGameTime();
        if (!consume(stack, now, 1, 0)) return;
        Vec3 eye = entity.getEyePosition();
        Vec3 dir = entity.getLookAngle();
        Vec3 end = eye.add(dir.scale(RANGE));
        DamageSource source = PXDamage.source(server, PXDamage.SONICO, entity, entity);
        for (LivingEntity e : Aim.segment(server, entity, eye, end, 1.2)) {
            if (entity.isAlliedTo(e)) continue;
            e.invulnerableTime = 0;
            e.hurt(source, 10.0F);
            e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 1), entity);
            e.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0), entity);
            e.knockback(1.2, -dir.x, -dir.z);
        }
        Vec3 muzzle = Aim.muzzle(entity, 1.2, 0.25, 0.15);
        Vec3 d = end.subtract(muzzle);
        int n = (int) (d.length() / 1.6);
        for (int i = 1; i <= n; i++) {
            Vec3 p = muzzle.add(d.scale(i / (double) n));
            server.sendParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
        FX.sound(level, entity, PXSounds.ECO_ONDA.get(), 2.0F, 1.0F);
        if (entity instanceof Player player) player.getCooldowns().addCooldown(this, 20);
    }
}
