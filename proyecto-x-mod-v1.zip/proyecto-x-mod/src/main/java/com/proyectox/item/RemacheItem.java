package com.proyectox.item;

import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import com.proyectox.util.FallGuard;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-10 REMACHE — escopeta de remaches magnéticos.
 * 8 remaches de 3 de daño; 4+ impactos en el mismo enemigo lo clavan. Agachado: salto de retroceso.
 */
public class RemacheItem extends PXWeapon {
    public RemacheItem(Properties properties) {
        super("remache", "PX-10", 0xC88B4A, properties);
    }

    @Override
    public int maxCharge() {
        return 6;
    }

    @Override
    public int regenTicks() {
        return 40;
    }

    @Override
    protected boolean guardsBlocks() {
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        long now = level.getGameTime();
        boolean jump = player.isSecondaryUseActive();
        int cost = jump ? 2 : 1;
        if (charge(stack, now) < cost) {
            emptyClick(level, player, "message.proyectox.tambor_vacio");
            return InteractionResultHolder.fail(stack);
        }
        Vec3 look = player.getLookAngle();
        if (jump) {
            Vec3 v = look.scale(-1.7).add(0, 0.25, 0);
            player.setDeltaMovement(v);
            player.resetFallDistance();
        }
        if (level instanceof ServerLevel server) {
            consume(stack, now, cost, 0);
            Vec3 muzzle = Aim.muzzle(player, 1.0, 0.28, 0.22);
            if (jump) {
                player.hurtMarked = true;
                FallGuard.protect(player, 60);
                FX.burst(server, ParticleTypes.EXPLOSION, muzzle, 1, 0.0, 0.0);
            } else {
                blast(server, player, muzzle);
            }
            FX.burst(server, ParticleTypes.LARGE_SMOKE, muzzle, 6, 0.1, 0.03);
            FX.sound(level, player, PXSounds.REMACHE_DISPARO.get(), 1.2F, jump ? 0.7F : 0.9F + level.random.nextFloat() * 0.15F);
        }
        player.getCooldowns().addCooldown(this, 14);
        return InteractionResultHolder.consume(stack);
    }

    private void blast(ServerLevel level, Player player, Vec3 muzzle) {
        Vec3 eye = player.getEyePosition();
        Vec3 aim = player.getLookAngle();
        DamageSource source = PXDamage.source(level, PXDamage.REMACHE, player, player);
        Map<LivingEntity, Integer> count = new HashMap<>();
        for (int i = 0; i < 8; i++) {
            Vec3 dir = Aim.spread(aim, level.random, 7.0);
            Aim.Ray ray = Aim.pierce(level, player, eye, dir, 12.0, 1);
            Vec3 end = ray.end();
            for (Entity e : ray.hits()) {
                if (!(e instanceof LivingEntity target)) continue;
                end = target.getBoundingBox().getCenter();
                double dist = eye.distanceTo(end);
                target.invulnerableTime = 0;
                if (target.hurt(source, dist > 6.0 ? 1.5F : 3.0F)) count.merge(target, 1, Integer::sum);
            }
            FX.line(level, ParticleTypes.CRIT, muzzle, end, 1.1, 0.02);
        }
        for (Map.Entry<LivingEntity, Integer> en : count.entrySet()) {
            if (en.getValue() >= 4) {
                LivingEntity t = en.getKey();
                t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 2), player);
                FX.burst(level, FX.dust(0xC88B4A, 1.3F), t.position().add(0, 0.2, 0), 14, 0.4, 0.02);
            }
        }
    }
}
