package com.proyectox.item;

import com.proyectox.entity.SlashWave;
import com.proyectox.registry.PXComponents;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.FX;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-06 CIZALLA — hoja de vibroenergía.
 * Espada rápida. Clic derecho: tajo de media luna que atraviesa. Cada 3.er golpe seguido: vibrocorte.
 */
public class CizallaItem extends PXWeapon {
    public CizallaItem(Properties properties) {
        super("cizalla", "PX-06", 0xFF2E7E, properties);
    }

    public static ItemAttributeModifiers attributes() {
        return ItemAttributeModifiers.builder()
                .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_ID, 8.0, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_ID, -2.4, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .build();
    }

    @Override
    public int maxCharge() {
        return 4;
    }

    @Override
    public int regenTicks() {
        return 80;
    }

    @Override
    protected boolean chargeBar() {
        return false;
    }

    @Override
    public int getEnchantmentValue() {
        return 15;
    }

    @Override
    public boolean isValidRepairItem(ItemStack stack, ItemStack repairCandidate) {
        return repairCandidate.is(Items.NETHERITE_INGOT);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        Level level = attacker.level();
        if (level instanceof ServerLevel server) {
            long now = level.getGameTime();
            long last = stack.getOrDefault(PXComponents.HEAT_STAMP.get(), -1000L);
            int combo = now - last <= 40L ? stack.getOrDefault(PXComponents.HEAT.get(), 0) + 1 : 1;
            if (combo >= 3) {
                // Vibrocorte: daño extra que ignora la armadura
                target.invulnerableTime = 0;
                target.hurt(PXDamage.source(server, PXDamage.VIBROCORTE, attacker, attacker), 4.0F);
                FX.burst(server, ParticleTypes.ENCHANTED_HIT, target.getBoundingBox().getCenter(), 14, 0.3, 0.3);
                FX.burst(server, FX.dust(0xFF2E7E, 1.3F), target.getBoundingBox().getCenter(), 10, 0.35, 0.05);
                FX.sound(level, target, PXSounds.CIZALLA_VIBRO.get(), 1.0F, 1.4F);
                combo = 0;
            }
            stack.set(PXComponents.HEAT.get(), combo);
            stack.set(PXComponents.HEAT_STAMP.get(), now);
        }
        return true;
    }

    @Override
    public void postHurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        stack.hurtAndBreak(1, attacker, EquipmentSlot.MAINHAND);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        long now = level.getGameTime();
        if (charge(stack, now) <= 0) {
            emptyClick(level, player, "message.proyectox.cizalla.sin_carga");
            return InteractionResultHolder.fail(stack);
        }
        if (level instanceof ServerLevel server) {
            consume(stack, now, 1, 0);
            Vec3 look = player.getLookAngle();
            Vec3 pos = player.getEyePosition().add(look.scale(0.7)).add(0, -0.35, 0);
            server.addFreshEntity(SlashWave.create(server, player, pos, look.scale(1.6)));
            FX.sound(level, player, PXSounds.CIZALLA_TAJO.get(), 1.0F, 0.9F + level.random.nextFloat() * 0.2F);
        }
        player.getCooldowns().addCooldown(this, 10);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    protected void appendStatus(ItemStack stack, long now, List<Component> lines) {
        lines.add(Component.translatable("tooltip.proyectox.cizalla.carga", charge(stack, now), maxCharge()).withColor(color()));
        int combo = now - stack.getOrDefault(PXComponents.HEAT_STAMP.get(), -1000L) <= 40L ? stack.getOrDefault(PXComponents.HEAT.get(), 0) : 0;
        if (combo > 0) lines.add(Component.translatable("tooltip.proyectox.cizalla.combo", combo).withStyle(ChatFormatting.LIGHT_PURPLE));
    }
}
