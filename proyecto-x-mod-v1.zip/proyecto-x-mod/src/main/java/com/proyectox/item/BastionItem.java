package com.proyectox.item;

import com.proyectox.ProyectoX;
import com.proyectox.registry.PXComponents;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.ItemAbilities;
import net.neoforged.neoforge.common.ItemAbility;

/**
 * PX-18 BASTIÓN — escudo de energía de asalto.
 * Bloquea como un escudo; cada golpe bloqueado carga el acumulador cinético.
 * Agachado + clic derecho con 30+ de carga: pulso cinético en cono.
 */
public class BastionItem extends PXWeapon {
    public static final int MIN_PULSE = 30;

    public BastionItem(Properties properties) {
        super("bastion", "PX-18", 0xFFD8B1, properties);
    }

    public static ItemAttributeModifiers attributes() {
        return ItemAttributeModifiers.builder()
                .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_ID, 5.0, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_ID, -3.0, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .add(Attributes.MOVEMENT_SPEED, new AttributeModifier(ProyectoX.id("bastion_peso"), -0.15, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                        EquipmentSlotGroup.HAND)
                .build();
    }

    @Override
    public int maxCharge() {
        return 100;
    }

    @Override
    public int initialCharge() {
        return 0;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BLOCK;
    }

    @Override
    public boolean canPerformAction(ItemStack stack, ItemAbility ability) {
        return ItemAbilities.DEFAULT_SHIELD_ACTIONS.contains(ability);
    }

    /** Llamado desde el evento de bloqueo: la energía del impacto se almacena. */
    public void absorb(ItemStack stack, LivingEntity holder, float blocked) {
        long now = holder.level().getGameTime();
        int add = Math.max(4, Math.round(blocked * 4.0F));
        int before = charge(stack, now);
        int after = Math.min(maxCharge(), before + add);
        stack.set(PXComponents.CHARGE.get(), after);
        stack.set(PXComponents.STAMP.get(), now);
        if (holder instanceof Player p) {
            p.displayClientMessage(Component.translatable("message.proyectox.bastion.carga", after).withColor(color()), true);
        }
        if (before < MIN_PULSE && after >= MIN_PULSE) FX.sound(holder.level(), holder, PXSounds.LISTO.get(), 0.8F, 1.0F);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        long now = level.getGameTime();
        if (player.isSecondaryUseActive() && charge(stack, now) >= MIN_PULSE) {
            if (level instanceof ServerLevel server) pulse(server, player, stack, charge(stack, now));
            stack.set(PXComponents.CHARGE.get(), 0);
            stack.set(PXComponents.STAMP.get(), now);
            player.getCooldowns().addCooldown(this, 20);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    private void pulse(ServerLevel level, Player player, ItemStack stack, int charge) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        DamageSource source = PXDamage.source(level, PXDamage.CINETICO, player, player);
        float dmg = 4.0F + charge * 0.12F;
        double kb = 1.2 + charge / 100.0;
        for (LivingEntity e : Aim.cone(level, player, eye, look, 6.0, 50.0)) {
            if (player.isAlliedTo(e)) continue;
            e.invulnerableTime = 0;
            e.hurt(source, dmg);
            e.knockback(kb, -look.x, -look.z);
            e.setDeltaMovement(e.getDeltaMovement().add(0, 0.35, 0));
            e.hurtMarked = true;
        }
        for (int i = 0; i < 30; i++) {
            Vec3 d = Aim.spread(look, level.random, 40.0);
            Vec3 p = eye.add(look.scale(0.8));
            level.sendParticles(ParticleTypes.CLOUD, p.x, p.y, p.z, 0, d.x, d.y, d.z, 0.6 + level.random.nextDouble() * 0.4);
        }
        FX.burst(level, FX.dust(0xFFD8B1, 1.8F), eye.add(look.scale(2.5)), 30, 1.2, 0.05);
        FX.sound(level, player, PXSounds.BASTION_PULSO.get(), 1.4F, 1.0F);
    }

    @Override
    protected void appendStatus(ItemStack stack, long now, List<Component> lines) {
        lines.add(Component.translatable("tooltip.proyectox.bastion.carga", charge(stack, now), maxCharge()).withColor(color()));
    }
}
