package com.proyectox.item;

import com.proyectox.entity.SawDisc;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-20 SIERRA — lanzadiscos de sierra. Discos que rebotan 3 veces y atraviesan enemigos.
 * Agachado + clic derecho: los discos vuelven cortando y devuelven su carga.
 */
public class SierraItem extends PXWeapon {
    public SierraItem(Properties properties) {
        super("sierra", "PX-20", 0x2EE6A0, properties);
    }

    @Override
    public int maxCharge() {
        return 3;
    }

    @Override
    public int regenTicks() {
        return 60;
    }

    @Override
    protected boolean guardsBlocks() {
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        long now = level.getGameTime();
        if (player.isSecondaryUseActive()) {
            if (level instanceof ServerLevel server && SawDisc.recallAll(server, player) == 0) {
                player.displayClientMessage(Component.translatable("message.proyectox.sierra.sin_discos").withStyle(ChatFormatting.YELLOW), true);
            }
            player.getCooldowns().addCooldown(this, 10);
            return InteractionResultHolder.consume(stack);
        }
        if (charge(stack, now) <= 0) {
            emptyClick(level, player, "message.proyectox.forja_vacia");
            return InteractionResultHolder.fail(stack);
        }
        if (level instanceof ServerLevel server) {
            consume(stack, now, 1, 0);
            Vec3 muzzle = Aim.muzzle(player, 1.0, 0.25, 0.15);
            Vec3 dir = Aim.converge(player, muzzle, 48.0);
            server.addFreshEntity(SawDisc.create(server, player, muzzle, dir.scale(1.4)));
            FX.sound(level, player, PXSounds.SIERRA_LANZAR.get(), 1.0F, 1.0F + level.random.nextFloat() * 0.2F);
        }
        player.getCooldowns().addCooldown(this, 8);
        return InteractionResultHolder.consume(stack);
    }
}
