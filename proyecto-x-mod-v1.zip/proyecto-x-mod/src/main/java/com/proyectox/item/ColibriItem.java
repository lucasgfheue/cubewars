package com.proyectox.item;

import com.proyectox.ProyectoX;
import com.proyectox.entity.EnergyBolt;
import com.proyectox.network.PXNetwork;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-19 COLIBRÍ — subfusil de agujas. Automático (≈13 agujas/s); cada 5 agujas en el mismo objetivo: veneno.
 */
public class ColibriItem extends PXWeapon implements AutoFire {
    public ColibriItem(Properties properties) {
        super("colibri", "PX-19", 0xFF8FD0, properties);
    }

    public static ItemAttributeModifiers attributes() {
        return ItemAttributeModifiers.builder()
                .add(Attributes.MOVEMENT_SPEED, new AttributeModifier(ProyectoX.id("colibri_ligera"), 0.10, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                        EquipmentSlotGroup.MAINHAND)
                .build();
    }

    @Override
    public int maxCharge() {
        return 60;
    }

    @Override
    public int regenTicks() {
        return 1;
    }

    @Override
    public boolean guardsInteractions() {
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return InteractionResultHolder.fail(player.getItemInHand(hand));
    }

    @Override
    public InteractionResult onItemUseFirst(ItemStack stack, UseOnContext context) {
        return context.getPlayer() == null ? InteractionResult.PASS : InteractionResult.FAIL;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (selected && level instanceof ServerLevel server && entity instanceof ServerPlayer player && player.getMainHandItem() == stack) {
            long now = level.getGameTime();
            if (PXNetwork.triggerHeld(player, now)) triggerTick(player, stack, server, now);
        }
    }

    @Override
    public void triggerTick(ServerPlayer player, ItemStack stack, ServerLevel level, long now) {
        if (player.isSpectator() || now % 3 == 0) return;
        if (!consume(stack, now, 1, 15)) {
            if (now % 8 == 1) emptyClick(level, player, "message.proyectox.cargador_vacio");
            return;
        }
        Vec3 muzzle = Aim.muzzle(player, 1.0, 0.24, 0.2);
        Vec3 dir = Aim.spread(Aim.converge(player, muzzle, 48.0), level.random, 2.5);
        level.addFreshEntity(EnergyBolt.create(level, player, EnergyBolt.NEEDLE, muzzle, dir.scale(3.6), 1.5F, 20.0, 16));
        FX.sound(level, player, PXSounds.COLIBRI_DISPARO.get(), 0.4F, 1.6F + level.random.nextFloat() * 0.3F);
    }
}
