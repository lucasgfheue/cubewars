package com.proyectox.item;

import com.proyectox.entity.Grenade;
import com.proyectox.network.PXNetwork;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-15 SOPLETE — lanzallamas de plasma. Automático: chorro de 7 bloques. Agachado + clic derecho: napalm.
 */
public class SopleteItem extends PXWeapon implements AutoFire {
    public SopleteItem(Properties properties) {
        super("soplete", "PX-15", 0xFF5E1A, properties);
    }

    @Override
    public int maxCharge() {
        return 100;
    }

    @Override
    public int regenTicks() {
        return 1;
    }

    @Override
    public boolean guardsInteractions() {
        return true;
    }

    @Override
    public InteractionResult onItemUseFirst(ItemStack stack, UseOnContext context) {
        Player player = context.getPlayer();
        if (player == null) return InteractionResult.PASS;
        return player.isSecondaryUseActive() ? InteractionResult.PASS : InteractionResult.FAIL;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (selected && level instanceof ServerLevel server && entity instanceof ServerPlayer player && player.getMainHandItem() == stack) {
            long now = level.getGameTime();
            if (PXNetwork.triggerHeld(player, now)) triggerTick(player, stack, server, now);
        }
    }

    @Override
    public void triggerTick(ServerPlayer player, ItemStack stack, ServerLevel level, long now) {
        if (player.isSpectator() || player.getCooldowns().isOnCooldown(this)) return;
        if (!consume(stack, now, 1, 20)) {
            if (now % 8 == 0) emptyClick(level, player, "message.proyectox.tanque_vacio");
            return;
        }
        Vec3 muzzle = Aim.muzzle(player, 1.1, 0.28, 0.25);
        Vec3 look = player.getLookAngle();
        for (int i = 0; i < 5; i++) {
            Vec3 d = Aim.spread(look, level.random, 9.0);
            double speed = 0.45 + level.random.nextDouble() * 0.35;
            level.sendParticles(i < 4 ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.FLAME, muzzle.x, muzzle.y, muzzle.z, 0, d.x, d.y, d.z, speed);
        }
        if (now % 2 == 0) {
            DamageSource source = PXDamage.source(level, PXDamage.LLAMA, player, player);
            for (LivingEntity e : Aim.cone(level, player, player.getEyePosition(), look, 7.0, 25.0)) {
                if (player.isAlliedTo(e)) continue;
                e.invulnerableTime = 0;
                e.hurt(source, 1.5F);
                e.igniteForSeconds(4.0F);
            }
        }
        if (now % 4 == 0) FX.sound(level, player, PXSounds.SOPLETE_CHORRO.get(), 0.7F, 0.9F + level.random.nextFloat() * 0.2F);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!player.isSecondaryUseActive()) return InteractionResultHolder.fail(stack);
        long now = level.getGameTime();
        if (charge(stack, now) < 30) {
            emptyClick(level, player, "message.proyectox.tanque_vacio");
            return InteractionResultHolder.fail(stack);
        }
        if (level instanceof ServerLevel server) {
            consume(stack, now, 30, 20);
            Vec3 muzzle = Aim.muzzle(player, 1.0, 0.28, 0.2);
            Vec3 v = player.getLookAngle().scale(1.0).add(0, 0.15, 0);
            server.addFreshEntity(Grenade.create(server, player, Grenade.NAPALM, muzzle, v, 60));
            FX.sound(level, player, PXSounds.SOPLETE_NAPALM.get(), 1.0F, 1.2F);
        }
        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.consume(stack);
    }
}
