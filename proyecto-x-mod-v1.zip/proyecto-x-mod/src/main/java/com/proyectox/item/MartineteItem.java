package com.proyectox.item;

import com.proyectox.ProyectoX;
import com.proyectox.registry.PXComponents;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * PX-01 MARTINETE — mazo de ruptura hidráulico.
 * Cada golpe que conecta llena el acumulador de presión (máx. 4). Con 2 o más cargas,
 * mantener clic derecho 1 s y soltar dispara el pistón contra el suelo: onda de choque.
 */
public class MartineteItem extends PXWeapon {
    public static final int MAX_PRESSURE = 4;
    public static final int WINDUP = 20;
    private static final float RUPTURE_DAMAGE = 18.0F;

    public MartineteItem(Properties properties) {
        super("martinete", "PX-01", 0xFF9A1F, properties);
    }

    public static ItemAttributeModifiers attributes() {
        return ItemAttributeModifiers.builder()
                .add(Attributes.ATTACK_DAMAGE,
                        new AttributeModifier(BASE_ATTACK_DAMAGE_ID, 12.0, AttributeModifier.Operation.ADD_VALUE),
                        EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ATTACK_SPEED,
                        new AttributeModifier(BASE_ATTACK_SPEED_ID, -3.3, AttributeModifier.Operation.ADD_VALUE),
                        EquipmentSlotGroup.MAINHAND)
                .add(Attributes.MOVEMENT_SPEED,
                        new AttributeModifier(ProyectoX.id("martinete_peso"), -0.10, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                        EquipmentSlotGroup.MAINHAND)
                .build();
    }

    @Override
    public int maxCharge() {
        return MAX_PRESSURE;
    }

    @Override
    public int initialCharge() {
        return 0;
    }

    @Override
    protected boolean chargeBar() {
        return false;
    }

    @Override
    public int getEnchantmentValue() {
        return 14;
    }

    @Override
    public boolean isValidRepairItem(ItemStack stack, ItemStack repairCandidate) {
        return repairCandidate.is(Items.NETHERITE_INGOT);
    }

    // ------------------------------------------------------------- presión

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        Level level = attacker.level();
        if (!level.isClientSide) {
            long now = level.getGameTime();
            long last = stack.getOrDefault(PXComponents.STAMP.get(), 0L);
            // como mucho una carga por segundo: aporrear sin esperar no llena el acumulador
            if (now - last >= 16L) {
                int pressure = Math.min(MAX_PRESSURE, charge(stack, now) + 1);
                stack.set(PXComponents.CHARGE.get(), pressure);
                stack.set(PXComponents.STAMP.get(), now);
                FX.sound(level, attacker, PXSounds.MARTINETE_PRESION.get(), 0.8F, 0.8F + pressure * 0.12F);
                if (attacker instanceof Player player) player.displayClientMessage(gauge(pressure), true);
            }
        }
        return true;
    }

    @Override
    public void postHurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        stack.hurtAndBreak(1, attacker, net.minecraft.world.entity.EquipmentSlot.MAINHAND);
    }

    private static MutableComponent gauge(int pressure) {
        MutableComponent bar = Component.translatable("message.proyectox.martinete.presion").withStyle(ChatFormatting.GOLD);
        bar.append(Component.literal(" "));
        for (int i = 1; i <= MAX_PRESSURE; i++) {
            bar.append(Component.literal("■").withStyle(i <= pressure ? ChatFormatting.GOLD : ChatFormatting.DARK_GRAY));
        }
        return bar;
    }

    // ------------------------------------------------------------- golpe de ruptura

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (charge(stack, level.getGameTime()) < 2) {
            emptyClick(level, player, "message.proyectox.martinete.presion_baja");
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        if (!level.isClientSide) FX.sound(level, player, PXSounds.MARTINETE_CARGA.get(), 0.9F, 1.0F);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        int used = getUseDuration(stack, entity) - remaining;
        if (!level.isClientSide && used == WINDUP) {
            FX.sound(level, entity, PXSounds.LISTO.get(), 0.8F, 0.8F);
            if (level instanceof ServerLevel server) {
                FX.burst(server, ParticleTypes.CLOUD, entity.position().add(0, 1.0, 0), 6, 0.3, 0.02);
            }
        }
        if (level.isClientSide && used > WINDUP && used % 3 == 0) {
            Vec3 p = Aim.muzzle(entity, 0.6, 0.45, 0.1);
            level.addParticle(ParticleTypes.WHITE_SMOKE, p.x, p.y, p.z, 0.0, 0.03, 0.0);
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        int used = getUseDuration(stack, entity) - timeLeft;
        if (level.isClientSide || used < WINDUP || !(level instanceof ServerLevel server)) return;
        long now = level.getGameTime();
        int pressure = charge(stack, now);
        if (pressure < 2) return;
        rupture(server, entity, pressure);
        stack.set(PXComponents.CHARGE.get(), 0);
        stack.set(PXComponents.STAMP.get(), now);
        stack.hurtAndBreak(3, entity, LivingEntity.getSlotForHand(entity.getUsedItemHand()));
        if (entity instanceof Player player) {
            player.getCooldowns().addCooldown(this, 20);
            player.displayClientMessage(gauge(0), true);
        }
    }

    private void rupture(ServerLevel level, LivingEntity user, int pressure) {
        double radius = pressure >= MAX_PRESSURE ? 5.25 : 3.5;
        Vec3 look = user.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0, look.z);
        flat = flat.lengthSqr() < 1.0E-4 ? Vec3.ZERO : flat.normalize();
        Vec3 center = user.position().add(flat.scale(1.2));

        DamageSource source = PXDamage.source(level, PXDamage.IMPACTO, user, user);
        List<LivingEntity> victims = Aim.sphere(level, user, center.add(0, 0.8, 0), radius);
        for (LivingEntity e : victims) {
            if (user.isAlliedTo(e)) continue;
            disableShield(e);
            e.invulnerableTime = 0;
            e.hurt(source, RUPTURE_DAMAGE);
            Vec3 push = e.position().subtract(center);
            push = new Vec3(push.x, 0.0, push.z);
            push = push.lengthSqr() < 1.0E-4 ? flat : push.normalize();
            double d = e.position().distanceTo(center);
            double k = 1.15 * (1.0 - 0.5 * Math.min(1.0, d / radius));
            e.setDeltaMovement(e.getDeltaMovement().add(push.x * k, 0.55, push.z * k));
            e.hurtMarked = true;
        }

        // efectos: anillos de escombros del suelo, polvo y destello
        BlockPos ground = BlockPos.containing(center).below();
        BlockState state = level.getBlockState(ground);
        if (state.isAir()) state = level.getBlockState(ground.below());
        Vec3 floor = new Vec3(center.x, ground.getY() + 1.05, center.z);
        if (!state.isAir()) {
            BlockParticleOption debris = new BlockParticleOption(ParticleTypes.BLOCK, state);
            for (double r = 0.8; r <= radius; r += 0.9) {
                int points = (int) (r * 7);
                for (int i = 0; i < points; i++) {
                    double a = Math.PI * 2 * i / points;
                    level.sendParticles(debris, floor.x + Math.cos(a) * r, floor.y, floor.z + Math.sin(a) * r, 3, 0.15, 0.25, 0.15, 0.2);
                }
            }
        }
        FX.ring(level, ParticleTypes.CLOUD, floor, 0.6, 28, 0.45);
        FX.ring(level, ParticleTypes.POOF, floor, 1.0, 20, 0.3);
        FX.burst(level, ParticleTypes.EXPLOSION, floor.add(0, 0.4, 0), 2, 0.4, 0.0);
        FX.burst(level, FX.dust(0xFF9A1F, 1.6F), floor.add(0, 0.3, 0), 30, radius * 0.4, 0.05);
        FX.sound(level, center, PXSounds.MARTINETE_RUPTURA.get(), 1.4F, 0.9F + level.random.nextFloat() * 0.15F);
    }

    /** Desactiva los escudos del objetivo durante 5 s (100 ticks), como un hacha. */
    private static void disableShield(LivingEntity e) {
        if (!(e instanceof Player player)) return;
        boolean had = false;
        for (InteractionHand hand : InteractionHand.values()) {
            ItemStack held = player.getItemInHand(hand);
            if (held.getItem() instanceof ShieldItem) {
                player.getCooldowns().addCooldown(held.getItem(), 100);
                had = true;
            }
        }
        if (had && player.isBlocking()) {
            player.stopUsingItem();
            player.level().broadcastEntityEvent(player, (byte) 30);
        }
    }

    @Override
    protected void appendStatus(ItemStack stack, long now, List<Component> lines) {
        int p = charge(stack, now);
        lines.add(gauge(p));
    }
}
