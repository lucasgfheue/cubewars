package com.proyectox.item;

import com.proyectox.fx.Fx;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.FX;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/** PX-01 MARTINETE — mazo hidráulico: 32 de daño por golpe, sin empujar al enemigo. */
public class MartineteItem extends MeleeItem {
    public MartineteItem(Properties properties) {
        super("martinete", "PX-01", 0xFF9A1F, Fx.MARTINETE, properties);
    }

    @Override
    protected void onHit(ServerLevel level, ItemStack stack, LivingEntity target, LivingEntity attacker) {
        FX.sound(level, target, PXSounds.MARTINETE_RUPTURA.get(), 1.0F, 1.1F + level.random.nextFloat() * 0.2F);
    }
}
