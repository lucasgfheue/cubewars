package com.proyectox.item;

import com.proyectox.ProyectoX;
import com.proyectox.entity.MicroRocket;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * PX-04 COLMENA — lanzador de microcohetes.
 * Mantener clic derecho fija hasta 6 objetivos (uno cada 1,2 s); al soltar se lanzan todos los
 * cohetes disponibles. Los cohetes buscan su objetivo y priorizan a los marcados (Resplandor).
 */
public class ColmenaItem extends PXWeapon {
    public static final int LOCK_TICKS = 24;
    public static final double RANGE = 64.0;
    private static final Map<UUID, List<Integer>> LOCKS = new HashMap<>();

    public ColmenaItem(Properties properties) {
        super("colmena", "PX-04", 0xFF3C3C, properties);
    }

    public static ItemAttributeModifiers attributes() {
        return ItemAttributeModifiers.builder()
                .add(Attributes.MOVEMENT_SPEED,
                        new AttributeModifier(ProyectoX.id("colmena_peso"), -0.20, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                        EquipmentSlotGroup.MAINHAND)
                .build();
    }

    @Override
    public int maxCharge() {
        return 6;
    }

    @Override
    public int regenTicks() {
        return 40;
    }

    @Override
    protected boolean guardsBlocks() {
        return true;
    }

    public static void forget(Player player) {
        LOCKS.remove(player.getUUID());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (charge(stack, level.getGameTime()) <= 0) {
            emptyClick(level, player, "message.proyectox.colmena.sin_cohetes");
            return InteractionResultHolder.fail(stack);
        }
        if (!level.isClientSide) LOCKS.put(player.getUUID(), new ArrayList<>());
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (level.isClientSide || !(entity instanceof Player player) || !(level instanceof ServerLevel server)) return;
        int used = getUseDuration(stack, entity) - remaining;
        if (used <= 0 || used % LOCK_TICKS != 0) return;
        List<Integer> locks = LOCKS.computeIfAbsent(player.getUUID(), k -> new ArrayList<>());
        int capacity = Math.min(maxCharge(), charge(stack, level.getGameTime()));
        if (locks.size() >= capacity) return;
        LivingEntity target = findTarget(server, player, locks);
        if (target == null) return;
        locks.add(target.getId());
        target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false), player);
        FX.burst(server, FX.dust(0xFF3C3C, 1.3F), target.getBoundingBox().getCenter(), 10, 0.4, 0.02);
        FX.sound(level, player, PXSounds.COLMENA_FIJAR.get(), 0.8F, 1.0F + locks.size() * 0.1F);
        player.displayClientMessage(Component.translatable("message.proyectox.colmena.fijados", locks.size(), capacity)
                .withStyle(ChatFormatting.RED), true);
    }

    /** Mejor objetivo dentro de un cono de 14°: primero los marcados, luego los hostiles y los más centrados. */
    private static LivingEntity findTarget(ServerLevel level, Player player, List<Integer> exclude) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        AABB box = player.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(10.0);
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> Aim.targetable(player, x) && !exclude.contains(x.getId()))) {
            Vec3 c = e.getBoundingBox().getCenter();
            double dist = c.distanceTo(eye);
            if (dist > RANGE || dist < 2.0) continue;
            double angle = Aim.angleTo(eye, look, c);
            if (angle > 14.0 || !player.hasLineOfSight(e)) continue;
            double score = angle * 2.0 + dist * 0.08;
            if (e.hasEffect(MobEffects.GLOWING)) score -= 100.0;
            if (e instanceof Enemy) score -= 6.0;
            if (score < bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (level.isClientSide || !(level instanceof ServerLevel server) || !(entity instanceof Player player)) return;
        long now = level.getGameTime();
        int rockets = charge(stack, now);
        List<Integer> locks = LOCKS.remove(player.getUUID());
        if (rockets <= 0) return;
        List<LivingEntity> targets = new ArrayList<>();
        if (locks != null) {
            for (int id : locks) {
                Entity e = level.getEntity(id);
                if (e instanceof LivingEntity living && living.isAlive()) targets.add(living);
            }
        }
        setCharge(stack, now, 0, 0);

        Vec3 muzzle = Aim.muzzle(player, 0.7, 0.32, 0.05);
        Vec3 aim = Aim.converge(player, muzzle, RANGE);
        for (int i = 0; i < rockets; i++) {
            // abanico: los seis tubos se abren ligeramente y suben un poco antes de corregir
            double yaw = Math.toRadians((i - (rockets - 1) / 2.0) * 5.0);
            double pitch = Math.toRadians(4.0 + (i % 2) * 3.0);
            Vec3 dir = aim.yRot((float) yaw).add(0, Math.sin(pitch), 0).normalize();
            LivingEntity target = targets.isEmpty() ? null : targets.get(i % targets.size());
            MicroRocket rocket = MicroRocket.create(server, player, muzzle, dir.scale(0.85 + 0.05 * i), target);
            server.addFreshEntity(rocket);
        }
        FX.burst(server, ParticleTypes.LARGE_SMOKE, muzzle, 8, 0.2, 0.03);
        FX.burst(server, ParticleTypes.FLAME, muzzle, 6, 0.1, 0.05);
        FX.sound(level, player, PXSounds.COLMENA_LANZAR.get(), 1.2F, 0.9F + level.random.nextFloat() * 0.2F);
        player.getCooldowns().addCooldown(this, 10);
    }
}
