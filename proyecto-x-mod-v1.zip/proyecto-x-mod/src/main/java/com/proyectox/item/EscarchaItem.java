package com.proyectox.item;

import com.proyectox.entity.RailTrail;
import com.proyectox.network.PXNetwork;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-16 ESCARCHA — proyector criogénico. Automático: rayo que congela. Agachado + clic derecho: nova de hielo.
 */
public class EscarchaItem extends PXWeapon implements AutoFire {
    public static final double RANGE = 18.0;

    public EscarchaItem(Properties properties) {
        super("escarcha", "PX-16", 0xA8F0FF, properties);
    }

    @Override
    public int maxCharge() {
        return 100;
    }

    @Override
    public int regenTicks() {
        return 1;
    }

    @Override
    public boolean guardsInteractions() {
        return true;
    }

    @Override
    public InteractionResult onItemUseFirst(ItemStack stack, UseOnContext context) {
        Player player = context.getPlayer();
        if (player == null) return InteractionResult.PASS;
        return player.isSecondaryUseActive() ? InteractionResult.PASS : InteractionResult.FAIL;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (selected && level instanceof ServerLevel server && entity instanceof ServerPlayer player && player.getMainHandItem() == stack) {
            long now = level.getGameTime();
            if (PXNetwork.triggerHeld(player, now)) triggerTick(player, stack, server, now);
        }
    }

    private static void freeze(LivingEntity e, int amount) {
        e.setTicksFrozen(Math.min(e.getTicksFrozen() + amount, e.getTicksRequiredToFreeze() + 60));
    }

    @Override
    public void triggerTick(ServerPlayer player, ItemStack stack, ServerLevel level, long now) {
        if (player.isSpectator() || player.getCooldowns().isOnCooldown(this)) return;
        if (!consume(stack, now, 1, 20)) {
            if (now % 8 == 0) emptyClick(level, player, "message.proyectox.criotanque_vacio");
            return;
        }
        Vec3 muzzle = Aim.muzzle(player, 1.1, 0.27, 0.24);
        Aim.Ray ray = Aim.pierce(level, player, player.getEyePosition(), player.getLookAngle(), RANGE, 1);
        Vec3 end = ray.end();
        for (Entity hit : ray.hits()) {
            if (!(hit instanceof LivingEntity e)) continue;
            end = e.getBoundingBox().getCenter();
            freeze(e, 7);
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 1), player);
            if (now % 4 == 0) {
                e.invulnerableTime = 0;
                e.hurt(PXDamage.source(level, PXDamage.FRIO, player, player), 1.0F);
            }
            if (e.getTicksFrozen() >= e.getTicksRequiredToFreeze()) {
                MobEffectInstance slow = e.getEffect(MobEffects.MOVEMENT_SLOWDOWN);
                if (slow == null || slow.getAmplifier() < 6) {
                    // Congelación total: queda inmóvil 2 s
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 6), player);
                    e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 40, 2), player);
                    FX.burst(level, ParticleTypes.SNOWFLAKE, end, 30, 0.4, 0.05);
                    FX.sound(level, e, PXSounds.ESCARCHA_CONGELAR.get(), 1.0F, 1.2F);
                }
            }
        }
        if (now % 2 == 0) RailTrail.spawn(level, muzzle, end, 0xA8F0FF, 0.09F, 3);
        level.sendParticles(ParticleTypes.SNOWFLAKE, end.x, end.y, end.z, 2, 0.15, 0.15, 0.15, 0.01);
        if (now % 5 == 0) FX.sound(level, player, PXSounds.ESCARCHA_RAYO.get(), 0.5F, 1.4F + level.random.nextFloat() * 0.2F);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!player.isSecondaryUseActive()) return InteractionResultHolder.fail(stack);
        long now = level.getGameTime();
        if (charge(stack, now) < 40) {
            emptyClick(level, player, "message.proyectox.criotanque_vacio");
            return InteractionResultHolder.fail(stack);
        }
        if (level instanceof ServerLevel server) {
            consume(stack, now, 40, 20);
            Vec3 c = player.position().add(0, 1.0, 0);
            for (LivingEntity e : Aim.sphere(server, player, c, 4.0)) {
                if (player.isAlliedTo(e)) continue;
                freeze(e, 100);
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2), player);
                e.invulnerableTime = 0;
                e.hurt(PXDamage.source(server, PXDamage.FRIO, player, player), 3.0F);
                Vec3 push = e.position().subtract(player.position());
                push = push.lengthSqr() < 1.0E-4 ? Vec3.ZERO : push.normalize();
                e.setDeltaMovement(e.getDeltaMovement().add(push.x * 0.8, 0.3, push.z * 0.8));
                e.hurtMarked = true;
            }
            FX.ring(server, ParticleTypes.SNOWFLAKE, c.add(0, -0.6, 0), 0.6, 40, 0.5);
            FX.burst(server, ParticleTypes.ITEM_SNOWBALL, c, 30, 1.5, 0.1);
            FX.sound(level, player, PXSounds.ESCARCHA_NOVA.get(), 1.2F, 0.8F);
        }
        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.consume(stack);
    }
}
