package com.proyectox.item;

import com.proyectox.ProyectoX;
import com.proyectox.entity.RailTrail;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-08 SERPENTINA — látigo de cadena electrificada.
 * +2 bloques de alcance; cada golpe salta en arco a 2 enemigos. Clic derecho: latigazo que arrastra.
 */
public class SerpentinaItem extends PXWeapon {
    public SerpentinaItem(Properties properties) {
        super("serpentina", "PX-08", 0x5A7BFF, properties);
    }

    public static ItemAttributeModifiers attributes() {
        return ItemAttributeModifiers.builder()
                .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_ID, 6.0, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_ID, -2.8, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ENTITY_INTERACTION_RANGE, new AttributeModifier(ProyectoX.id("serpentina_alcance"), 2.0, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .build();
    }

    @Override
    public int maxCharge() {
        return 3;
    }

    @Override
    public int regenTicks() {
        return 100;
    }

    @Override
    protected boolean chargeBar() {
        return false;
    }

    @Override
    public int getEnchantmentValue() {
        return 15;
    }

    @Override
    public boolean isValidRepairItem(ItemStack stack, ItemStack repairCandidate) {
        return repairCandidate.is(Items.NETHERITE_INGOT);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker.level() instanceof ServerLevel level) {
            // Arco voltaico: salta a los 2 enemigos más cercanos al objetivo
            DamageSource source = PXDamage.source(level, PXDamage.ARCO, attacker, attacker);
            List<LivingEntity> near = Aim.sphere(level, attacker, target.getBoundingBox().getCenter(), 4.0);
            near.removeIf(e -> e == target || attacker.isAlliedTo(e));
            near.sort((a, b) -> Double.compare(a.distanceToSqr(target), b.distanceToSqr(target)));
            for (int i = 0; i < Math.min(2, near.size()); i++) {
                LivingEntity e = near.get(i);
                e.invulnerableTime = 0;
                e.hurt(source, 3.0F);
                RailTrail.spawn(level, target.getBoundingBox().getCenter(), e.getBoundingBox().getCenter(), 0x9DB2FF, 0.05F, 5);
                FX.burst(level, ParticleTypes.ELECTRIC_SPARK, e.getBoundingBox().getCenter(), 8, 0.2, 0.2);
            }
            if (!near.isEmpty()) FX.sound(level, target, PXSounds.SERPENTINA_ARCO.get(), 0.7F, 1.5F);
        }
        return true;
    }

    @Override
    public void postHurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        stack.hurtAndBreak(1, attacker, EquipmentSlot.MAINHAND);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        long now = level.getGameTime();
        if (charge(stack, now) <= 0) {
            emptyClick(level, player, "message.proyectox.serpentina.sin_carga");
            return InteractionResultHolder.fail(stack);
        }
        if (level instanceof ServerLevel server) {
            consume(stack, now, 1, 0);
            Vec3 eye = player.getEyePosition();
            Aim.Ray ray = Aim.pierce(server, player, eye, player.getLookAngle(), 12.0, 1);
            Vec3 hand0 = Aim.muzzle(player, 0.6, 0.35, 0.3);
            Vec3 end = ray.end();
            for (Entity e : ray.hits()) {
                if (!(e instanceof LivingEntity target)) continue;
                end = target.getBoundingBox().getCenter();
                target.invulnerableTime = 0;
                target.hurt(PXDamage.source(server, PXDamage.ARCO, player, player), 4.0F);
                Vec3 pull = player.position().subtract(target.position());
                double d = pull.length();
                pull = d < 1.0E-3 ? Vec3.ZERO : pull.normalize().scale(Math.min(1.6, 0.5 + d * 0.11));
                target.setDeltaMovement(pull.x, 0.35 + pull.y * 0.2, pull.z);
                target.hurtMarked = true;
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 3), player);
                FX.burst(server, ParticleTypes.ELECTRIC_SPARK, end, 14, 0.3, 0.3);
            }
            RailTrail.spawn(server, hand0, end, 0x5A7BFF, 0.07F, 7);
            FX.sound(level, player, PXSounds.SERPENTINA_LATIGO.get(), 1.0F, 1.0F);
        }
        player.getCooldowns().addCooldown(this, 15);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    protected void appendStatus(ItemStack stack, long now, List<Component> lines) {
        lines.add(Component.translatable("tooltip.proyectox.serpentina.carga", charge(stack, now), maxCharge()).withColor(color()));
    }
}
