package com.proyectox.item;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

/**
 * Armas automáticas: el cliente envía el estado del gatillo y el servidor dispara cada tick
 * mientras se mantiene, sin usar la mecánica de "usar objeto" (que frena al jugador un 80 %).
 */
public interface AutoFire {
    void triggerTick(ServerPlayer player, ItemStack stack, ServerLevel level, long now);
}
