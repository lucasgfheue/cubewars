package com.proyectox.item;

import com.proyectox.ProyectoX;
import com.proyectox.entity.EnergyBolt;
import com.proyectox.network.PXNetwork;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-12 ROTOR — ametralladora rotativa de energía. Automática: gira 0,75 s y dispara 20 trazadoras/s.
 */
public class RotorItem extends PXWeapon implements AutoFire {
    public static final int SPIN_UP = 15;
    private static final Map<UUID, long[]> SPIN = new HashMap<>();

    public RotorItem(Properties properties) {
        super("rotor", "PX-12", 0xB4BCC6, properties);
    }

    public static ItemAttributeModifiers attributes() {
        return ItemAttributeModifiers.builder()
                .add(Attributes.MOVEMENT_SPEED, new AttributeModifier(ProyectoX.id("rotor_peso"), -0.30, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                        EquipmentSlotGroup.MAINHAND)
                .build();
    }

    public static void forget(Player player) {
        SPIN.remove(player.getUUID());
    }

    @Override
    public int maxCharge() {
        return 200;
    }

    @Override
    public int regenTicks() {
        return 2;
    }

    @Override
    public boolean guardsInteractions() {
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return InteractionResultHolder.fail(player.getItemInHand(hand));
    }

    @Override
    public InteractionResult onItemUseFirst(ItemStack stack, UseOnContext context) {
        return context.getPlayer() == null ? InteractionResult.PASS : InteractionResult.FAIL;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (selected && level instanceof ServerLevel server && entity instanceof ServerPlayer player && player.getMainHandItem() == stack) {
            long now = level.getGameTime();
            if (PXNetwork.triggerHeld(player, now)) triggerTick(player, stack, server, now);
        }
    }

    @Override
    public void triggerTick(ServerPlayer player, ItemStack stack, ServerLevel level, long now) {
        if (player.isSpectator()) return;
        long[] s = SPIN.computeIfAbsent(player.getUUID(), k -> new long[]{0, now});
        if (now - s[1] > 3) s[0] = 0;
        s[1] = now;
        s[0]++;
        if (s[0] == 1) FX.sound(level, player, PXSounds.ROTOR_GIRO.get(), 0.9F, 1.0F);
        if (s[0] < SPIN_UP) {
            if (s[0] % 3 == 0) {
                Vec3 m = Aim.muzzle(player, 1.2, 0.3, 0.35);
                level.sendParticles(ParticleTypes.SMOKE, m.x, m.y, m.z, 1, 0.02, 0.02, 0.02, 0.0);
            }
            return;
        }
        if (!consume(stack, now, 1, 20)) {
            if (now % 8 == 0) emptyClick(level, player, "message.proyectox.cinta_vacia");
            return;
        }
        long sustained = s[0] - SPIN_UP;
        double spread = Math.max(0.8, 3.0 - sustained * 0.1);
        Vec3 muzzle = Aim.muzzle(player, 1.3, 0.3, 0.35);
        Vec3 dir = Aim.spread(Aim.converge(player, muzzle, 64.0), level.random, spread);
        level.addFreshEntity(EnergyBolt.create(level, player, EnergyBolt.TRACER, muzzle, dir.scale(4.5), 2.0F, 40.0, 18));
        if (now % 2 == 0) {
            FX.sound(level, player, PXSounds.ROTOR_DISPARO.get(), 0.5F, 1.0F + level.random.nextFloat() * 0.2F);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, muzzle.x, muzzle.y, muzzle.z, 1, 0.03, 0.03, 0.03, 0.02);
        }
    }
}
