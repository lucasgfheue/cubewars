package com.proyectox.item;

import com.proyectox.ProyectoX;
import com.proyectox.entity.Grenade;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-11 TRITURADORA — lanzagranadas de racimo.
 * Granadas que rebotan y sueltan 4 bombetas. Agachado + clic derecho: detonación remota.
 */
public class TrituradoraItem extends PXWeapon {
    public TrituradoraItem(Properties properties) {
        super("trituradora", "PX-11", 0xB7C34A, properties);
    }

    public static ItemAttributeModifiers attributes() {
        return ItemAttributeModifiers.builder()
                .add(Attributes.MOVEMENT_SPEED, new AttributeModifier(ProyectoX.id("trituradora_peso"), -0.15, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                        EquipmentSlotGroup.MAINHAND)
                .build();
    }

    @Override
    public int maxCharge() {
        return 4;
    }

    @Override
    public int regenTicks() {
        return 60;
    }

    @Override
    protected boolean guardsBlocks() {
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        long now = level.getGameTime();
        if (player.isSecondaryUseActive()) {
            if (level instanceof ServerLevel server) {
                int n = Grenade.detonateAll(server, player);
                if (n == 0) {
                    player.displayClientMessage(Component.translatable("message.proyectox.trituradora.sin_granadas").withStyle(ChatFormatting.YELLOW), true);
                }
            }
            player.getCooldowns().addCooldown(this, 10);
            return InteractionResultHolder.consume(stack);
        }
        if (charge(stack, now) <= 0) {
            emptyClick(level, player, "message.proyectox.forja_vacia");
            return InteractionResultHolder.fail(stack);
        }
        if (level instanceof ServerLevel server) {
            consume(stack, now, 1, 0);
            Vec3 muzzle = Aim.muzzle(player, 0.9, 0.3, 0.1);
            Vec3 v = player.getLookAngle().scale(1.25).add(0, 0.12, 0);
            server.addFreshEntity(Grenade.create(server, player, Grenade.GRENADE, muzzle, v, 40));
            FX.burst(server, ParticleTypes.LARGE_SMOKE, muzzle, 5, 0.08, 0.03);
            FX.sound(level, player, PXSounds.TRITURADORA_LANZAR.get(), 1.0F, 0.8F + level.random.nextFloat() * 0.15F);
        }
        player.getCooldowns().addCooldown(this, 16);
        return InteractionResultHolder.consume(stack);
    }
}
