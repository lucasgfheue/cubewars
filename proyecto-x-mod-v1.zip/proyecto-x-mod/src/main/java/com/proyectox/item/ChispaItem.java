package com.proyectox.item;

import com.proyectox.entity.RailTrail;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-09 CHISPA — pistola de arco eléctrico.
 * Descarga instantánea (5 de daño) que salta a 2 enemigos más (3 de daño). ×1,5 contra objetivos mojados.
 */
public class ChispaItem extends PXWeapon {
    public static final double RANGE = 28.0;

    public ChispaItem(Properties properties) {
        super("chispa", "PX-09", 0xFFF59A, properties);
    }

    @Override
    public int maxCharge() {
        return 12;
    }

    @Override
    public int regenTicks() {
        return 15;
    }

    @Override
    protected boolean guardsBlocks() {
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        long now = level.getGameTime();
        if (charge(stack, now) <= 0) {
            emptyClick(level, player, "message.proyectox.condensador_vacio");
            return InteractionResultHolder.fail(stack);
        }
        if (level instanceof ServerLevel server) {
            consume(stack, now, 1, 0);
            fire(server, player);
        }
        player.getCooldowns().addCooldown(this, 5);
        return InteractionResultHolder.consume(stack);
    }

    private static float wet(Entity e, float dmg) {
        return e.isInWaterOrRain() ? dmg * 1.5F : dmg;
    }

    private void fire(ServerLevel level, Player player) {
        Vec3 eye = player.getEyePosition();
        Vec3 muzzle = Aim.muzzle(player, 0.85, 0.26, 0.18);
        Aim.Ray ray = Aim.pierce(level, player, eye, Aim.spread(player.getLookAngle(), level.random, 0.6), RANGE, 1);
        DamageSource source = PXDamage.source(level, PXDamage.ARCO, player, player);
        if (ray.hits().isEmpty()) {
            RailTrail.spawn(level, muzzle, ray.end(), 0xFFF59A, 0.05F, 5);
            FX.burst(level, ParticleTypes.ELECTRIC_SPARK, ray.end(), 6, 0.1, 0.2);
        } else {
            Entity first = ray.hits().get(0);
            Set<Integer> done = new HashSet<>();
            done.add(first.getId());
            Vec3 from = first.getBoundingBox().getCenter();
            RailTrail.spawn(level, muzzle, from, 0xFFF59A, 0.06F, 5);
            first.invulnerableTime = 0;
            first.hurt(source, wet(first, 5.0F));
            FX.burst(level, ParticleTypes.ELECTRIC_SPARK, from, 12, 0.25, 0.3);
            Entity current = first;
            for (int jump = 0; jump < 2; jump++) {
                List<LivingEntity> near = Aim.sphere(level, player, current.getBoundingBox().getCenter(), 5.0);
                LivingEntity next = null;
                double best = Double.MAX_VALUE;
                for (LivingEntity e : near) {
                    if (done.contains(e.getId()) || player.isAlliedTo(e)) continue;
                    double d = e.distanceToSqr(current);
                    if (d < best) {
                        best = d;
                        next = e;
                    }
                }
                if (next == null) break;
                done.add(next.getId());
                Vec3 to = next.getBoundingBox().getCenter();
                RailTrail.spawn(level, current.getBoundingBox().getCenter(), to, 0xFFF59A, 0.045F, 5);
                next.invulnerableTime = 0;
                next.hurt(source, wet(next, 3.0F));
                FX.burst(level, ParticleTypes.ELECTRIC_SPARK, to, 8, 0.2, 0.25);
                current = next;
            }
        }
        FX.burst(level, ParticleTypes.ELECTRIC_SPARK, muzzle, 4, 0.05, 0.1);
        FX.sound(level, player, PXSounds.CHISPA_DISPARO.get(), 0.8F, 1.3F + level.random.nextFloat() * 0.3F);
    }
}
