package com.proyectox.item;

import com.proyectox.entity.RailTrail;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-02 AGUJA — fusil de riel de precisión.
 * Mantener clic derecho carga los condensadores (1,5 s). Al soltar dispara un rayo instantáneo:
 * 6–26 de daño según la carga; al 100 % atraviesa hasta 3 enemigos. Cada impacto marca 8 s.
 */
public class AgujaItem extends PXWeapon {
    public static final int FULL_CHARGE = 30;
    public static final double RANGE = 120.0;

    public AgujaItem(Properties properties) {
        super("aguja", "PX-02", 0x3CE6FF, properties);
    }

    @Override
    public int maxCharge() {
        return 5;
    }

    @Override
    public int regenTicks() {
        return 60;
    }

    @Override
    protected boolean guardsBlocks() {
        return true;
    }

    /** Fracción de carga de los condensadores tras {@code ticks} manteniendo el gatillo. */
    public static float chargeFraction(int ticks) {
        return Mth.clamp(ticks / (float) FULL_CHARGE, 0.0F, 1.0F);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (charge(stack, level.getGameTime()) <= 0) {
            emptyClick(level, player, "message.proyectox.bateria_vacia");
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        if (!level.isClientSide) FX.sound(level, player, PXSounds.AGUJA_CARGA.get(), 0.6F, 1.0F);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        int used = getUseDuration(stack, entity) - remaining;
        if (!level.isClientSide && used == FULL_CHARGE) {
            FX.sound(level, entity, PXSounds.LISTO.get(), 0.7F, 1.6F);
        }
        if (level.isClientSide && used % 2 == 0) {
            Vec3 m = Aim.muzzle(entity, 1.0, 0.26, 0.2);
            float f = chargeFraction(used);
            if (level.random.nextFloat() < 0.35F + f * 0.6F) {
                level.addParticle(ParticleTypes.ELECTRIC_SPARK, m.x, m.y, m.z,
                        (level.random.nextDouble() - 0.5) * 0.1, (level.random.nextDouble() - 0.5) * 0.1, (level.random.nextDouble() - 0.5) * 0.1);
            }
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (level.isClientSide || !(level instanceof ServerLevel server)) return;
        int used = getUseDuration(stack, entity) - timeLeft;
        float f = Math.max(0.12F, chargeFraction(used));
        long now = level.getGameTime();
        if (!consume(stack, now, 1, 0)) return;
        fire(server, entity, f);
        if (entity instanceof Player player) player.getCooldowns().addCooldown(this, 8);
    }

    private void fire(ServerLevel level, LivingEntity shooter, float f) {
        boolean full = f >= 0.999F;
        Vec3 eye = shooter.getEyePosition();
        // sin carga completa los carriles no estabilizan la aguja: hasta 4° de dispersión
        Vec3 dir = Aim.spread(shooter.getLookAngle(), level.random, (1.0 - f) * 4.0);
        Aim.Ray ray = Aim.pierce(level, shooter, eye, dir, RANGE, full ? 3 : 1);

        float damage = 6.0F + 20.0F * f;
        DamageSource source = PXDamage.source(level, PXDamage.RIEL, shooter, shooter);
        for (Entity e : ray.hits()) {
            e.invulnerableTime = 0;
            if (e.hurt(source, damage) && e instanceof LivingEntity living) {
                // Marca de objetivo: Resplandor 8 s, visible a través de las paredes
                living.addEffect(new MobEffectInstance(MobEffects.GLOWING, 160, 0, false, false), shooter);
                living.knockback(0.3 + 0.5 * f, -dir.x, -dir.z);
            }
            Vec3 c = e.getBoundingBox().getCenter();
            FX.burst(level, ParticleTypes.ELECTRIC_SPARK, c, 12, 0.25, 0.4);
            FX.burst(level, FX.dust(0x3CE6FF, 1.2F), c, 8, 0.3, 0.05);
        }

        Vec3 muzzle = Aim.muzzle(shooter, 1.05, 0.26, 0.2);
        RailTrail.spawn(level, muzzle, ray.end(), 0x3CE6FF, full ? 0.16F : 0.07F + 0.06F * f, full ? 36 : 14);
        if (ray.hitBlock()) {
            FX.burst(level, ParticleTypes.ELECTRIC_SPARK, ray.end(), 10, 0.15, 0.3);
            FX.burst(level, ParticleTypes.SMOKE, ray.end(), 4, 0.1, 0.02);
        }
        if (full) {
            // estela de plasma: delata la posición del tirador
            FX.line(level, ParticleTypes.END_ROD, muzzle, ray.end(), 1.6, 0.04);
            FX.sound(level, shooter, PXSounds.AGUJA_RIEL.get(), 1.5F, 1.0F);
        }
        FX.sound(level, shooter, PXSounds.AGUJA_DISPARO.get(), 1.0F + f, 1.25F - 0.35F * f);
    }
}
