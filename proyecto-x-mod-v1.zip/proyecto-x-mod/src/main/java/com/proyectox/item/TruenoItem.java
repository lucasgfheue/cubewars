package com.proyectox.item;

import com.proyectox.entity.RailTrail;
import com.proyectox.registry.PXComponents;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import com.proyectox.util.Scheduler;
import java.util.List;
import java.util.Locale;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * PX-14 TRUENO — designador de ataque orbital.
 * Mantener clic derecho 2 s marca el punto; 2 s después cae la lanza orbital. Agachado: bengala de reconocimiento.
 */
public class TruenoItem extends PXWeapon {
    public static final int DESIGNATE = 40;
    public static final double RANGE = 96.0;
    public static final int FLARE_COOLDOWN = 400;

    public TruenoItem(Properties properties) {
        super("trueno", "PX-14", 0xD6E4FF, properties);
    }

    @Override
    public int maxCharge() {
        return 1;
    }

    @Override
    public int regenTicks() {
        return 600;
    }

    @Override
    protected boolean guardsBlocks() {
        return true;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        long now = level.getGameTime();
        if (player.isSecondaryUseActive()) {
            long ready = stack.getOrDefault(PXComponents.READY_AT.get(), 0L);
            if (now < ready) {
                if (!level.isClientSide) {
                    player.displayClientMessage(Component.translatable("message.proyectox.trueno.bengala_recarga",
                            String.format(Locale.ROOT, "%.0f", (ready - now) / 20.0)).withStyle(ChatFormatting.GRAY), true);
                }
                return InteractionResultHolder.fail(stack);
            }
            if (level instanceof ServerLevel server) flare(server, player);
            stack.set(PXComponents.READY_AT.get(), now + FLARE_COOLDOWN);
            return InteractionResultHolder.consume(stack);
        }
        if (charge(stack, now) <= 0) {
            emptyClick(level, player, "message.proyectox.trueno.sin_enlace");
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        if (!level.isClientSide) FX.sound(level, player, PXSounds.TRUENO_MARCAR.get(), 0.8F, 1.0F);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (!(level instanceof ServerLevel server)) return;
        int used = getUseDuration(stack, entity) - remaining;
        Vec3 point = Aim.lookPoint(entity, RANGE);
        if (used % 2 == 0) RailTrail.spawn(server, Aim.muzzle(entity, 0.9, 0.2, 0.3), point, 0xFF5050, 0.03F, 3);
        if (used % 10 == 0) FX.burst(server, FX.dust(0xFF5050, 1.0F), point, 4, 0.1, 0.01);
        if (used == DESIGNATE) {
            long now = level.getGameTime();
            if (!consume(stack, now, 1, 0)) return;
            Vec3 ground = point;
            RailTrail.spawn(server, ground, ground.add(0, 60, 0), 0xD6E4FF, 0.35F, 40);
            FX.sound(level, ground, PXSounds.TRUENO_MARCAR.get(), 2.0F, 1.6F);
            if (entity instanceof Player player) {
                player.displayClientMessage(Component.translatable("message.proyectox.trueno.impacto").withColor(color()), true);
            }
            Scheduler.schedule(server, 40, () -> strike(server, entity, ground));
            entity.stopUsingItem();
        }
    }

    private static void strike(ServerLevel level, LivingEntity owner, Vec3 at) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(at.x, at.y, at.z);
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
        DamageSource source = PXDamage.source(level, PXDamage.ORBITAL, owner, owner);
        for (LivingEntity e : Aim.sphere(level, owner, at, 4.0)) {
            double d = e.position().distanceTo(at);
            float dmg = (float) (20.0 * (1.0 - 0.6 * Math.min(1.0, d / 4.0)));
            e.invulnerableTime = 0;
            e.hurt(source, dmg);
            e.igniteForSeconds(5.0F);
            Vec3 push = e.position().subtract(at);
            push = push.lengthSqr() < 1.0E-4 ? Vec3.ZERO : push.normalize();
            e.setDeltaMovement(e.getDeltaMovement().add(push.x * 0.8, 0.7, push.z * 0.8));
            e.hurtMarked = true;
        }
        FX.burst(level, ParticleTypes.EXPLOSION_EMITTER, at, 1, 0.0, 0.0);
        FX.burst(level, ParticleTypes.END_ROD, at.add(0, 0.5, 0), 30, 0.6, 0.25);
        FX.ring(level, ParticleTypes.CLOUD, at.add(0, 0.2, 0), 1.0, 32, 0.6);
        FX.burst(level, FX.dust(0xD6E4FF, 2.0F), at, 40, 2.0, 0.1);
        FX.sound(level, at, PXSounds.TRUENO_IMPACTO.get(), 3.0F, 0.8F);
    }

    private static void flare(ServerLevel level, Player player) {
        Vec3 point = Aim.lookPoint(player, RANGE);
        for (LivingEntity e : Aim.sphere(level, player, point, 24.0)) {
            e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0, false, false), player);
        }
        FX.burst(level, ParticleTypes.FIREWORK, point.add(0, 1.0, 0), 40, 1.5, 0.15);
        FX.sound(level, point, PXSounds.TRUENO_BENGALA.get(), 2.0F, 1.0F);
        FX.sound(level, player, PXSounds.TRUENO_BENGALA.get(), 0.8F, 1.2F);
    }

    @Override
    protected void appendStatus(ItemStack stack, long now, List<Component> lines) {
        super.appendStatus(stack, now, lines);
        long ready = stack.getOrDefault(PXComponents.READY_AT.get(), 0L);
        if (now < ready) {
            lines.add(Component.translatable("tooltip.proyectox.trueno.bengala", String.format(Locale.ROOT, "%.0f", (ready - now) / 20.0))
                    .withStyle(ChatFormatting.GRAY));
        }
    }
}
