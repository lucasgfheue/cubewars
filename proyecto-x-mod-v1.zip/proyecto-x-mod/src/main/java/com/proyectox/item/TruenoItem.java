package com.proyectox.item;

import com.proyectox.fx.Fx;
import com.proyectox.registry.PXDamage;
import com.proyectox.registry.PXSounds;
import com.proyectox.util.Aim;
import com.proyectox.util.FX;
import com.proyectox.util.Hits;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;

/**
 * PX-14 TRUENO — cañón láser. Mientras se mantiene el gatillo dispara un láser continuo de 64 bloques
 * que atraviesa hasta 3 criaturas. Empieza celeste (1 de daño, cinco veces por segundo) y cuanto más
 * tiempo sigue encendido más se calienta: a los 3 s es rojo y hace 5.
 */
public class TruenoItem extends GunItem {
    public static final double RANGE = 64.0;
    public static final int RAMP_TICKS = 60;
    public static final float MIN_DAMAGE = 1.0F;
    public static final float MAX_DAMAGE = 5.0F;

    public TruenoItem(Properties properties) {
        super("trueno", "PX-14", 0xD6E4FF, Fx.TRUENO, properties);
    }

    @Override
    public int maxCharge() {
        return 400;
    }

    @Override
    public int regenTicks() {
        return 1;
    }

    @Override
    public int regenDelay() {
        return 12;
    }

    @Override
    public int interval() {
        return 2;
    }

    @Override
    public int cost() {
        return 2;
    }

    @Override
    public float zoom() {
        return 0.4F;
    }

    @Override
    public float kick() {
        return 0.06F;
    }

    @Override
    protected boolean muzzleFlash() {
        return false;
    }

    /** Calentamiento del láser (0 = celeste, 1 = rojo) tras {@code ticks} encendido. */
    public static float heat(int ticks) {
        return Mth.clamp(ticks / (float) RAMP_TICKS, 0.0F, 1.0F);
    }

    @Override
    protected void fire(Shot shot, ItemStack stack, int heldTicks) {
        ServerLevel level = shot.level();
        float heat = heat(heldTicks);
        Aim.Ray ray = Aim.pierce(level, shot.player(), shot.eye(), shot.look(), RANGE, 3);
        if ((heldTicks / 2) % 2 == 0) {
            DamageSource source = PXDamage.source(level, PXDamage.LASER, shot.player(), shot.player());
            float damage = MIN_DAMAGE + (MAX_DAMAGE - MIN_DAMAGE) * heat;
            for (Entity e : ray.hits()) Hits.hurt(e, source, damage, shot.player());
        }
        Fx.line(level, Fx.LASER, Fx.TRUENO, shot.muzzle(), ray.end(), heat, shot.player().getId());
        if ((heldTicks / 2) % 4 == 0) {
            FX.sound(level, shot.player(), PXSounds.TRUENO_MARCAR.get(), 0.8F, 1.3F + heat * 0.6F);
        }
    }
}
