package com.proyectox.client;

import com.proyectox.ProyectoX;
import com.proyectox.entity.MicroRocket;
import com.proyectox.entity.PlasmaBolt;
import com.proyectox.entity.Singularity;
import com.proyectox.item.AgujaItem;
import com.proyectox.item.AutoFire;
import com.proyectox.network.TriggerPayload;
import com.proyectox.registry.PXEntities;
import com.proyectox.registry.PXItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.PacketDistributor;

/** Parte exclusiva del cliente: renderizadores, poses de brazos, gatillo automático y zoom. */
@Mod(value = ProyectoX.MODID, dist = Dist.CLIENT)
public final class PXClient {
    private static boolean triggerWasDown;
    private static int triggerTicks;

    public PXClient(IEventBus modBus, ModContainer container) {
        modBus.addListener(PXClient::registerRenderers);
        modBus.addListener(PXClient::registerExtensions);
        NeoForge.EVENT_BUS.addListener(PXClient::onClientTick);
        NeoForge.EVENT_BUS.addListener(PXClient::onFov);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(PXEntities.PLASMA.get(), ctx -> new GlowRenderer<PlasmaBolt>(ctx,
                (bolt, pt) -> bolt.isHot()
                        ? new GlowRenderer.Look(0xFF9A30, 0xFFF4C0, 0.32F, 1.0F)
                        : new GlowRenderer.Look(0x96FF28, 0xEFFFD0, 0.28F, 1.0F)));
        event.registerEntityRenderer(PXEntities.MICROCOHETE.get(), ctx -> new GlowRenderer<MicroRocket>(ctx,
                (rocket, pt) -> new GlowRenderer.Look(0xFF4A2A, 0xFFE0B0, 0.42F + 0.06F * Mth.sin((rocket.tickCount + pt) * 1.7F), 1.0F)));
        event.registerEntityRenderer(PXEntities.SINGULARIDAD.get(), ctx -> new GlowRenderer<Singularity>(ctx, PXClient::singularityLook));
        event.registerEntityRenderer(PXEntities.ESTELA.get(), TrailRenderer::new);
    }

    private static GlowRenderer.Look singularityLook(Singularity s, float pt) {
        if (!s.isOpen()) {
            float pulse = 0.5F + 0.08F * Mth.sin((s.tickCount + pt) * 0.8F);
            return new GlowRenderer.Look(0xAA5AFF, 0xF0D8FF, pulse, 1.0F);
        }
        float t = s.openTicks() + pt;
        float grow = Math.min(1.0F, t / 8.0F);
        float end = Math.max(0.0F, (t - (Singularity.VORTEX_TICKS - 10)) / 10.0F);
        float radius = (1.1F + 0.25F * Mth.sin(t * 0.9F)) * grow * (1.0F + end * 1.5F);
        return new GlowRenderer.Look(0x8A3AFF, 0xFFFFFF, radius, 1.0F - end * 0.6F);
    }

    private static void registerExtensions(RegisterClientExtensionsEvent event) {
        IClientItemExtensions twoHanded = new IClientItemExtensions() {
            @Override
            public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
                return HumanoidModel.ArmPose.CROSSBOW_HOLD;
            }
        };
        event.registerItem(twoHanded, PXItems.AGUJA.get(), PXItems.AVISPON.get(), PXItems.COLMENA.get(), PXItems.VORTICE.get());
    }

    /** Gatillo de las armas automáticas: mientras se mantiene el clic derecho se avisa al servidor cada 2 ticks. */
    private static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        boolean down = player != null && mc.screen == null && !player.isSpectator()
                && mc.options.keyUse.isDown() && !player.isShiftKeyDown()
                && player.getMainHandItem().getItem() instanceof AutoFire;
        if (down) {
            if (!triggerWasDown || ++triggerTicks % 2 == 0) PacketDistributor.sendToServer(new TriggerPayload(true));
        } else if (triggerWasDown && mc.getConnection() != null) {
            PacketDistributor.sendToServer(new TriggerPayload(false));
            triggerTicks = 0;
        }
        triggerWasDown = down;
    }

    /** AGUJA: los condensadores cargando estrechan el campo de visión (zoom de tirador). */
    private static void onFov(ComputeFovModifierEvent event) {
        Player player = event.getPlayer();
        if (player.isUsingItem() && player.getUseItem().getItem() instanceof AgujaItem) {
            float f = AgujaItem.chargeFraction(player.getTicksUsingItem());
            event.setNewFovModifier(event.getNewFovModifier() * (1.0F - 0.35F * f));
        }
    }
}
