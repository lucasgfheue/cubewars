package com.proyectox.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;

/** Accesos al cliente. Solo se llama desde código protegido por {@code FMLEnvironment.dist.isClient()}. */
public final class ClientOnly {
    private ClientOnly() {}

    public static long gameTime() {
        ClientLevel level = Minecraft.getInstance().level;
        return level == null ? 0L : level.getGameTime();
    }

    public static boolean shiftDown() {
        return Screen.hasShiftDown();
    }
}
