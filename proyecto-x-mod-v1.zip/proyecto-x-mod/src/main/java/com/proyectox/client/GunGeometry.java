package com.proyectox.client;

import javax.annotation.Nullable;

/**
 * Geometría de las armas en primera persona (generado por tools/display.py; no editar):
 * posición del arma al apuntar, giro que se anula al apuntar y boca del cañón (espacio de la mano).
 */
public final class GunGeometry {
    private GunGeometry() {}

    public record Data(float adsX, float adsY, float adsZ, float yaw, float tipX, float tipY, float tipZ) {}

    @Nullable
    public static Data of(String key) {
        return switch (key) {
            case "aguja" -> new Data(-0.0817F, -0.4302F, -0.6102F, 6.00F, 0.0036F, 0.2101F, -0.7519F);
            case "avispon" -> new Data(-0.1009F, -0.5012F, -0.5598F, 6.00F, -0.0017F, 0.2496F, -0.8038F);
            case "colmena" -> new Data(-0.1035F, -0.4902F, -0.6083F, 6.00F, 0.0680F, 0.2142F, -0.6915F);
            case "vortice" -> new Data(-0.0822F, -0.5918F, -0.3538F, 6.00F, -0.0235F, 0.2901F, -1.0103F);
            case "chispa" -> new Data(-0.0742F, -0.3990F, -0.2831F, 6.00F, -0.0105F, 0.2269F, -0.8100F);
            case "remache" -> new Data(-0.0819F, -0.3258F, -0.5284F, 6.00F, -0.0051F, 0.2111F, -0.8318F);
            case "trituradora" -> new Data(-0.1399F, -0.4960F, -0.5325F, 6.00F, 0.0601F, 0.3039F, -0.7667F);
            case "rotor" -> new Data(-0.1152F, -0.4052F, -0.3063F, 6.00F, 0.0369F, 0.1885F, -0.9883F);
            case "halcon" -> new Data(-0.0527F, -0.5347F, -0.3563F, 6.00F, -0.0080F, 0.2970F, -0.5808F);
            case "trueno" -> new Data(-0.0091F, -0.6531F, -0.5111F, 6.00F, -0.0070F, 0.3147F, -0.8528F);
            case "soplete" -> new Data(-0.0820F, -0.4560F, -0.4575F, 6.00F, -0.0127F, 0.2369F, -0.9055F);
            case "escarcha" -> new Data(-0.0823F, -0.4974F, -0.4922F, 6.00F, -0.0087F, 0.2548F, -0.8708F);
            case "eco" -> new Data(-0.1396F, -0.4688F, -0.4686F, 6.00F, 0.0530F, 0.2246F, -0.8305F);
            case "colibri" -> new Data(-0.0742F, -0.2863F, -0.4415F, 6.00F, -0.0083F, 0.2008F, -0.7897F);
            case "sierra" -> new Data(-0.0823F, -0.5183F, -0.4853F, 6.00F, -0.0111F, 0.3401F, -0.8771F);
            default -> null;
        };
    }

    /** Eje de la broca del TALADRO en el espacio de la mano: punto (x, y, z) y dirección (x, y, z). */
    public static final float[] DRILL_AXIS = {0.0706F, 0.2045F, -0.6621F, -0.1045F, 0.0000F, -0.9945F};
}
