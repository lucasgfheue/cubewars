package com.proyectox.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.proyectox.ProyectoX;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

/**
 * Proyectil de energía dibujado como un destello aditivo que siempre mira a la cámara.
 * Usa el render type de los ojos de las arañas: brilla en la oscuridad y no escribe profundidad.
 */
public class GlowRenderer<T extends Entity> extends EntityRenderer<T> {
    public static final ResourceLocation GLOW = ProyectoX.id("textures/entity/brillo.png");

    /** Aspecto de un proyectil en un instante: color del halo, color del núcleo, radio e intensidad. */
    public record Look(int halo, int core, float radius, float intensity) {}

    @FunctionalInterface
    public interface Styler<T> {
        Look look(T entity, float partialTick);
    }

    private final Styler<T> styler;

    public GlowRenderer(EntityRendererProvider.Context context, Styler<T> styler) {
        super(context);
        this.styler = styler;
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(T entity, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        Look look = styler.look(entity, partialTick);
        if (look.radius() > 0.0F && look.intensity() > 0.0F) {
            pose.pushPose();
            pose.translate(0.0F, entity.getBbHeight() * 0.5F, 0.0F);
            pose.mulPose(this.entityRenderDispatcher.cameraOrientation());
            VertexConsumer vc = buffers.getBuffer(RenderType.eyes(GLOW));
            PoseStack.Pose p = pose.last();
            sprite(vc, p, look.radius(), look.halo(), 0.9F * look.intensity());
            sprite(vc, p, look.radius() * 0.45F, look.core(), 1.0F * look.intensity());
            pose.popPose();
        }
        super.render(entity, yaw, partialTick, pose, buffers, light);
    }

    /** Cuadrado con la textura de destello, por las dos caras (mezcla aditiva: color premultiplicado). */
    static void sprite(VertexConsumer vc, PoseStack.Pose pose, float radius, int rgb, float intensity) {
        float r = ((rgb >> 16) & 0xFF) / 255F * intensity;
        float g = ((rgb >> 8) & 0xFF) / 255F * intensity;
        float b = (rgb & 0xFF) / 255F * intensity;
        vertex(vc, pose, -radius, -radius, 0.0F, 1.0F, r, g, b);
        vertex(vc, pose, radius, -radius, 1.0F, 1.0F, r, g, b);
        vertex(vc, pose, radius, radius, 1.0F, 0.0F, r, g, b);
        vertex(vc, pose, -radius, radius, 0.0F, 0.0F, r, g, b);

        vertex(vc, pose, -radius, radius, 0.0F, 0.0F, r, g, b);
        vertex(vc, pose, radius, radius, 1.0F, 0.0F, r, g, b);
        vertex(vc, pose, radius, -radius, 1.0F, 1.0F, r, g, b);
        vertex(vc, pose, -radius, -radius, 0.0F, 1.0F, r, g, b);
    }

    static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float u, float v, float r, float g, float b) {
        vc.addVertex(pose, x, y, 0.0F)
                .setColor(r, g, b, 1.0F)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0.0F, 1.0F, 0.0F);
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return GLOW;
    }
}
