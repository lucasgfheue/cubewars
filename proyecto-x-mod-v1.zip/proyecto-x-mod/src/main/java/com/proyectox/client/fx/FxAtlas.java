package com.proyectox.client.fx;

/** Coordenadas de los sprites en textures/fx/atlas.png (generado por tools/fx.py; no editar). */
public final class FxAtlas {
    private FxAtlas() {}

    public static final int SIZE = 2048;

    public static final Sprite ACCRETION = new Sprite(0.504150F, 0.251221F, 0.628662F, 0.375732F, 1032, 514, 256, 256);
    public static final Sprite BEAM = new Sprite(0.284424F, 0.630127F, 0.315186F, 0.660889F, 582, 1290, 64, 64);
    public static final Sprite BEAM_NOISE = new Sprite(0.697510F, 0.566650F, 0.822021F, 0.597412F, 1428, 1160, 256, 64);
    public static final Sprite BEAM_THIN = new Sprite(0.316650F, 0.630127F, 0.347412F, 0.660889F, 648, 1290, 64, 64);
    public static final Sprite BOLT = new Sprite(0.571533F, 0.566650F, 0.696045F, 0.597412F, 1170, 1160, 256, 64);
    public static final Sprite BUBBLE = new Sprite(0.510010F, 0.630127F, 0.540771F, 0.660889F, 1044, 1290, 64, 64);
    public static final Sprite CHARGE_RING = new Sprite(0.190674F, 0.566650F, 0.252686F, 0.628662F, 390, 1160, 128, 128);
    public static final Sprite CLOUD_0 = new Sprite(0.381104F, 0.566650F, 0.443115F, 0.628662F, 780, 1160, 128, 128);
    public static final Sprite CLOUD_1 = new Sprite(0.444580F, 0.566650F, 0.506592F, 0.628662F, 910, 1160, 128, 128);
    public static final Sprite CLOUD_2 = new Sprite(0.508057F, 0.566650F, 0.570068F, 0.628662F, 1040, 1160, 128, 128);
    public static final Sprite CORE = new Sprite(0.252197F, 0.630127F, 0.282959F, 0.660889F, 516, 1290, 64, 64);
    public static final Sprite CORONA = new Sprite(0.000244F, 0.377197F, 0.124756F, 0.501709F, 0, 772, 256, 256);
    public static final Sprite CRESCENT = new Sprite(0.378174F, 0.251221F, 0.502686F, 0.375732F, 774, 514, 256, 256);
    public static final Sprite DEBRIS = new Sprite(0.622314F, 0.630127F, 0.637451F, 0.645264F, 1274, 1290, 32, 32);
    public static final Sprite DRILL = new Sprite(0.254150F, 0.566650F, 0.316162F, 0.628662F, 520, 1160, 128, 128);
    public static final Sprite EMBER = new Sprite(0.605713F, 0.630127F, 0.620850F, 0.645264F, 1240, 1290, 32, 32);
    public static final Sprite FIRE_0 = new Sprite(0.254150F, 0.503174F, 0.316162F, 0.565186F, 520, 1030, 128, 128);
    public static final Sprite FIRE_1 = new Sprite(0.317627F, 0.503174F, 0.379639F, 0.565186F, 650, 1030, 128, 128);
    public static final Sprite FIRE_2 = new Sprite(0.381104F, 0.503174F, 0.443115F, 0.565186F, 780, 1030, 128, 128);
    public static final Sprite FIRE_3 = new Sprite(0.444580F, 0.503174F, 0.506592F, 0.565186F, 910, 1030, 128, 128);
    public static final Sprite FIRE_4 = new Sprite(0.508057F, 0.503174F, 0.570068F, 0.565186F, 1040, 1030, 128, 128);
    public static final Sprite FIRE_5 = new Sprite(0.571533F, 0.503174F, 0.633545F, 0.565186F, 1170, 1030, 128, 128);
    public static final Sprite FIRE_6 = new Sprite(0.635010F, 0.503174F, 0.697021F, 0.565186F, 1300, 1030, 128, 128);
    public static final Sprite FIRE_7 = new Sprite(0.698486F, 0.503174F, 0.760498F, 0.565186F, 1430, 1030, 128, 128);
    public static final Sprite FLAME_0 = new Sprite(0.695557F, 0.377197F, 0.757568F, 0.439209F, 1424, 772, 128, 128);
    public static final Sprite FLAME_1 = new Sprite(0.759033F, 0.377197F, 0.821045F, 0.439209F, 1554, 772, 128, 128);
    public static final Sprite FLAME_2 = new Sprite(0.822510F, 0.377197F, 0.884521F, 0.439209F, 1684, 772, 128, 128);
    public static final Sprite FLAME_3 = new Sprite(0.885986F, 0.377197F, 0.947998F, 0.439209F, 1814, 772, 128, 128);
    public static final Sprite FLAME_4 = new Sprite(0.000244F, 0.503174F, 0.062256F, 0.565186F, 0, 1030, 128, 128);
    public static final Sprite FLAME_5 = new Sprite(0.063721F, 0.503174F, 0.125732F, 0.565186F, 130, 1030, 128, 128);
    public static final Sprite FLAME_6 = new Sprite(0.127197F, 0.503174F, 0.189209F, 0.565186F, 260, 1030, 128, 128);
    public static final Sprite FLAME_7 = new Sprite(0.190674F, 0.503174F, 0.252686F, 0.565186F, 390, 1030, 128, 128);
    public static final Sprite FLASH_SIDE = new Sprite(0.126221F, 0.377197F, 0.250732F, 0.439209F, 258, 772, 256, 128);
    public static final Sprite FUNNEL = new Sprite(0.252197F, 0.377197F, 0.376709F, 0.439209F, 516, 772, 256, 128);
    public static final Sprite GLINT = new Sprite(0.477783F, 0.630127F, 0.508545F, 0.660889F, 978, 1290, 64, 64);
    public static final Sprite GLOW = new Sprite(0.378174F, 0.377197F, 0.440186F, 0.439209F, 774, 772, 128, 128);
    public static final Sprite GRENADE = new Sprite(0.825439F, 0.503174F, 0.887451F, 0.565186F, 1690, 1030, 128, 128);
    public static final Sprite HARPOON = new Sprite(0.126221F, 0.630127F, 0.250732F, 0.660889F, 258, 1290, 256, 64);
    public static final Sprite HEX = new Sprite(0.000244F, 0.251221F, 0.124756F, 0.375732F, 0, 514, 256, 256);
    public static final Sprite HITMARK = new Sprite(0.445557F, 0.630127F, 0.476318F, 0.660889F, 912, 1290, 64, 64);
    public static final Sprite LENS = new Sprite(0.000244F, 0.630127F, 0.124756F, 0.660889F, 0, 1290, 256, 64);
    public static final Sprite LOCK = new Sprite(0.888916F, 0.503174F, 0.950928F, 0.565186F, 1820, 1030, 128, 128);
    public static final Sprite MINE = new Sprite(0.317627F, 0.566650F, 0.379639F, 0.628662F, 650, 1160, 128, 128);
    public static final Sprite ORB_CORE = new Sprite(0.761963F, 0.503174F, 0.823975F, 0.565186F, 1560, 1030, 128, 128);
    public static final Sprite RET_CHEVRON = new Sprite(0.127197F, 0.566650F, 0.189209F, 0.628662F, 260, 1160, 128, 128);
    public static final Sprite RET_CIRCLE = new Sprite(0.000244F, 0.566650F, 0.062256F, 0.628662F, 0, 1160, 128, 128);
    public static final Sprite RET_CROSS = new Sprite(0.063721F, 0.566650F, 0.125732F, 0.628662F, 130, 1160, 128, 128);
    public static final Sprite RET_DOT = new Sprite(0.413330F, 0.630127F, 0.444092F, 0.660889F, 846, 1290, 64, 64);
    public static final Sprite RING = new Sprite(0.503174F, 0.000244F, 0.627686F, 0.124756F, 1030, 0, 256, 256);
    public static final Sprite RING_NOISE = new Sprite(0.629150F, 0.000244F, 0.753662F, 0.124756F, 1288, 0, 256, 256);
    public static final Sprite ROPE = new Sprite(0.823486F, 0.566650F, 0.947998F, 0.597412F, 1686, 1160, 256, 64);
    public static final Sprite SAW = new Sprite(0.126221F, 0.251221F, 0.250732F, 0.375732F, 258, 514, 256, 256);
    public static final Sprite SAW_BLUR = new Sprite(0.252197F, 0.251221F, 0.376709F, 0.375732F, 516, 514, 256, 256);
    public static final Sprite SCOPE = new Sprite(0.000244F, 0.000244F, 0.249756F, 0.249756F, 0, 0, 512, 512);
    public static final Sprite SHARD = new Sprite(0.348877F, 0.630127F, 0.379639F, 0.660889F, 714, 1290, 64, 64);
    public static final Sprite SHOCK = new Sprite(0.755127F, 0.000244F, 0.879639F, 0.124756F, 1546, 0, 256, 256);
    public static final Sprite SMOKE_0 = new Sprite(0.441650F, 0.377197F, 0.503662F, 0.439209F, 904, 772, 128, 128);
    public static final Sprite SMOKE_1 = new Sprite(0.505127F, 0.377197F, 0.567139F, 0.439209F, 1034, 772, 128, 128);
    public static final Sprite SMOKE_2 = new Sprite(0.568604F, 0.377197F, 0.630615F, 0.439209F, 1164, 772, 128, 128);
    public static final Sprite SMOKE_3 = new Sprite(0.632080F, 0.377197F, 0.694092F, 0.439209F, 1294, 772, 128, 128);
    public static final Sprite SNOW = new Sprite(0.381104F, 0.630127F, 0.411865F, 0.660889F, 780, 1290, 64, 64);
    public static final Sprite SOUNDWAVE = new Sprite(0.756104F, 0.251221F, 0.880615F, 0.375732F, 1548, 514, 256, 256);
    public static final Sprite SPARK = new Sprite(0.542236F, 0.630127F, 0.604248F, 0.645264F, 1110, 1290, 128, 32);
    public static final Sprite STAR4 = new Sprite(0.251221F, 0.000244F, 0.375732F, 0.124756F, 514, 0, 256, 256);
    public static final Sprite STAR6 = new Sprite(0.377197F, 0.000244F, 0.501709F, 0.124756F, 772, 0, 256, 256);
    public static final Sprite VORTEX = new Sprite(0.630127F, 0.251221F, 0.754639F, 0.375732F, 1290, 514, 256, 256);

    public static final Sprite[] CLOUD = {CLOUD_0, CLOUD_1, CLOUD_2};
    public static final Sprite[] FIRE = {FIRE_0, FIRE_1, FIRE_2, FIRE_3, FIRE_4, FIRE_5, FIRE_6, FIRE_7};
    public static final Sprite[] FLAME = {FLAME_0, FLAME_1, FLAME_2, FLAME_3, FLAME_4, FLAME_5, FLAME_6, FLAME_7};
    public static final Sprite[] SMOKE = {SMOKE_0, SMOKE_1, SMOKE_2, SMOKE_3};

    /** Rectángulo UV de un sprite del atlas. */
    public record Sprite(float u0, float v0, float u1, float v1, int x, int y, int w, int h) {
        public float u(float f) {
            return this.u0 + (this.u1 - this.u0) * f;
        }

        public float v(float f) {
            return this.v0 + (this.v1 - this.v0) * f;
        }
    }
}
