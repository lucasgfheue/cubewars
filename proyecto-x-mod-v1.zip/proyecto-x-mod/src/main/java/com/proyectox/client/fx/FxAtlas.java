package com.proyectox.client.fx;

/** Coordenadas de los sprites en textures/fx/atlas.png (generado por tools/fx.py; no editar). */
public final class FxAtlas {
    private FxAtlas() {}

    public static final int SIZE = 2048;

    public static final Sprite ACCRETION = new Sprite(0.504150F, 0.251221F, 0.628662F, 0.375732F, 1032, 514, 256, 256);
    public static final Sprite BEAM = new Sprite(0.599854F, 0.504150F, 0.630615F, 0.534912F, 1228, 1032, 64, 64);
    public static final Sprite BEAM_NOISE = new Sprite(0.189697F, 0.504150F, 0.314209F, 0.534912F, 388, 1032, 256, 64);
    public static final Sprite BEAM_THIN = new Sprite(0.632080F, 0.504150F, 0.662842F, 0.534912F, 1294, 1032, 64, 64);
    public static final Sprite BOLT = new Sprite(0.063721F, 0.504150F, 0.188232F, 0.534912F, 130, 1032, 256, 64);
    public static final Sprite CHARGE_RING = new Sprite(0.888916F, 0.440674F, 0.950928F, 0.502686F, 1820, 902, 128, 128);
    public static final Sprite CORE = new Sprite(0.567627F, 0.504150F, 0.598389F, 0.534912F, 1162, 1032, 64, 64);
    public static final Sprite CRESCENT = new Sprite(0.378174F, 0.251221F, 0.502686F, 0.375732F, 774, 514, 256, 256);
    public static final Sprite DEBRIS = new Sprite(0.905518F, 0.504150F, 0.920654F, 0.519287F, 1854, 1032, 32, 32);
    public static final Sprite DRILL = new Sprite(0.000244F, 0.504150F, 0.062256F, 0.566162F, 0, 1032, 128, 128);
    public static final Sprite EMBER = new Sprite(0.888916F, 0.504150F, 0.904053F, 0.519287F, 1820, 1032, 32, 32);
    public static final Sprite FIRE_0 = new Sprite(0.000244F, 0.440674F, 0.062256F, 0.502686F, 0, 902, 128, 128);
    public static final Sprite FIRE_1 = new Sprite(0.063721F, 0.440674F, 0.125732F, 0.502686F, 130, 902, 128, 128);
    public static final Sprite FIRE_2 = new Sprite(0.127197F, 0.440674F, 0.189209F, 0.502686F, 260, 902, 128, 128);
    public static final Sprite FIRE_3 = new Sprite(0.190674F, 0.440674F, 0.252686F, 0.502686F, 390, 902, 128, 128);
    public static final Sprite FIRE_4 = new Sprite(0.254150F, 0.440674F, 0.316162F, 0.502686F, 520, 902, 128, 128);
    public static final Sprite FIRE_5 = new Sprite(0.317627F, 0.440674F, 0.379639F, 0.502686F, 650, 902, 128, 128);
    public static final Sprite FIRE_6 = new Sprite(0.381104F, 0.440674F, 0.443115F, 0.502686F, 780, 902, 128, 128);
    public static final Sprite FIRE_7 = new Sprite(0.444580F, 0.440674F, 0.506592F, 0.502686F, 910, 902, 128, 128);
    public static final Sprite FLAME_0 = new Sprite(0.443604F, 0.377197F, 0.505615F, 0.439209F, 908, 772, 128, 128);
    public static final Sprite FLAME_1 = new Sprite(0.507080F, 0.377197F, 0.569092F, 0.439209F, 1038, 772, 128, 128);
    public static final Sprite FLAME_2 = new Sprite(0.570557F, 0.377197F, 0.632568F, 0.439209F, 1168, 772, 128, 128);
    public static final Sprite FLAME_3 = new Sprite(0.634033F, 0.377197F, 0.696045F, 0.439209F, 1298, 772, 128, 128);
    public static final Sprite FLAME_4 = new Sprite(0.697510F, 0.377197F, 0.759521F, 0.439209F, 1428, 772, 128, 128);
    public static final Sprite FLAME_5 = new Sprite(0.760986F, 0.377197F, 0.822998F, 0.439209F, 1558, 772, 128, 128);
    public static final Sprite FLAME_6 = new Sprite(0.824463F, 0.377197F, 0.886475F, 0.439209F, 1688, 772, 128, 128);
    public static final Sprite FLAME_7 = new Sprite(0.887939F, 0.377197F, 0.949951F, 0.439209F, 1818, 772, 128, 128);
    public static final Sprite FLASH_SIDE = new Sprite(0.000244F, 0.377197F, 0.124756F, 0.439209F, 0, 772, 256, 128);
    public static final Sprite GLINT = new Sprite(0.793213F, 0.504150F, 0.823975F, 0.534912F, 1624, 1032, 64, 64);
    public static final Sprite GLOW = new Sprite(0.126221F, 0.377197F, 0.188232F, 0.439209F, 258, 772, 128, 128);
    public static final Sprite GRENADE = new Sprite(0.571533F, 0.440674F, 0.633545F, 0.502686F, 1170, 902, 128, 128);
    public static final Sprite HEX = new Sprite(0.000244F, 0.251221F, 0.124756F, 0.375732F, 0, 514, 256, 256);
    public static final Sprite HITMARK = new Sprite(0.760986F, 0.504150F, 0.791748F, 0.534912F, 1558, 1032, 64, 64);
    public static final Sprite LENS = new Sprite(0.441650F, 0.504150F, 0.566162F, 0.534912F, 904, 1032, 256, 64);
    public static final Sprite LOCK = new Sprite(0.635010F, 0.440674F, 0.697021F, 0.502686F, 1300, 902, 128, 128);
    public static final Sprite ORB_CORE = new Sprite(0.508057F, 0.440674F, 0.570068F, 0.502686F, 1040, 902, 128, 128);
    public static final Sprite RET_CHEVRON = new Sprite(0.825439F, 0.440674F, 0.887451F, 0.502686F, 1690, 902, 128, 128);
    public static final Sprite RET_CIRCLE = new Sprite(0.698486F, 0.440674F, 0.760498F, 0.502686F, 1430, 902, 128, 128);
    public static final Sprite RET_CROSS = new Sprite(0.761963F, 0.440674F, 0.823975F, 0.502686F, 1560, 902, 128, 128);
    public static final Sprite RET_DOT = new Sprite(0.728760F, 0.504150F, 0.759521F, 0.534912F, 1492, 1032, 64, 64);
    public static final Sprite RING = new Sprite(0.503174F, 0.000244F, 0.627686F, 0.124756F, 1030, 0, 256, 256);
    public static final Sprite RING_NOISE = new Sprite(0.629150F, 0.000244F, 0.753662F, 0.124756F, 1288, 0, 256, 256);
    public static final Sprite ROPE = new Sprite(0.315674F, 0.504150F, 0.440186F, 0.534912F, 646, 1032, 256, 64);
    public static final Sprite SAW = new Sprite(0.126221F, 0.251221F, 0.250732F, 0.375732F, 258, 514, 256, 256);
    public static final Sprite SAW_BLUR = new Sprite(0.252197F, 0.251221F, 0.376709F, 0.375732F, 516, 514, 256, 256);
    public static final Sprite SCOPE = new Sprite(0.000244F, 0.000244F, 0.249756F, 0.249756F, 0, 0, 512, 512);
    public static final Sprite SHARD = new Sprite(0.664307F, 0.504150F, 0.695068F, 0.534912F, 1360, 1032, 64, 64);
    public static final Sprite SHOCK = new Sprite(0.755127F, 0.000244F, 0.879639F, 0.124756F, 1546, 0, 256, 256);
    public static final Sprite SMOKE_0 = new Sprite(0.189697F, 0.377197F, 0.251709F, 0.439209F, 388, 772, 128, 128);
    public static final Sprite SMOKE_1 = new Sprite(0.253174F, 0.377197F, 0.315186F, 0.439209F, 518, 772, 128, 128);
    public static final Sprite SMOKE_2 = new Sprite(0.316650F, 0.377197F, 0.378662F, 0.439209F, 648, 772, 128, 128);
    public static final Sprite SMOKE_3 = new Sprite(0.380127F, 0.377197F, 0.442139F, 0.439209F, 778, 772, 128, 128);
    public static final Sprite SNOW = new Sprite(0.696533F, 0.504150F, 0.727295F, 0.534912F, 1426, 1032, 64, 64);
    public static final Sprite SOUNDWAVE = new Sprite(0.756104F, 0.251221F, 0.880615F, 0.375732F, 1548, 514, 256, 256);
    public static final Sprite SPARK = new Sprite(0.825439F, 0.504150F, 0.887451F, 0.519287F, 1690, 1032, 128, 32);
    public static final Sprite STAR4 = new Sprite(0.251221F, 0.000244F, 0.375732F, 0.124756F, 514, 0, 256, 256);
    public static final Sprite STAR6 = new Sprite(0.377197F, 0.000244F, 0.501709F, 0.124756F, 772, 0, 256, 256);
    public static final Sprite VORTEX = new Sprite(0.630127F, 0.251221F, 0.754639F, 0.375732F, 1290, 514, 256, 256);

    public static final Sprite[] FIRE = {FIRE_0, FIRE_1, FIRE_2, FIRE_3, FIRE_4, FIRE_5, FIRE_6, FIRE_7};
    public static final Sprite[] FLAME = {FLAME_0, FLAME_1, FLAME_2, FLAME_3, FLAME_4, FLAME_5, FLAME_6, FLAME_7};
    public static final Sprite[] SMOKE = {SMOKE_0, SMOKE_1, SMOKE_2, SMOKE_3};

    /** Rectángulo UV de un sprite del atlas. */
    public record Sprite(float u0, float v0, float u1, float v1, int x, int y, int w, int h) {
        public float u(float f) {
            return this.u0 + (this.u1 - this.u0) * f;
        }

        public float v(float f) {
            return this.v0 + (this.v1 - this.v0) * f;
        }
    }
}
