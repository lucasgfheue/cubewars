package com.proyectox.client.fx;

import com.proyectox.fx.Fx;

/** Colores de los efectos de cada arma: tono principal, núcleo caliente y chispas. */
public final class Palette {
    private Palette() {}

    public static int main(int style) {
        return switch (style) {
            case Fx.MARTINETE -> 0xFF9A1F;
            case Fx.AGUJA -> 0x3CE6FF;
            case Fx.AVISPON -> 0x8CFF2E;
            case Fx.AVISPON_HOT -> 0xFF8A26;
            case Fx.COLMENA -> 0xFF5A2A;
            case Fx.VORTICE -> 0xA45CFF;
            case Fx.CIZALLA -> 0xFF2E7E;
            case Fx.TALADRO -> 0xFFD21A;
            case Fx.SERPENTINA -> 0x4F78FF;
            case Fx.CHISPA -> 0x9CC8FF;
            case Fx.REMACHE -> 0xFF9A40;
            case Fx.TRITURADORA -> 0xC8E04A;
            case Fx.BOMBLET -> 0xFFB840;
            case Fx.ROTOR -> 0xFFC85A;
            case Fx.HALCON -> 0xFFA235;
            case Fx.TRUENO -> 0x5FE6FF;
            case Fx.SOPLETE -> 0xFF6A1A;
            case Fx.ESCARCHA -> 0x9FEFFF;
            case Fx.ECO -> 0xD9A8FF;
            case Fx.BASTION -> 0xFFC48A;
            case Fx.COLIBRI -> 0xFF6FC8;
            case Fx.SIERRA -> 0x2EE6A0;
            default -> 0xFFFFFF;
        };
    }

    /** Núcleo casi blanco con un toque del color del arma. */
    public static int hot(int style) {
        return switch (style) {
            case Fx.AGUJA, Fx.TRUENO, Fx.ESCARCHA -> 0xE8FDFF;
            case Fx.AVISPON -> 0xF0FFD8;
            case Fx.VORTICE, Fx.ECO -> 0xF4E8FF;
            case Fx.CIZALLA, Fx.COLIBRI -> 0xFFE6F4;
            case Fx.SERPENTINA, Fx.CHISPA -> 0xF0F6FF;
            case Fx.SIERRA -> 0xE6FFF4;
            default -> 0xFFF4DC;
        };
    }

    /** Color de las chispas. */
    public static int spark(int style) {
        return switch (style) {
            case Fx.AGUJA, Fx.TRUENO -> 0x9FF4FF;
            case Fx.AVISPON -> 0xC8FF6A;
            case Fx.VORTICE -> 0xD2A8FF;
            case Fx.CIZALLA -> 0xFF7AB0;
            case Fx.SERPENTINA, Fx.CHISPA -> 0xD8E8FF;
            case Fx.ESCARCHA -> 0xDDFBFF;
            case Fx.ECO -> 0xF0D8FF;
            case Fx.COLIBRI -> 0xFFB0E0;
            case Fx.SIERRA -> 0x9FFFD6;
            default -> 0xFFC870;
        };
    }

    /** Mezcla lineal de dos colores RGB. */
    public static int mix(int a, int b, float t) {
        float k = Math.max(0.0F, Math.min(1.0F, t));
        int r = Math.round(((a >> 16) & 0xFF) * (1 - k) + ((b >> 16) & 0xFF) * k);
        int g = Math.round(((a >> 8) & 0xFF) * (1 - k) + ((b >> 8) & 0xFF) * k);
        int bl = Math.round((a & 0xFF) * (1 - k) + (b & 0xFF) * k);
        return r << 16 | g << 8 | bl;
    }
}
