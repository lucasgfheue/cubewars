package com.proyectox.client.fx;

import com.proyectox.fx.Fx;

/** Colores de los efectos de cada arma: tono principal, núcleo caliente y chispas. */
public final class Palette {
    private Palette() {}

    public static int main(int style) {
        return switch (style) {
            case Fx.MARTINETE -> 0xFF9A1F;
            case Fx.AGUJA -> 0x3CE6FF;
            case Fx.AVISPON -> 0x8CFF2E;
            case Fx.AVISPON_HOT -> 0xFF8A26;
            case Fx.COLMENA -> 0xFF5A2A;
            case Fx.VORTICE -> 0xA45CFF;
            case Fx.CIZALLA -> 0xFF2E7E;
            case Fx.TALADRO -> 0xFFD21A;
            case Fx.SERPENTINA -> 0x4F78FF;
            case Fx.CHISPA -> 0x9CC8FF;
            case Fx.REMACHE -> 0xFF9A40;
            case Fx.TRITURADORA -> 0xC8E04A;
            case Fx.BOMBLET -> 0xFFB840;
            case Fx.ROTOR -> 0xFFC85A;
            case Fx.HALCON -> 0xFFA235;
            case Fx.TRUENO -> 0x5FE6FF;
            case Fx.SOPLETE -> 0xFF6A1A;
            case Fx.ESCARCHA -> 0x9FEFFF;
            case Fx.ECO -> 0xD9A8FF;
            case Fx.BASTION -> 0xFFC48A;
            case Fx.COLIBRI -> 0xFF6FC8;
            case Fx.SIERRA -> 0x2EE6A0;
            case Fx.CENTELLA -> 0xFFC83A;
            case Fx.ARPON -> 0x39D6FF;
            case Fx.MORTERO -> 0xFF7A2A;
            case Fx.PRISMA -> 0xF4F6FF;
            case Fx.ENJAMBRE -> 0xFFB800;
            case Fx.CAUSTICA -> 0xB4FF1E;
            case Fx.SOLAR -> 0xFFD23A;
            case Fx.TEMPESTAD -> 0x8AA8FF;
            case Fx.ESQUIRLA -> 0xC07CFF;
            case Fx.CICLON -> 0x7FE8D8;
            case Fx.MINADOR -> 0xFF3A3A;
            case Fx.CENIZA -> 0x3CFF9E;
            case Fx.SAETA -> 0xFFE9A0;
            case Fx.GUADANA -> 0xFF1E46;
            case Fx.PICA -> 0x4FA8FF;
            case Fx.YUNQUE -> 0xFF8C3A;
            case Fx.CHACAL -> 0xE8D06A;
            case Fx.TRABUCO -> 0xE83A2A;
            case Fx.COYOTE -> 0xE8B070;
            case Fx.GRANIZO -> 0xB8E0FF;
            case Fx.LINCE -> 0x40FFD0;
            case Fx.RUGIDO -> 0xFF6A1A;
            case Fx.METEORO -> 0xFF3A1A;
            case Fx.PULSAR -> 0xFF40E0;
            case Fx.FALLA -> 0xE8A23C;
            case Fx.CENTINELA -> 0x34F5C5;
            case Fx.RETORNO -> 0xFFD84A;
            case Fx.MAREA -> 0x3AB4FF;
            case Fx.MANGUAL -> 0xB04CFF;
            case Fx.ARIETE -> 0x5AE0FF;
            // v6: armas realistas (el color de su nombre; la retícula toma este tono)
            case Fx.BISONTE -> 0xD6DADE;
            case Fx.VIBORA -> 0xE8604C;
            case Fx.TEJON -> 0xB8BEC6;
            case Fx.SOMBRA -> 0xC8B08A;
            case Fx.GALGO -> 0xE0BE6A;
            case Fx.AZOR -> 0xC8A878;
            case Fx.CONDOR -> 0xA8B07A;
            case Fx.HURON -> 0xA6ACB4;
            case Fx.BUHO -> 0x8EA4B8;
            case Fx.PIRANA -> 0xE07A5A;
            case Fx.JABALI -> 0xC9A97E;
            case Fx.AVALANCHA -> 0x9FAA78;
            case Fx.DILUVIO -> 0xB4BA8A;
            case Fx.VOLCAN -> 0xE8823A;
            case Fx.MAMUT -> 0xD2B48C;
            default -> 0xFFFFFF;
        };
    }

    /** Núcleo casi blanco con un toque del color del arma. */
    public static int hot(int style) {
        return switch (style) {
            case Fx.AGUJA, Fx.TRUENO, Fx.ESCARCHA -> 0xE8FDFF;
            case Fx.AVISPON -> 0xF0FFD8;
            case Fx.VORTICE, Fx.ECO -> 0xF4E8FF;
            case Fx.CIZALLA, Fx.COLIBRI -> 0xFFE6F4;
            case Fx.SERPENTINA, Fx.CHISPA -> 0xF0F6FF;
            case Fx.SIERRA -> 0xE6FFF4;
            case Fx.ARPON, Fx.CICLON, Fx.PICA -> 0xE8FAFF;
            case Fx.PRISMA -> 0xFFFFFF;
            case Fx.CAUSTICA -> 0xF4FFD0;
            case Fx.TEMPESTAD -> 0xEEF2FF;
            case Fx.ESQUIRLA -> 0xF6E8FF;
            case Fx.CENIZA -> 0xE0FFF0;
            case Fx.GUADANA -> 0xFFE0E6;
            case Fx.GRANIZO, Fx.MAREA, Fx.ARIETE -> 0xEEF8FF;
            case Fx.LINCE, Fx.CENTINELA -> 0xE0FFF6;
            case Fx.PULSAR -> 0xFFE0FA;
            case Fx.MANGUAL -> 0xF4E4FF;
            default -> 0xFFF4DC;
        };
    }

    /** Color de las chispas. */
    public static int spark(int style) {
        return switch (style) {
            case Fx.AGUJA, Fx.TRUENO -> 0x9FF4FF;
            case Fx.AVISPON -> 0xC8FF6A;
            case Fx.VORTICE -> 0xD2A8FF;
            case Fx.CIZALLA -> 0xFF7AB0;
            case Fx.SERPENTINA, Fx.CHISPA -> 0xD8E8FF;
            case Fx.ESCARCHA -> 0xDDFBFF;
            case Fx.ECO -> 0xF0D8FF;
            case Fx.COLIBRI -> 0xFFB0E0;
            case Fx.SIERRA -> 0x9FFFD6;
            case Fx.ARPON -> 0xA8F0FF;
            case Fx.PRISMA -> 0xFFFFFF;
            case Fx.CAUSTICA -> 0xD8FF70;
            case Fx.TEMPESTAD -> 0xC8D8FF;
            case Fx.ESQUIRLA -> 0xE0B8FF;
            case Fx.CICLON -> 0xC8FFF4;
            case Fx.CENIZA -> 0xA8FFD0;
            case Fx.GUADANA -> 0xFF7A90;
            case Fx.PICA -> 0xB8DCFF;
            case Fx.TRABUCO, Fx.METEORO -> 0xFF9A60;
            case Fx.GRANIZO -> 0xD8EEFF;
            case Fx.LINCE, Fx.CENTINELA -> 0xA0FFE6;
            case Fx.PULSAR -> 0xFFA0F0;
            case Fx.RETORNO -> 0xFFE890;
            case Fx.MAREA -> 0xB0E0FF;
            case Fx.MANGUAL -> 0xD8A8FF;
            case Fx.ARIETE -> 0xB0F0FF;
            default -> 0xFFC870;
        };
    }

    /** Colores de los cinco rayos del PRISMA. */
    public static final int[] RAINBOW = {0xFF3B4A, 0xFFB43B, 0x6BFF5A, 0x3BC8FF, 0xB45CFF};

    /** Mezcla lineal de dos colores RGB. */
    public static int mix(int a, int b, float t) {
        float k = Math.max(0.0F, Math.min(1.0F, t));
        int r = Math.round(((a >> 16) & 0xFF) * (1 - k) + ((b >> 16) & 0xFF) * k);
        int g = Math.round(((a >> 8) & 0xFF) * (1 - k) + ((b >> 8) & 0xFF) * k);
        int bl = Math.round((a & 0xFF) * (1 - k) + (b & 0xFF) * k);
        return r << 16 | g << 8 | bl;
    }
}
