package com.proyectox.client.fx;

import com.proyectox.entity.EnergyBolt;
import com.proyectox.entity.Grenade;
import com.proyectox.entity.MicroRocket;
import com.proyectox.entity.PXProjectile;
import com.proyectox.entity.PlasmaBolt;
import com.proyectox.entity.SawDisc;
import com.proyectox.entity.Singularity;
import com.proyectox.entity.SlashWave;
import com.proyectox.entity.SonicWave;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Aspecto de cada proyectil: núcleo, resplandor, estela y detalles propios del arma que lo dispara. */
public final class Looks {
    private Looks() {}

    private static final Vector3f ZERO = new Vector3f();

    private static Vector3f dir(PXProjectile p) {
        Vec3 h = p.heading();
        return new Vector3f((float) h.x, (float) h.y, (float) h.z);
    }

    /** Posiciones de la estela: la actual interpolada seguida de las guardadas. */
    private static List<Vec3> trail(PXProjectile p, float pt, int max) {
        List<Vec3> out = new ArrayList<>();
        out.add(p.getPosition(pt));
        int n = Math.min(max, p.trailSize());
        for (int i = 0; i < n; i++) out.add(p.trailPoint(i));
        return out;
    }

    private static float time(net.minecraft.world.entity.Entity e, float pt) {
        return e.tickCount + pt;
    }

    // ---------------------------------------------------------------- pulsos de energía

    /** AVISPÓN: gota de plasma verde (naranja cuando el cañón está al rojo). */
    public static void plasma(PlasmaBolt e, float pt, Draw d) {
        boolean hot = e.isHot();
        int main = hot ? 0xFF7A1E : 0x8CFF2E;
        int core = hot ? 0xFFF0C8 : 0xF0FFD8;
        Vector3f dir = dir(e);
        float pulse = 0.85F + 0.15F * Mth.sin(time(e, pt) * 2.1F);
        d.trail(FxAtlas.BEAM, trail(e, pt, 6), 0.11F, main, hot ? 0xFF2000 : 0x1E9A00, 0.9F);
        d.cross(true, FxAtlas.BOLT, ZERO, dir, 0.9F, 0.25F, 0.13F, main, 1.0F);
        d.billboard(true, FxAtlas.GLOW, ZERO, 0.42F * pulse, 0.0F, main, 0.85F);
        d.billboard(true, FxAtlas.CORE, ZERO, 0.14F, 0.0F, core, 1.0F);
    }

    /** ROTOR (trazadora), COLIBRÍ (aguja de cristal), HALCÓN (pulso), ESCARCHA (láser de hielo) y BASTIÓN (bala cinética). */
    public static void bolt(EnergyBolt e, float pt, Draw d) {
        Vector3f dir = dir(e);
        float t = time(e, pt);
        switch (e.style()) {
            case EnergyBolt.NEEDLE -> {
                d.trail(FxAtlas.BEAM_THIN, trail(e, pt, 5), 0.06F, 0xFF8FD0, 0x8A2060, 0.8F);
                d.cross(true, FxAtlas.BOLT, ZERO, dir, 0.7F, 0.15F, 0.05F, 0xFFB8E4, 1.0F);
                d.billboard(true, FxAtlas.GLINT, ZERO, 0.16F, t * 0.3F, 0xFFD8F0, 0.9F);
                d.billboard(true, FxAtlas.GLOW, ZERO, 0.2F, 0.0F, 0xFF6FC8, 0.6F);
            }
            case EnergyBolt.DRONE -> {
                d.trail(FxAtlas.BEAM, trail(e, pt, 5), 0.08F, 0xFFB13B, 0x7A3000, 0.8F);
                d.cross(true, FxAtlas.BOLT, ZERO, dir, 0.7F, 0.2F, 0.09F, 0xFFC060, 1.0F);
                d.billboard(true, FxAtlas.GLOW, ZERO, 0.3F, 0.0F, 0xFFA235, 0.8F);
                d.billboard(true, FxAtlas.CORE, ZERO, 0.1F, 0.0F, 0xFFF2D8, 1.0F);
            }
            case EnergyBolt.FROST -> {
                d.trail(FxAtlas.BEAM_NOISE, trail(e, pt, 7), 0.1F, 0xBFF6FF, 0x2A8AFF, 0.85F);
                d.cross(true, FxAtlas.BOLT, ZERO, dir, 1.1F, 0.2F, 0.08F, 0xBFF6FF, 1.0F);
                d.billboard(true, FxAtlas.SNOW, ZERO, 0.2F, t * 0.25F, 0xE8FDFF, 0.9F);
                d.billboard(true, FxAtlas.GLOW, ZERO, 0.32F, 0.0F, 0x7FE4FF, 0.8F);
                d.billboard(true, FxAtlas.CORE, ZERO, 0.09F, 0.0F, 0xFFFFFF, 1.0F);
            }
            case EnergyBolt.BULLET -> {
                d.trail(FxAtlas.BEAM, trail(e, pt, 5), 0.07F, 0xFFD8A8, 0x8A4A10, 0.8F);
                d.cross(true, FxAtlas.BOLT, ZERO, dir, 1.0F, 0.2F, 0.08F, 0xFFC48A, 1.0F);
                d.billboard(true, FxAtlas.GLOW, ZERO, 0.28F, 0.0F, 0xFFB070, 0.75F);
                d.billboard(true, FxAtlas.CORE, ZERO, 0.09F, 0.0F, 0xFFF4E0, 1.0F);
            }
            default -> {
                // trazadora del ROTOR: larga y fina
                d.cross(true, FxAtlas.BOLT, ZERO, dir, 2.4F, 0.2F, 0.06F, 0xFFC85A, 1.0F);
                d.billboard(true, FxAtlas.GLOW, ZERO, 0.22F, 0.0F, 0xFFB040, 0.7F);
                d.billboard(true, FxAtlas.CORE, ZERO, 0.07F, 0.0F, 0xFFF6E0, 1.0F);
            }
        }
    }

    // ---------------------------------------------------------------- explosivos

    /** COLMENA: microcohete con llama de escape parpadeante y luz roja de guiado. */
    public static void rocket(MicroRocket e, float pt, Draw d) {
        Vector3f dir = dir(e);
        float t = time(e, pt);
        float flick = 0.8F + 0.2F * Mth.sin(t * 5.3F) + 0.1F * Mth.sin(t * 13.1F);
        d.trail(FxAtlas.BEAM, trail(e, pt, 8), 0.12F, 0xFFB060, 0x601000, 0.7F);
        // llama de escape (desde la cola hacia atrás)
        Vector3f back = new Vector3f(dir).negate();
        Vector3f tail = new Vector3f(back).mul(0.25F);
        d.cross(true, FxAtlas.FLASH_SIDE, tail, back, 0.0F, 0.9F * flick, 0.16F * flick, 0xFFB050, 1.0F);
        d.billboard(true, FxAtlas.GLOW, tail, 0.45F * flick, 0.0F, 0xFF7A30, 0.9F);
        d.billboard(true, FxAtlas.CORE, tail, 0.12F, 0.0F, 0xFFF0D0, 1.0F);
        // luz de guiado
        if (((int) (t * 2)) % 2 == 0) d.billboard(true, FxAtlas.CORE, new Vector3f(dir).mul(0.22F), 0.07F, 0.0F, 0xFF3020, 1.0F);
    }

    /** TRITURADORA: granada metálica que gira, con su banda luminosa ácida. */
    public static void grenade(Grenade e, float pt, Draw d) {
        boolean small = e.kind() == Grenade.BOMBLET;
        float t = time(e, pt);
        float size = small ? 0.11F : 0.2F;
        float blink = 0.6F + 0.4F * Mth.sin(t * (small ? 1.8F : 1.1F));
        d.billboard(true, FxAtlas.GLOW, ZERO, size * 2.4F * blink, 0.0F, 0xC8E04A, 0.6F);
        d.billboard(false, FxAtlas.GRENADE, ZERO, size, t * 0.35F, 0xFFFFFF, 1.0F);
        d.billboard(true, FxAtlas.CORE, ZERO, size * 0.5F * blink, 0.0F, 0xF4FFB0, 0.8F);
    }

    // ---------------------------------------------------------------- especiales

    /** SIERRA: hoja metálica girando a toda velocidad con su halo verde. */
    public static void disc(SawDisc e, float pt, Draw d) {
        float t = time(e, pt);
        Vector3f dir = dir(e);
        Vector3f normal = new Vector3f(0, 1, 0);
        Vector3f tangent = new Vector3f(dir.x, 0, dir.z);
        if (tangent.lengthSquared() < 1.0E-6) tangent.set(1, 0, 0);
        d.trail(FxAtlas.BEAM, trail(e, pt, 6), 0.18F, 0x2EE6A0, 0x0A5A40, 0.55F);
        d.flat(true, FxAtlas.GLOW, ZERO, normal, tangent, 0.7F, 0.7F, 0.0F, 0x2EE6A0, 0.55F);
        d.flat(false, FxAtlas.SAW, ZERO, normal, tangent, 0.42F, 0.42F, -t * 1.6F, 0xFFFFFF, 1.0F);
        d.flat(true, FxAtlas.SAW_BLUR, new Vector3f(0, 0.01F, 0), normal, tangent, 0.45F, 0.45F, -t * 1.6F, 0x7FFFD0, 0.9F);
    }

    /** VÓRTICE: horizonte de sucesos negro con disco de acreción; abierto, un remolino gigante. */
    public static void singularity(Singularity e, float pt, Draw d) {
        float t = time(e, pt);
        int main = 0xA45CFF;
        if (!e.isOpen()) {
            Vector3f tilt = new Vector3f(0.35F, 1.0F, 0.2F).normalize();
            d.trail(FxAtlas.BEAM, trail(e, pt, 8), 0.2F, main, 0x200040, 0.7F);
            d.billboard(true, FxAtlas.GLOW, ZERO, 0.9F + 0.1F * Mth.sin(t * 0.8F), 0.0F, main, 0.8F);
            d.flat(true, FxAtlas.ACCRETION, ZERO, tilt, new Vector3f(1, 0, 0), 0.75F, 0.75F, t * 0.35F, 0xD8B0FF, 1.0F);
            d.billboard(false, FxAtlas.ORB_CORE, ZERO, 0.32F, 0.0F, 0xFFFFFF, 1.0F);
            d.billboard(true, FxAtlas.RING, ZERO, 0.36F, 0.0F, 0xF0E0FF, 0.8F);
            return;
        }
        float open = e.openTicks() + pt;
        float grow = Math.min(1.0F, open / 6.0F);
        float end = Math.max(0.0F, (open - (Singularity.VORTEX_TICKS - 8)) / 8.0F);
        float r = (float) Singularity.PULL_RADIUS * 0.75F * grow * (1.0F - end * 0.8F);
        Vector3f up = new Vector3f(0, 1, 0);
        d.flat(true, FxAtlas.VORTEX, ZERO, up, new Vector3f(1, 0, 0), r, r, t * 0.6F, main, 0.9F);
        d.flat(true, FxAtlas.VORTEX, new Vector3f(0, 0.02F, 0), up, new Vector3f(1, 0, 0), r * 0.6F, r * 0.6F, t * 1.1F, 0xE0C8FF, 0.7F);
        d.flat(true, FxAtlas.ACCRETION, ZERO, up, new Vector3f(1, 0, 0), 1.6F * grow, 1.6F * grow, t * 0.5F, 0xD8B0FF, 1.0F);
        d.billboard(true, FxAtlas.GLOW, ZERO, (1.6F + end * 3.0F) * grow, 0.0F, main, 0.9F);
        d.billboard(false, FxAtlas.ORB_CORE, ZERO, 0.6F * grow * (1.0F - end * 0.7F), 0.0F, 0xFFFFFF, 1.0F);
        d.billboard(true, FxAtlas.RING, ZERO, 0.65F * grow, 0.0F, 0xF4E8FF, 0.9F);
    }

    /** CIZALLA: media luna de plasma que avanza de canto. */
    public static void slash(SlashWave e, float pt, Draw d) {
        float t = time(e, pt);
        Vector3f dir = dir(e);
        Vector3f side = new Vector3f(dir).cross(new Vector3f(0, 1, 0));
        if (side.lengthSquared() < 1.0E-6) side.set(1, 0, 0);
        side.normalize();
        Vector3f normal = new Vector3f(side).cross(dir).normalize();
        float fade = 1.0F - Math.min(0.7F, t / 26.0F);
        // la curva del sprite (abajo en la textura) mira hacia delante
        d.flat(true, FxAtlas.CRESCENT, ZERO, normal, side, 1.3F, 1.3F, 0.0F, 0xFF2E7E, fade);
        d.flat(true, FxAtlas.CRESCENT, new Vector3f(dir).mul(0.1F), normal, side, 1.1F, 1.1F, 0.0F, 0xFFE0EE, fade * 0.8F);
        d.billboard(true, FxAtlas.GLOW, ZERO, 0.8F, 0.0F, 0xFF2E7E, 0.5F * fade);
    }

    /** ECO: anillos sónicos que se ensanchan mientras avanzan. */
    public static void wave(SonicWave e, float pt, Draw d) {
        float age = e.tickCount + pt;
        Vec3 dv = e.direction();
        Vector3f dir = new Vector3f((float) dv.x, (float) dv.y, (float) dv.z);
        Vector3f side = Math.abs(dir.y) < 0.95F ? new Vector3f(0, 1, 0).cross(dir) : new Vector3f(1, 0, 0).cross(dir);
        float fade = 1.0F - Math.max(0.0F, (age - SonicWave.LIFE * 0.6F) / (SonicWave.LIFE * 0.4F));
        for (int i = 0; i < 4; i++) {
            float a = age - i * 1.5F;
            if (a < 0) continue;
            float r = SonicWave.radius(a);
            Vector3f c = new Vector3f(dir).mul((float) (-i * 1.5F * SonicWave.SPEED / 1.5F));
            float alpha = fade * (1.0F - i * 0.22F);
            d.flat(true, i == 0 ? FxAtlas.SHOCK : FxAtlas.SOUNDWAVE, c, dir, side, r, r, a * 0.05F, i == 0 ? 0xF0D8FF : 0xD9A8FF, alpha * 0.8F);
        }
        d.billboard(true, FxAtlas.GLOW, ZERO, SonicWave.radius(age) * 0.6F, 0.0F, 0xD9A8FF, 0.35F * fade);
    }
}
