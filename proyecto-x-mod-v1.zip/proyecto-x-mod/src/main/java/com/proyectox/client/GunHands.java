package com.proyectox.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.proyectox.client.fx.Draw;
import com.proyectox.client.fx.FxAtlas;
import com.proyectox.client.fx.Muzzle;
import com.proyectox.client.fx.Palette;
import com.proyectox.fx.Fx;
import com.proyectox.item.BastionItem;
import com.proyectox.item.GunItem;
import com.proyectox.item.PXWeapon;
import com.proyectox.item.TaladroItem;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Cómo se sostienen las armas: pose de los brazos en tercera persona y, en primera persona, la posición
 * de cadera o de apuntado (el arma sube al centro de la vista), el retroceso, el fogonazo pegado a la
 * boca del cañón y el giro de la broca del TALADRO.
 */
public final class GunHands implements IClientItemExtensions {
    private final PXWeapon weapon;
    @Nullable
    private final GunGeometry.Data geo;

    public GunHands(PXWeapon weapon) {
        this.weapon = weapon;
        this.geo = GunGeometry.of(weapon.key());
    }

    @Override
    public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
        if (this.weapon instanceof BastionItem) {
            return entity.isUsingItem() && entity.getUseItem() == stack ? HumanoidModel.ArmPose.BLOCK : HumanoidModel.ArmPose.CROSSBOW_HOLD;
        }
        if (this.weapon instanceof GunItem) {
            boolean aiming = entity == Minecraft.getInstance().player && Muzzle.aim(1.0F) > 0.5F;
            return aiming ? HumanoidModel.ArmPose.BOW_AND_ARROW : HumanoidModel.ArmPose.CROSSBOW_HOLD;
        }
        if (this.weapon instanceof TaladroItem) return HumanoidModel.ArmPose.CROSSBOW_HOLD;
        return null;
    }

    @Override
    public boolean applyForgeHandTransform(PoseStack pose, LocalPlayer player, HumanoidArm arm, ItemStack stack, float pt,
                                           float equip, float swing) {
        boolean main = player.getMainHandItem() == stack;
        int side = arm == HumanoidArm.RIGHT ? 1 : -1;
        if (this.weapon instanceof GunItem gun && gun.aims() && this.geo != null) {
            float aim = main ? Muzzle.aim(pt) : 0.0F;
            float rec = main ? Muzzle.recoil(pt) : 0.0F;
            float x = Mth.lerp(aim, side * 0.56F, side * this.geo.adsX());
            float y = Mth.lerp(aim, -0.52F, this.geo.adsY()) + equip * -0.6F;
            float z = Mth.lerp(aim, -0.72F, this.geo.adsZ());
            float kick = gun.kick();
            pose.translate(x, y + rec * 0.012F, z + rec * (0.04F + 0.1F * kick));
            if (aim > 0.0F) pose.mulPose(Axis.YP.rotationDegrees(-side * this.geo.yaw() * aim));
            if (rec > 0.0F) {
                pose.mulPose(Axis.XP.rotationDegrees(rec * (3.0F + 9.0F * kick)));
                pose.mulPose(Axis.ZP.rotationDegrees(side * rec * 2.0F * (Muzzle.flashSeed() - 0.5F)));
            }
            if (main) muzzleFlash(pose, side, pt);
            return true;
        }
        if (this.weapon instanceof TaladroItem && main && Muzzle.spinning()) {
            // la broca gira sobre su eje y la perforadora tiembla
            float shake = 0.004F;
            float t = player.tickCount + pt;
            pose.translate(side * 0.56F + Mth.sin(t * 2.9F) * shake, -0.52F + equip * -0.6F + Mth.cos(t * 3.7F) * shake, -0.72F);
            float[] a = GunGeometry.DRILL_AXIS;
            pose.translate(side * a[0], a[1], a[2]);
            pose.mulPose(new Quaternionf().rotationAxis((float) Math.toRadians(Muzzle.spin(pt)), side * a[3], a[4], a[5]));
            pose.translate(-side * a[0], -a[1], -a[2]);
            return true;
        }
        return false;
    }

    /** Fogonazo dibujado en el espacio de la mano, justo en la boca del cañón. */
    private void muzzleFlash(PoseStack pose, int side, float pt) {
        float f = Muzzle.flash(pt);
        if (f <= 0.0F || this.geo == null) return;
        int style = Muzzle.flashStyle();
        if (style < 0) return;
        int main = Palette.main(style);
        int hot = Palette.hot(style);
        float k = switch (style) {
            case Fx.REMACHE, Fx.ECO -> 1.5F;
            case Fx.AGUJA, Fx.TRITURADORA, Fx.VORTICE, Fx.COLMENA -> 1.2F;
            case Fx.ROTOR, Fx.COLIBRI -> 0.75F;
            case Fx.TRUENO, Fx.CHISPA, Fx.SOPLETE -> 0.55F;
            default -> 1.0F;
        };
        Draw d = new Draw(pose, Minecraft.getInstance().renderBuffers().bufferSource(), new Vector3f(0, 0, 0), new Quaternionf());
        Vector3f tip = new Vector3f(side * this.geo.tipX(), this.geo.tipY(), this.geo.tipZ());
        float roll = Muzzle.flashSeed() * 6.2832F;
        boolean beamWeapon = style == Fx.TRUENO || style == Fx.CHISPA || style == Fx.SOPLETE;
        d.billboard(true, FxAtlas.GLOW, tip, 0.22F * k, 0.0F, main, 0.75F * f);
        if (!beamWeapon) {
            d.billboard(true, style % 2 == 0 ? FxAtlas.STAR4 : FxAtlas.STAR6, tip, 0.13F * k, roll, hot, f);
            d.cross(true, FxAtlas.FLASH_SIDE, tip, new Vector3f(0, 0, -1), 0.0F, 0.32F * k * (0.7F + 0.3F * f), 0.075F * k, hot, f);
        }
        d.billboard(true, FxAtlas.CORE, tip, 0.05F * k, 0.0F, 0xFFFFFF, f);
    }
}
