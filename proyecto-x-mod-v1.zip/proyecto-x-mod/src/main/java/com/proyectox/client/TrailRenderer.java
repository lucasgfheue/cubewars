package com.proyectox.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.proyectox.ProyectoX;
import com.proyectox.entity.RailTrail;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/** Haz de un disparo de riel: cinta luminosa orientada hacia la cámara que se desvanece. */
public class TrailRenderer extends EntityRenderer<RailTrail> {
    public static final ResourceLocation BEAM = ProyectoX.id("textures/entity/haz.png");

    public TrailRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public boolean shouldRender(RailTrail entity, Frustum frustum, double camX, double camY, double camZ) {
        return true;
    }

    @Override
    public void render(RailTrail trail, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        Vec3 d = trail.delta();
        float age = (trail.tickCount + partialTick) / trail.life();
        if (d.lengthSqr() < 1.0E-4 || age >= 1.0F) return;
        float fade = (1.0F - age) * (1.0F - age);
        float width = trail.width() * (0.5F + 0.5F * (1.0F - age));

        Vec3 cam = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
        Vec3 origin = trail.getPosition(partialTick);
        Vec3 toCam = cam.subtract(origin.add(d.scale(0.5)));
        Vec3 side = d.cross(toCam);
        if (side.lengthSqr() < 1.0E-6) side = d.cross(new Vec3(0, 1, 0));
        if (side.lengthSqr() < 1.0E-6) side = new Vec3(1, 0, 0);
        side = side.normalize();

        VertexConsumer vc = buffers.getBuffer(RenderType.eyes(BEAM));
        PoseStack.Pose p = pose.last();
        int rgb = trail.color();
        ribbon(vc, p, d, side.scale(width), rgb, 0.85F * fade);
        ribbon(vc, p, d, side.scale(width * 0.35F), 0xFFFFFF, 0.9F * fade);
        super.render(trail, yaw, partialTick, pose, buffers, light);
    }

    private static void ribbon(VertexConsumer vc, PoseStack.Pose p, Vec3 d, Vec3 s, int rgb, float intensity) {
        float r = ((rgb >> 16) & 0xFF) / 255F * intensity;
        float g = ((rgb >> 8) & 0xFF) / 255F * intensity;
        float b = (rgb & 0xFF) / 255F * intensity;
        Vec3 a0 = s.scale(-1.0);
        Vec3 a1 = s;
        Vec3 b1 = d.add(s);
        Vec3 b0 = d.subtract(s);
        vertex(vc, p, a0, 0.0F, 0.0F, r, g, b);
        vertex(vc, p, a1, 0.0F, 1.0F, r, g, b);
        vertex(vc, p, b1, 1.0F, 1.0F, r, g, b);
        vertex(vc, p, b0, 1.0F, 0.0F, r, g, b);

        vertex(vc, p, b0, 1.0F, 0.0F, r, g, b);
        vertex(vc, p, b1, 1.0F, 1.0F, r, g, b);
        vertex(vc, p, a1, 0.0F, 1.0F, r, g, b);
        vertex(vc, p, a0, 0.0F, 0.0F, r, g, b);
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose p, Vec3 v, float u, float w, float r, float g, float b) {
        vc.addVertex(p, (float) v.x, (float) v.y, (float) v.z)
                .setColor(r, g, b, 1.0F)
                .setUv(u, w)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(p, 0.0F, 1.0F, 0.0F);
    }

    @Override
    public ResourceLocation getTextureLocation(RailTrail entity) {
        return BEAM;
    }
}
