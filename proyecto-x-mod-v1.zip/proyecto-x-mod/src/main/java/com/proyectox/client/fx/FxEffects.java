package com.proyectox.client.fx;

import com.proyectox.client.Reticle;
import com.proyectox.client.fx.FxParticle.Mode;
import com.proyectox.entity.Drone;
import com.proyectox.entity.EnergyBolt;
import com.proyectox.entity.Grenade;
import com.proyectox.entity.MicroRocket;
import com.proyectox.entity.PXProjectile;
import com.proyectox.entity.PlasmaBolt;
import com.proyectox.entity.SawDisc;
import com.proyectox.entity.Singularity;
import com.proyectox.entity.SlashWave;
import com.proyectox.fx.Fx;
import com.proyectox.item.GunItem;
import com.proyectox.network.FxPayload;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Composición de los efectos visuales en el cliente: cada aviso del servidor ({@link FxPayload})
 * se convierte en un conjunto de partículas HD, haces y anillos con el estilo de su arma.
 */
public final class FxEffects {
    private FxEffects() {}

    private static final Vec3 UP = new Vec3(0, 1, 0);

    @Nullable
    private static ClientLevel level() {
        return Minecraft.getInstance().level;
    }

    private static RandomSource rnd() {
        ClientLevel l = level();
        return l != null ? l.random : RandomSource.create();
    }

    /** Partícula nueva (sin añadir todavía). */
    private static FxParticle p(Vec3 pos, FxAtlas.Sprite s, int life) {
        return new FxParticle(level(), pos, s, life);
    }

    private static float rf(float a, float b) {
        return a + rnd().nextFloat() * (b - a);
    }

    private static Vec3 randomDir() {
        RandomSource r = rnd();
        double z = r.nextDouble() * 2.0 - 1.0;
        double t = r.nextDouble() * Math.PI * 2.0;
        double s = Math.sqrt(1.0 - z * z);
        return new Vec3(s * Math.cos(t), z, s * Math.sin(t));
    }

    /** Dirección dentro de un cono de {@code deg} grados alrededor de {@code dir}. */
    private static Vec3 cone(Vec3 dir, double deg) {
        Vec3 n = dir.lengthSqr() < 1.0E-8 ? UP : dir.normalize();
        Vec3 a = Math.abs(n.y) < 0.99 ? UP : new Vec3(1, 0, 0);
        Vec3 u = n.cross(a).normalize();
        Vec3 v = n.cross(u).normalize();
        RandomSource r = rnd();
        double ang = r.nextDouble() * Math.PI * 2.0;
        double mag = Math.tan(Math.toRadians(deg)) * Math.sqrt(r.nextDouble());
        return n.add(u.scale(Math.cos(ang) * mag)).add(v.scale(Math.sin(ang) * mag)).normalize();
    }

    // ================================================================ entrada desde la red

    public static void play(FxPayload f) {
        ClientLevel level = level();
        if (level == null) return;
        Vec3 a = f.from();
        Vec3 b = f.to();
        switch (f.kind()) {
            case Fx.MUZZLE -> muzzle(f.style(), a, b, level.getEntity(f.entity()));
            case Fx.BEAM -> rail(a, b, f.value(), level.getEntity(f.entity()));
            case Fx.IMPACT -> impact(f.style(), a, b, f.value());
            case Fx.EXPLOSION -> explosion(f.style(), a, f.value());
            case Fx.ARC -> arc(f.style(), a, b, f.value(), f.entity() >= 0 ? level.getEntity(f.entity()) : null);
            case Fx.TRACER -> tracer(f.style(), a, b, level.getEntity(f.entity()));
            case Fx.FLAME -> flame(a, b, f.value(), level.getEntity(f.entity()));
            case Fx.LASER -> laser(a, b, f.value(), level.getEntity(f.entity()));
            case Fx.ROPE -> rope(a, b, f.value(), level.getEntity(f.entity()), f.other() >= 0 ? level.getEntity(f.other()) : null);
            case Fx.DRILL -> drill(a, b, (int) f.value());
            case Fx.LOCK -> lock(level.getEntity(f.entity()), (int) f.value());
            case Fx.MELEE -> melee(f.style(), a, b, f.value());
            case Fx.SHIELD -> shield(a, b);
            case Fx.HITMARK -> Reticle.hit(f.style() == 1);
            case Fx.DRONE -> drone(a, b);
            case Fx.VORTEX -> vortexOpen(a, f.value());
            default -> {}
        }
    }

    // ================================================================ piezas básicas

    /** Destello: halo de color y núcleo blanco. */
    private static void flash(Vec3 pos, int color, int hot, float size, int life) {
        p(pos, FxAtlas.GLOW, life + 1).size(size, size * 1.3F, 1.0F).color(color).alpha(0.9F, 0.0F).spawn();
        p(pos, FxAtlas.CORE, life).size(size * 0.4F, size * 0.2F, 1.0F).color(hot).alpha(1.0F, 0.0F).spawn();
    }

    private static void sparks(Vec3 pos, Vec3 dir, double coneDeg, int n, int color, float speed, float size, int life, double gravity) {
        for (int i = 0; i < n; i++) {
            Vec3 d = coneDeg >= 180.0 ? randomDir() : cone(dir, coneDeg);
            float s = speed * rf(0.4F, 1.0F);
            p(pos, FxAtlas.SPARK, (int) (life * rf(0.6F, 1.2F))).mode(Mode.VELOCITY).vel(d.scale(s)).drag(0.86).gravity(gravity)
                    .size(size, size * 0.4F, 1.0F).aspect(3.0F).stretch(1.6F).color(0xFFFFFF, color).alpha(1.0F, 0.0F).spawn();
        }
    }

    private static void smoke(Vec3 pos, int n, float size, int life, int shade, Vec3 drift, float spread) {
        for (int i = 0; i < n; i++) {
            Vec3 at = pos.add(randomDir().scale(spread * rnd().nextFloat()));
            Vec3 v = drift.add(randomDir().scale(0.02));
            p(at, FxAtlas.SMOKE[rnd().nextInt(FxAtlas.SMOKE.length)], (int) (life * rf(0.7F, 1.3F))).soft().vel(v).drag(0.92)
                    .size(size * rf(0.6F, 1.0F), size * rf(1.8F, 2.6F), 0.6F).color(shade, Palette.mix(shade, 0x101010, 0.3F))
                    .alpha(rf(0.35F, 0.6F), 0.0F).fadeIn(0.1F).roll(rf(0.0F, 6.28F), rf(-0.03F, 0.03F)).spawn();
        }
    }

    private static void ring(Vec3 pos, Vec3 normal, FxAtlas.Sprite sprite, int color, float from, float to, int life, float alpha) {
        p(pos, sprite, life).mode(Mode.FIXED).axis(normal).size(from, to, 0.5F).color(color).alpha(alpha, 0.0F).roll(rf(0.0F, 6.28F), 0.0F).spawn();
    }

    private static void embers(Vec3 pos, int n, int color, float speed, int life) {
        for (int i = 0; i < n; i++) {
            p(pos, FxAtlas.EMBER, (int) (life * rf(0.5F, 1.4F))).vel(randomDir().scale(speed * rf(0.3F, 1.0F)).add(0, 0.03, 0)).drag(0.9).gravity(-0.002)
                    .size(rf(0.03F, 0.07F), 0.0F, 1.0F).color(0xFFFFFF, color).alpha(1.0F, 0.2F).spawn();
        }
    }

    // ================================================================ fogonazos

    private static void muzzle(int style, Vec3 pos, Vec3 dir, @Nullable Entity shooter) {
        Vec3 d = dir.lengthSqr() < 1.0E-6 ? UP : dir.normalize();
        int main = Palette.main(style);
        int hot = Palette.hot(style);
        boolean local = shooter != null && Muzzle.firstPerson(shooter);
        boolean inHand = false;
        if (local && shooter instanceof Player player && player.getMainHandItem().getItem() instanceof GunItem gun) {
            // en primera persona el fogonazo grande se dibuja pegado al arma (GunHands)
            Muzzle.fired(style, gun.kick());
            inHand = gun.aims() && com.proyectox.client.GunGeometry.of(gun.key()) != null;
            pos = Muzzle.world(shooter, 1.0F);
        }
        float big = switch (style) {
            case Fx.REMACHE, Fx.ECO -> 1.4F;
            case Fx.AGUJA, Fx.TRITURADORA, Fx.VORTICE, Fx.COLMENA -> 1.15F;
            case Fx.ROTOR, Fx.COLIBRI, Fx.HALCON -> 0.7F;
            default -> 0.9F;
        };
        if (!inHand) {
            // estrella frontal + lengua lateral + halo
            p(pos, style % 2 == 0 ? FxAtlas.STAR4 : FxAtlas.STAR6, 2).size(0.32F * big, 0.42F * big, 1.0F).color(hot, main)
                    .roll(rf(0.0F, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
            p(pos, FxAtlas.FLASH_SIDE, 2).mode(Mode.AXIS).axis(d).size(0.16F * big).aspect(2.2F).color(hot, main).alpha(1.0F, 0.0F).spawn();
            p(pos, FxAtlas.GLOW, 3).size(0.6F * big, 0.8F * big, 1.0F).color(main).alpha(0.55F, 0.0F).spawn();
        }
        switch (style) {
            case Fx.AGUJA -> {
                ring(pos.add(d.scale(0.2)), d, FxAtlas.RING, main, 0.08F, 0.7F, 7, 0.9F);
                ring(pos.add(d.scale(0.5)), d, FxAtlas.RING_NOISE, hot, 0.05F, 0.45F, 5, 0.7F);
                p(pos, FxAtlas.LENS, 3).size(0.12F, 0.05F, 1.0F).aspect(9.0F).color(main).alpha(0.8F, 0.0F).spawn();
                sparks(pos, d, 35, 6, Palette.spark(style), 0.35F, 0.05F, 6, 0.0);
            }
            case Fx.REMACHE -> {
                sparks(pos, d, 28, 14, 0xFFB050, 0.7F, 0.06F, 7, 0.02);
                smoke(pos.add(d.scale(0.4)), 4, 0.18F, 26, 0x9A9692, d.scale(0.05).add(0, 0.01, 0), 0.2F);
                ring(pos.add(d.scale(0.3)), d, FxAtlas.SHOCK, 0xFFD8A0, 0.1F, 0.9F, 5, 0.5F);
            }
            case Fx.COLMENA -> {
                // escape trasero del lanzacohetes
                smoke(pos.subtract(d.scale(0.9)), 5, 0.25F, 30, 0xB0ACA8, d.scale(-0.08).add(0, 0.015, 0), 0.3F);
                p(pos.subtract(d.scale(0.6)), FxAtlas.FLASH_SIDE, 3).mode(Mode.AXIS).axis(d.reverse()).size(0.22F).aspect(2.4F)
                        .color(0xFFE0A0, 0xFF5A20).alpha(0.9F, 0.0F).spawn();
                sparks(pos, d, 20, 5, 0xFFB060, 0.4F, 0.05F, 6, 0.01);
            }
            case Fx.TRITURADORA -> {
                ring(pos.add(d.scale(0.2)), d, FxAtlas.SHOCK, 0xE8F0A0, 0.1F, 0.8F, 6, 0.6F);
                smoke(pos.add(d.scale(0.3)), 4, 0.2F, 28, 0xA8A89A, d.scale(0.04).add(0, 0.01, 0), 0.2F);
            }
            case Fx.VORTICE -> {
                ring(pos.add(d.scale(0.3)), d, FxAtlas.ACCRETION, main, 0.9F, 0.15F, 8, 0.9F);
                ring(pos.add(d.scale(0.3)), d, FxAtlas.RING, hot, 0.1F, 1.0F, 6, 0.7F);
            }
            case Fx.ECO -> {
                for (int i = 0; i < 3; i++) {
                    ring(pos.add(d.scale(0.4 + i * 0.5)), d, FxAtlas.SOUNDWAVE, main, 0.2F + i * 0.1F, 1.3F + i * 0.4F, 8 + i * 2, 0.8F - i * 0.2F);
                }
            }
            case Fx.ESCARCHA -> {
                p(pos, FxAtlas.SNOW, 8).vel(d.scale(0.12).add(randomDir().scale(0.03))).size(0.08F, 0.02F, 1.0F).color(0xFFFFFF, main)
                        .roll(rf(0, 6.28F), rf(-0.3F, 0.3F)).alpha(1.0F, 0.0F).spawn();
                smoke(pos.add(d.scale(0.2)), 1, 0.12F, 14, 0xD8F4FF, d.scale(0.05), 0.05F);
            }
            case Fx.COLIBRI -> p(pos, FxAtlas.GLINT, 3).size(0.18F, 0.05F, 1.0F).color(main).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
            case Fx.SIERRA -> {
                ring(pos.add(d.scale(0.25)), d, FxAtlas.SAW_BLUR, main, 0.15F, 0.55F, 5, 0.8F);
                sparks(pos, d, 40, 6, Palette.spark(style), 0.4F, 0.05F, 6, 0.02);
            }
            case Fx.BASTION -> ring(pos.add(d.scale(0.2)), d, FxAtlas.HEX, main, 0.12F, 0.4F, 4, 0.7F);
            case Fx.CIZALLA -> p(pos.add(d.scale(0.5)), FxAtlas.CRESCENT, 5).mode(Mode.FIXED).axis(d).size(0.6F, 1.0F, 0.5F).color(hot, main)
                    .alpha(1.0F, 0.0F).spawn();
            case Fx.AVISPON_HOT -> embers(pos, 2, 0xFF7A20, 0.08F, 10);
            case Fx.ROTOR -> {
                if (rnd().nextFloat() < 0.4F) smoke(pos.add(d.scale(0.2)), 1, 0.1F, 16, 0xA0A0A0, d.scale(0.04), 0.05F);
            }
            default -> {}
        }
    }

    // ================================================================ impactos

    private static void impact(int style, Vec3 pos, Vec3 normal, float strength) {
        Vec3 n = normal.lengthSqr() < 1.0E-6 ? UP : normal.normalize();
        int main = Palette.main(style);
        int hot = Palette.hot(style);
        int spark = Palette.spark(style);
        Vec3 at = pos.add(n.scale(0.05));
        switch (style) {
            case Fx.AGUJA -> {
                flash(at, main, hot, 0.7F, 5);
                ring(at, n, FxAtlas.RING, main, 0.1F, 1.0F, 8, 0.9F);
                sparks(at, n, 70, 14, spark, 0.5F, 0.05F, 9, 0.01);
                for (int i = 0; i < 4; i++) {
                    p(at.add(randomDir().scale(0.3)), FxAtlas.GLINT, 10 + rnd().nextInt(8)).size(0.12F, 0.0F, 1.0F).color(hot, main)
                            .roll(rf(0, 6.28F), 0.0F).vel(randomDir().scale(0.02)).alpha(1.0F, 0.0F).spawn();
                }
            }
            case Fx.AVISPON, Fx.AVISPON_HOT -> {
                flash(at, main, hot, 0.35F, 3);
                ring(at, n, FxAtlas.RING_NOISE, main, 0.05F, 0.45F, 6, 0.8F);
                for (int i = 0; i < 6; i++) {
                    p(at, FxAtlas.EMBER, 10 + rnd().nextInt(8)).vel(cone(n, 60).scale(rf(0.08F, 0.22F))).gravity(0.02).drag(0.9)
                            .size(0.05F, 0.0F, 1.0F).color(hot, main).alpha(1.0F, 0.3F).spawn();
                }
                if (style == Fx.AVISPON_HOT) {
                    p(at, FxAtlas.FLAME[0], 10).frames(FxAtlas.FLAME, true).size(0.15F, 0.3F, 1.0F).vel(n.scale(0.02).add(0, 0.03, 0))
                            .color(0xFFE0A0, 0xFF4010).alpha(0.9F, 0.0F).spawn();
                }
            }
            case Fx.CHISPA -> {
                flash(at, main, hot, 0.4F, 3);
                sparks(at, n, 80, 8, 0xEAF2FF, 0.45F, 0.04F, 6, 0.02);
                for (int i = 0; i < 2; i++) {
                    Vec3 end = at.add(cone(n, 70).scale(rf(0.6F, 1.4F)));
                    new FxBeam(level(), at, end, 3).sprite(FxAtlas.BEAM_THIN).jagged(0.15F, 1, rnd().nextLong()).width(0.04F, 0.02F)
                            .color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
                }
            }
            case Fx.ESCARCHA -> {
                flash(at, main, hot, 0.35F, 3);
                for (int i = 0; i < 6; i++) {
                    p(at, FxAtlas.SHARD, 14 + rnd().nextInt(10)).soft().vel(cone(n, 70).scale(rf(0.1F, 0.25F))).gravity(0.03).drag(0.93)
                            .size(rf(0.05F, 0.1F), 0.02F, 1.0F).color(0xFFFFFF, 0xC8F4FF).roll(rf(0, 6.28F), rf(-0.4F, 0.4F)).alpha(0.95F, 0.0F).spawn();
                }
                p(at, FxAtlas.SNOW, 12).size(0.15F, 0.05F, 1.0F).color(0xFFFFFF, main).roll(rf(0, 6.28F), 0.15F).alpha(1.0F, 0.0F).spawn();
                smoke(at, 2, 0.15F, 18, 0xE0F6FF, n.scale(0.02), 0.1F);
            }
            case Fx.COLIBRI -> {
                flash(at, main, hot, 0.25F, 3);
                for (int i = 0; i < 4; i++) {
                    p(at, FxAtlas.SHARD, 10 + rnd().nextInt(6)).soft().vel(cone(n, 70).scale(rf(0.08F, 0.2F))).gravity(0.03)
                            .size(0.04F, 0.01F, 1.0F).color(0xFFD8F0, main).roll(rf(0, 6.28F), rf(-0.5F, 0.5F)).alpha(0.9F, 0.0F).spawn();
                }
            }
            case Fx.REMACHE -> {
                p(at, FxAtlas.CORE, 3).size(0.2F, 0.05F, 1.0F).color(0xFFE8C0).alpha(1.0F, 0.0F).spawn();
                sparks(at, n, 70, 5, 0xFFA040, 0.35F, 0.035F, 8, 0.04);
                if (rnd().nextFloat() < 0.5F) smoke(at, 1, 0.1F, 16, 0x8C847C, n.scale(0.02), 0.05F);
            }
            case Fx.ROTOR, Fx.HALCON, Fx.BASTION -> {
                flash(at, main, hot, 0.25F, 2);
                sparks(at, n, 70, 4, spark, 0.3F, 0.035F, 6, 0.03);
            }
            case Fx.SIERRA -> {
                flash(at, main, hot, 0.3F, 3);
                sparks(at, n, 80, 10, 0xFFE0A0, 0.45F, 0.035F, 8, 0.05);
                sparks(at, n, 60, 5, spark, 0.3F, 0.04F, 6, 0.0);
            }
            case Fx.CIZALLA -> {
                flash(at, main, hot, 0.5F, 4);
                p(at, FxAtlas.CRESCENT, 5).size(0.5F, 0.8F, 0.5F).color(hot, main).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
                sparks(at, n, 80, 8, spark, 0.4F, 0.04F, 7, 0.0);
            }
            default -> {
                flash(at, main, hot, 0.35F * Math.max(0.5F, strength), 3);
                sparks(at, n, 70, 6, spark, 0.35F, 0.04F, 7, 0.02);
            }
        }
    }

    // ================================================================ explosiones

    private static void explosion(int style, Vec3 pos, float radius) {
        int main = Palette.main(style);
        if (style == Fx.VORTICE) {
            collapse(pos, radius);
            return;
        }
        float k = radius / 3.0F;
        int fireballs = style == Fx.BOMBLET ? 3 : style == Fx.TRITURADORA ? 9 : 6;
        // destello que ilumina todo
        p(pos, FxAtlas.GLOW, 6).size(radius * 1.4F, radius * 2.2F, 0.5F).color(0xFFE6B0, 0xFF7020).alpha(1.0F, 0.0F).spawn();
        p(pos, FxAtlas.LENS, 5).size(radius * 0.6F, radius * 0.2F, 1.0F).aspect(6.0F).color(0xFFD090).alpha(0.8F, 0.0F).spawn();
        // bolas de fuego
        for (int i = 0; i < fireballs; i++) {
            Vec3 at = pos.add(randomDir().scale(radius * 0.35 * rnd().nextFloat()));
            p(at, FxAtlas.FIRE[0], 12 + rnd().nextInt(8)).frames(FxAtlas.FIRE, false).vel(randomDir().scale(0.04 * k).add(0, 0.03, 0)).drag(0.88)
                    .size(radius * rf(0.25F, 0.4F), radius * rf(0.55F, 0.8F), 0.4F).color(0xFFF4D0, style == Fx.TRITURADORA ? 0xFF5A10 : 0xFF3A10)
                    .roll(rf(0, 6.28F), rf(-0.05F, 0.05F)).alpha(1.0F, 0.0F).alphaPow(1.6F).spawn();
        }
        // onda de choque y anillo en el suelo
        ring(pos, UP, FxAtlas.SHOCK, style == Fx.TRITURADORA ? 0xF0FFB0 : 0xFFE0B0, radius * 0.2F, radius * 1.6F, 9, 0.9F);
        ring(pos.add(0, 0.05, 0), UP, FxAtlas.RING, main, radius * 0.3F, radius * 2.0F, 12, 0.6F);
        p(pos, FxAtlas.SHOCK, 7).size(radius * 0.2F, radius * 1.5F, 0.5F).color(0xFFF0D0).alpha(0.6F, 0.0F).spawn();
        // chispas, escombros, ascuas y humo
        sparks(pos, UP, 180.0, style == Fx.BOMBLET ? 8 : 22, 0xFFB050, 0.6F * k + 0.3F, 0.06F, 12, 0.03);
        int debris = style == Fx.BOMBLET ? 3 : style == Fx.TRITURADORA ? 14 : 8;
        for (int i = 0; i < debris; i++) {
            p(pos, FxAtlas.DEBRIS, 24 + rnd().nextInt(16)).soft().vel(cone(UP, 75).scale(rf(0.25F, 0.6F) * k)).gravity(0.045).drag(0.97)
                    .size(rf(0.05F, 0.12F)).color(0x3A3430).roll(rf(0, 6.28F), rf(-0.4F, 0.4F)).alpha(1.0F, 0.6F).spawn();
        }
        embers(pos, style == Fx.BOMBLET ? 6 : 18, 0xFF6020, 0.25F * k, 30);
        smoke(pos.add(0, radius * 0.2, 0), style == Fx.BOMBLET ? 3 : 9, radius * 0.35F, 55, 0x5C5650, new Vec3(0, 0.035, 0), radius * 0.5F);
    }

    /** Colapso del VÓRTICE: implosión violeta y estallido. */
    private static void collapse(Vec3 pos, float radius) {
        int main = Palette.main(Fx.VORTICE);
        p(pos, FxAtlas.GLOW, 8).size(radius * 1.6F, radius * 0.4F, 0.6F).color(0xF4E8FF, main).alpha(1.0F, 0.0F).spawn();
        p(pos, FxAtlas.CORE, 6).size(radius * 0.6F, radius * 0.1F, 1.0F).color(0xFFFFFF).alpha(1.0F, 0.0F).spawn();
        p(pos, FxAtlas.LENS, 6).size(radius * 0.8F, radius * 0.3F, 1.0F).aspect(7.0F).color(main).alpha(0.9F, 0.0F).spawn();
        ring(pos, UP, FxAtlas.SHOCK, main, radius * 1.8F, radius * 0.2F, 7, 0.9F);
        ring(pos, UP, FxAtlas.RING, 0xF0D8FF, radius * 0.2F, radius * 2.2F, 12, 0.8F);
        ring(pos, randomDir(), FxAtlas.ACCRETION, main, radius * 0.4F, radius * 1.4F, 10, 0.8F);
        p(pos, FxAtlas.VORTEX, 12).size(radius * 1.2F, radius * 0.1F, 0.7F).color(main).roll(0.0F, 0.5F).alpha(1.0F, 0.0F).spawn();
        for (int i = 0; i < 24; i++) {
            Vec3 d = randomDir();
            p(pos.add(d.scale(radius * 1.2)), FxAtlas.SPARK, 6).mode(Mode.VELOCITY).vel(d.scale(-radius * 0.2)).size(0.06F, 0.02F, 1.0F)
                    .aspect(3.0F).stretch(1.4F).color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
        }
        sparks(pos, UP, 180.0, 16, 0xD8B8FF, 0.6F, 0.05F, 12, 0.0);
    }

    private static void vortexOpen(Vec3 pos, float radius) {
        int main = Palette.main(Fx.VORTICE);
        p(pos, FxAtlas.GLOW, 8).size(1.0F, 2.5F, 0.5F).color(0xF4E8FF, main).alpha(1.0F, 0.0F).spawn();
        ring(pos, UP, FxAtlas.SHOCK, main, 0.4F, radius * 1.1F, 10, 0.8F);
        ring(pos, UP, FxAtlas.RING, 0xF0D8FF, radius, 0.3F, 12, 0.7F);
    }

    // ================================================================ haces

    /** Rayo de riel de la AGUJA: núcleo blanco, resplandor celeste y una hélice que se desvanece. */
    private static void rail(Vec3 from, Vec3 to, float charge, @Nullable Entity shooter) {
        ClientLevel level = level();
        Vec3 start = shooter != null ? Muzzle.world(shooter, 1.0F) : from;
        float k = 0.6F + 0.4F * charge;
        int main = Palette.main(Fx.AGUJA);
        new FxBeam(level, start, to, 14).sprite(FxAtlas.BEAM_THIN).width(0.07F * k, 0.0F).color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
        new FxBeam(level, start, to, 18).sprite(FxAtlas.BEAM).width(0.28F * k, 0.06F).color(main, 0x1E7CFF).alpha(0.85F, 0.0F).alphaPow(0.7F).spawn();
        new FxBeam(level, start, to, 24).sprite(FxAtlas.BEAM_THIN).helix(0.16F + 0.08F * charge, 0.55F, 0.25F, rf(0, 6.28F))
                .width(0.035F, 0.0F).color(0xB8F8FF, 0x2A70FF).alpha(0.9F, 0.0F).spawn();
        new FxBeam(level, start, to, 10).sprite(FxAtlas.BEAM_NOISE).tile(2.0F, 0.6F).width(0.12F * k, 0.02F).color(0xDFFFFF, main)
                .alpha(0.8F, 0.0F).spawn();
        // destellos a lo largo del recorrido
        Vec3 d = to.subtract(start);
        double len = d.length();
        int n = Mth.clamp((int) (len / 1.6), 2, 70);
        for (int i = 0; i < n; i++) {
            Vec3 at = start.add(d.scale(rnd().nextDouble()));
            p(at, FxAtlas.GLINT, 8 + rnd().nextInt(14)).size(rf(0.05F, 0.12F), 0.0F, 1.0F).color(0xFFFFFF, main)
                    .vel(randomDir().scale(0.015)).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
        }
    }

    /** Rayo eléctrico de la CHISPA: resplandor azul y núcleo blanco con la misma forma en zigzag. */
    private static void arc(int style, Vec3 from, Vec3 to, float thickness, @Nullable Entity shooter) {
        ClientLevel level = level();
        if (shooter != null && Muzzle.firstPerson(shooter)) Muzzle.fired(style, 0.04F);
        long seed = rnd().nextLong();
        double len = from.distanceTo(to);
        float jag = (float) Mth.clamp(0.12 + len * 0.035, 0.15, 0.9);
        new FxBeam(level, from, to, 3).anchor(shooter).sprite(FxAtlas.BEAM).jagged(jag, 1, seed).taper(0.1F)
                .width(0.22F * thickness, 0.12F * thickness).color(0x7FA8FF, 0x4060FF).alpha(0.8F, 0.0F).spawn();
        new FxBeam(level, from, to, 3).anchor(shooter).sprite(FxAtlas.BEAM_THIN).jagged(jag, 1, seed).taper(0.1F)
                .width(0.06F * thickness, 0.03F * thickness).color(0xFFFFFF, 0xFFF4C0).alpha(1.0F, 0.2F).spawn();
        // ramas cortas
        if (rnd().nextFloat() < 0.6F) {
            Vec3 a = from.add(to.subtract(from).scale(rf(0.2F, 0.8F)));
            Vec3 b = a.add(randomDir().scale(rf(0.5F, 1.6F)));
            new FxBeam(level, a, b, 2).sprite(FxAtlas.BEAM_THIN).jagged(0.2F, 1, rnd().nextLong()).taper(0.3F).width(0.03F, 0.01F)
                    .color(0xE8F0FF, 0x6080FF).alpha(0.9F, 0.0F).spawn();
        }
        p(to, FxAtlas.GLOW, 3).size(0.35F * thickness, 0.5F * thickness, 1.0F).color(0x9CC8FF).alpha(0.7F, 0.0F).spawn();
        if (shooter == null) p(from, FxAtlas.GLOW, 3).size(0.3F * thickness).color(0x9CC8FF).alpha(0.6F, 0.0F).spawn();
    }

    /** Remache: trazo rapidísimo desde la boca del cañón hasta el punto de impacto. */
    private static void tracer(int style, Vec3 from, Vec3 to, @Nullable Entity shooter) {
        Vec3 start = shooter != null ? Muzzle.world(shooter, 1.0F) : from;
        Vec3 d = to.subtract(start);
        double len = d.length();
        if (len < 0.3) return;
        double speed = 9.0;
        int life = Math.max(1, (int) Math.ceil(len / speed));
        p(start, FxAtlas.SPARK, life + 1).mode(Mode.VELOCITY).vel(d.scale(speed / len)).size(0.035F).aspect(4.0F).stretch(0.8F)
                .color(0xFFF0D0, Palette.main(style)).alpha(1.0F, 0.6F).spawn();
    }

    /** Chorro del SOPLETE: llamas de plasma que nacen azules en la boquilla y se vuelven fuego. */
    private static void flame(Vec3 from, Vec3 to, float range, @Nullable Entity shooter) {
        if (shooter != null && Muzzle.firstPerson(shooter)) Muzzle.fired(Fx.SOPLETE, 0.03F);
        Vec3 start = shooter != null ? Muzzle.world(shooter, 1.0F) : from;
        Vec3 d = to.subtract(start);
        double len = Math.max(1.0, d.length());
        Vec3 dir = d.scale(1.0 / len);
        p(start, FxAtlas.GLOW, 3).size(0.25F, 0.3F, 1.0F).color(0x7FB8FF).alpha(0.9F, 0.0F).spawn();
        p(start, FxAtlas.FLASH_SIDE, 2).mode(Mode.AXIS).axis(dir).size(0.1F).aspect(2.0F).color(0xDDEEFF, 0x5A8CFF).alpha(1.0F, 0.0F).spawn();
        for (int i = 0; i < 7; i++) {
            Vec3 v = cone(dir, 6.0).scale(rf(0.75F, 1.0F) * 1.25);
            int life = (int) Mth.clamp(len / 1.25 * rf(0.85F, 1.05F), 4, 20);
            p(start.add(randomDir().scale(0.05)), FxAtlas.FLAME[0], life).frames(FxAtlas.FLAME, true).vel(v).drag(0.97)
                    .size(0.08F, rf(0.7F, 1.1F), 0.7F).color(0xA8D4FF, 0xFF5A14).roll(rf(0, 6.28F), rf(-0.15F, 0.15F))
                    .alpha(1.0F, 0.0F).alphaPow(1.4F).spawn();
        }
        if (rnd().nextFloat() < 0.7F) embers(start.add(dir.scale(len * rf(0.3F, 0.9F))), 1, 0xFF7020, 0.08F, 16);
        if (rnd().nextFloat() < 0.5F) smoke(start.add(dir.scale(len)), 1, 0.4F, 30, 0x4A4440, new Vec3(0, 0.04, 0), 0.4F);
    }

    /** Láser del TRUENO: celeste que se vuelve rojo al calentarse. */
    private static void laser(Vec3 from, Vec3 to, float heat, @Nullable Entity shooter) {
        ClientLevel level = level();
        if (shooter != null && Muzzle.firstPerson(shooter)) Muzzle.fired(Fx.TRUENO, 0.02F + heat * 0.04F);
        int color = Palette.mix(0x5FE6FF, 0xFF2A1A, heat);
        int core = Palette.mix(0xE8FDFF, 0xFFE0D0, heat);
        float w = 1.0F + heat;
        new FxBeam(level, from, to, 3).anchor(shooter).sprite(FxAtlas.BEAM_THIN).width(0.045F * w, 0.04F * w).color(core).alpha(1.0F, 0.6F).spawn();
        new FxBeam(level, from, to, 3).anchor(shooter).sprite(FxAtlas.BEAM).width(0.2F * w, 0.18F * w).color(color).alpha(0.75F, 0.4F).spawn();
        new FxBeam(level, from, to, 3).anchor(shooter).sprite(FxAtlas.BEAM_NOISE).tile(1.6F, 0.5F).width(0.12F * w, 0.1F * w).color(color)
                .alpha(0.7F, 0.3F).spawn();
        Vec3 start = shooter != null ? Muzzle.world(shooter, 1.0F) : from;
        p(start, FxAtlas.GLOW, 3).size(0.2F * w).color(color).alpha(0.8F, 0.0F).spawn();
        // punto de impacto incandescente
        Vec3 back = start.subtract(to);
        Vec3 n = back.lengthSqr() < 1.0E-6 ? UP : back.normalize();
        p(to, FxAtlas.GLOW, 3).size(0.4F * w, 0.5F * w, 1.0F).color(color).alpha(0.9F, 0.0F).spawn();
        p(to, FxAtlas.CORE, 2).size(0.12F * w).color(core).alpha(1.0F, 0.0F).spawn();
        if (rnd().nextFloat() < 0.6F) sparks(to, n, 70, 2 + (int) (heat * 4), Palette.mix(0xBFF8FF, 0xFFB060, heat), 0.3F, 0.03F, 6, 0.03);
        if (heat > 0.6F && rnd().nextFloat() < 0.4F) smoke(to, 1, 0.15F, 22, 0x605A56, new Vec3(0, 0.03, 0), 0.05F);
    }

    /** Cuerda azul de la SERPENTINA: une el látigo con el enemigo mientras lo arrastra. */
    private static void rope(Vec3 from, Vec3 to, float ticks, @Nullable Entity shooter, @Nullable Entity target) {
        ClientLevel level = level();
        int life = Math.max(4, (int) ticks);
        boolean miss = target == null;
        new FxBeam(level, from, to, life).anchor(shooter).target(target).sprite(FxAtlas.ROPE).jagged(0.25F, 1, 0L)
                .shape(FxBeam.Shape.WAVE).tile(0.9F, 0.0F).width(0.07F, 0.05F).color(0x6C8CFF, 0x3050FF).alpha(1.0F, miss ? 0.0F : 0.7F)
                .grow(miss ? 3.0F : 2.0F).spawn();
        new FxBeam(level, from, to, life).anchor(shooter).target(target).sprite(FxAtlas.BEAM).width(0.16F, 0.1F).color(0x3A5CFF)
                .alpha(0.55F, miss ? 0.0F : 0.3F).grow(miss ? 3.0F : 2.0F).spawn();
        if (target != null) {
            p(target.position().add(0, target.getBbHeight() * 0.55, 0), FxAtlas.RING, 8).follow(target, new Vec3(0, target.getBbHeight() * 0.55, 0))
                    .size(0.6F, 0.9F, 1.0F).color(0x7090FF).alpha(0.8F, 0.0F).spawn();
            sparks(target.getBoundingBox().getCenter(), UP, 180.0, 8, 0xD8E4FF, 0.3F, 0.04F, 6, 0.0);
        }
    }

    private static void drill(Vec3 pos, Vec3 dir, int stage) {
        int color = stage == 2 ? 0xFF5020 : stage == 1 ? 0xFFA020 : 0xFFE060;
        Vec3 n = dir.lengthSqr() < 1.0E-6 ? UP : dir.normalize().reverse();
        p(pos, FxAtlas.DRILL, 4).mode(Mode.FIXED).axis(n).size(0.25F + stage * 0.08F).color(color).roll(rf(0, 6.28F), 0.8F).alpha(0.9F, 0.0F).spawn();
        p(pos, FxAtlas.GLOW, 3).size(0.3F + stage * 0.15F).color(color).alpha(0.8F, 0.0F).spawn();
        sparks(pos, n, 75, 4 + stage * 5, color, 0.35F + stage * 0.12F, 0.04F, 7, 0.04);
        if (stage == 2) {
            embers(pos, 3, 0xFF4010, 0.12F, 14);
            if (rnd().nextFloat() < 0.4F) smoke(pos, 1, 0.12F, 18, 0x5A5450, new Vec3(0, 0.02, 0), 0.05F);
        }
    }

    private static void lock(@Nullable Entity target, int count) {
        if (target == null) return;
        Vec3 off = new Vec3(0, target.getBbHeight() * 0.55, 0);
        float size = Math.max(0.45F, target.getBbWidth() * 0.7F);
        p(target.position().add(off), FxAtlas.LOCK, 40).follow(target, off).size(size * 1.6F, size, 0.3F).color(0xFF4A3A)
                .alpha(1.0F, 0.6F).spawn();
        p(target.position().add(off), FxAtlas.RING, 8).follow(target, off).size(size * 2.0F, size * 0.6F, 0.5F).color(0xFF6A4A)
                .alpha(0.9F, 0.0F).spawn();
    }

    private static void melee(int style, Vec3 pos, Vec3 dir, float power) {
        Vec3 d = dir.lengthSqr() < 1.0E-6 ? UP : dir.normalize();
        int main = Palette.main(style);
        int hot = Palette.hot(style);
        switch (style) {
            case Fx.MARTINETE -> {
                flash(pos, main, hot, 0.6F, 4);
                ring(pos, d, FxAtlas.SHOCK, 0xFFD8A0, 0.2F, 1.4F, 7, 0.8F);
                sparks(pos, d.reverse(), 80, 10, 0xFFB050, 0.5F, 0.05F, 9, 0.04);
                smoke(pos, 3, 0.2F, 24, 0x9A928A, d.scale(0.03), 0.3F);
            }
            case Fx.CIZALLA -> {
                p(pos, FxAtlas.CRESCENT, 6).size(0.7F, 1.1F, 0.5F).color(hot, main).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
                flash(pos, main, hot, 0.45F, 3);
                sparks(pos, d, 70, 8, Palette.spark(style), 0.4F, 0.04F, 7, 0.0);
            }
            case Fx.SERPENTINA -> {
                float k = power > 1.5F ? 1.8F : 1.0F;
                flash(pos, main, hot, 0.45F * k, 4);
                for (int i = 0; i < (int) (3 * k); i++) {
                    Vec3 end = pos.add(randomDir().scale(rf(0.6F, 1.4F) * k));
                    new FxBeam(level(), pos, end, 3).sprite(FxAtlas.BEAM_THIN).jagged(0.15F, 1, rnd().nextLong()).taper(0.3F).width(0.04F, 0.02F)
                            .color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
                }
                if (k > 1.0F) ring(pos, d, FxAtlas.RING_NOISE, main, 0.2F, 1.6F, 8, 0.9F);
            }
            default -> {
                flash(pos, main, hot, 0.4F, 3);
                sparks(pos, d, 70, 6, Palette.spark(style), 0.35F, 0.04F, 7, 0.02);
            }
        }
    }

    private static void shield(Vec3 pos, Vec3 dir) {
        int main = Palette.main(Fx.BASTION);
        Vec3 d = dir.lengthSqr() < 1.0E-6 ? UP : dir.normalize();
        p(pos, FxAtlas.HEX, 9).mode(Mode.FIXED).axis(d).size(0.5F, 0.9F, 0.5F).color(0xFFF0D8, main).alpha(1.0F, 0.0F).spawn();
        ring(pos, d, FxAtlas.RING, main, 0.2F, 1.0F, 7, 0.8F);
        sparks(pos, d, 70, 8, 0xFFD8A0, 0.35F, 0.04F, 7, 0.03);
    }

    private static void drone(Vec3 pos, Vec3 dir) {
        int main = Palette.main(Fx.HALCON);
        flash(pos, main, 0xFFF0D8, 0.5F, 4);
        ring(pos, UP, FxAtlas.RING, main, 0.2F, 1.2F, 8, 0.8F);
        sparks(pos, UP, 180.0, 8, 0xFFD090, 0.3F, 0.04F, 7, 0.02);
    }

    // ================================================================ estelas de los proyectiles (cada tick en el cliente)

    public static void projectileTick(PXProjectile e) {
        if (level() == null) return;
        RandomSource r = rnd();
        Vec3 pos = e.position();
        Vec3 back = e.heading().reverse();
        if (e instanceof PlasmaBolt bolt) {
            int c = bolt.isHot() ? 0xFF7A20 : 0x9CFF3A;
            p(pos.add(back.scale(0.3)), FxAtlas.EMBER, 6 + r.nextInt(4)).vel(randomDir().scale(0.01)).size(0.05F, 0.0F, 1.0F).color(0xFFFFFF, c)
                    .alpha(0.9F, 0.0F).spawn();
            if (bolt.isHot() && r.nextFloat() < 0.5F) embers(pos, 1, 0xFF5010, 0.03F, 10);
        } else if (e instanceof EnergyBolt bolt) {
            switch (bolt.style()) {
                case EnergyBolt.FROST -> {
                    if (r.nextFloat() < 0.6F) {
                        p(pos.add(back.scale(0.4)), FxAtlas.SNOW, 10 + r.nextInt(6)).vel(randomDir().scale(0.01)).size(0.06F, 0.0F, 1.0F)
                                .color(0xFFFFFF, 0x9FEFFF).roll(r.nextFloat() * 6.28F, 0.2F).alpha(1.0F, 0.0F).spawn();
                    }
                    if (r.nextFloat() < 0.3F) smoke(pos, 1, 0.06F, 12, 0xE8FAFF, Vec3.ZERO, 0.02F);
                }
                case EnergyBolt.NEEDLE -> {
                    if (r.nextFloat() < 0.4F) {
                        p(pos, FxAtlas.GLINT, 5).size(0.07F, 0.0F, 1.0F).color(0xFFB0E0).roll(r.nextFloat() * 6.28F, 0.0F).alpha(1.0F, 0.0F).spawn();
                    }
                }
                case EnergyBolt.DRONE, EnergyBolt.BULLET -> {
                    if (r.nextFloat() < 0.5F) {
                        p(pos.add(back.scale(0.3)), FxAtlas.EMBER, 5).size(0.04F, 0.0F, 1.0F).color(0xFFFFFF, Palette.main(bolt.style() == EnergyBolt.DRONE ? Fx.HALCON : Fx.BASTION))
                                .alpha(0.9F, 0.0F).spawn();
                    }
                }
                default -> {}
            }
        } else if (e instanceof MicroRocket) {
            Vec3 tail = pos.add(back.scale(0.35));
            smoke(tail, 1, 0.12F, 30, 0xB4B0AA, back.scale(0.02).add(0, 0.008, 0), 0.05F);
            p(tail, FxAtlas.GLOW, 3).size(0.3F, 0.15F, 1.0F).color(0xFF8A30).alpha(0.8F, 0.0F).spawn();
            if (r.nextFloat() < 0.5F) embers(tail, 1, 0xFF7020, 0.04F, 8);
        } else if (e instanceof Grenade g) {
            boolean small = g.kind() == Grenade.BOMBLET;
            p(pos, FxAtlas.EMBER, 6).vel(randomDir().scale(0.02)).size(small ? 0.03F : 0.05F, 0.0F, 1.0F).color(0xFFFFFF, 0xFFA040).alpha(1.0F, 0.0F).spawn();
            if (!small && r.nextFloat() < 0.35F) smoke(pos, 1, 0.08F, 18, 0x9A9890, new Vec3(0, 0.01, 0), 0.02F);
        } else if (e instanceof SawDisc) {
            if (r.nextFloat() < 0.3F) sparks(pos, UP, 180.0, 1, 0x9FFFD6, 0.15F, 0.03F, 5, 0.03);
        } else if (e instanceof Singularity s) {
            if (s.isOpen()) {
                // la materia cae en espiral hacia el centro
                for (int i = 0; i < 3; i++) {
                    double ang = r.nextDouble() * Math.PI * 2.0;
                    double rad = Singularity.PULL_RADIUS * (0.6 + 0.4 * r.nextDouble());
                    Vec3 at = pos.add(Math.cos(ang) * rad, (r.nextDouble() - 0.5) * 2.0, Math.sin(ang) * rad);
                    Vec3 to = pos.subtract(at);
                    Vec3 swirl = to.cross(UP).normalize().scale(0.25);
                    p(at, FxAtlas.SPARK, 14).mode(Mode.VELOCITY).vel(to.scale(0.07).add(swirl)).drag(0.98).size(0.05F, 0.01F, 1.0F).aspect(3.0F)
                            .stretch(2.0F).color(0xF0E0FF, 0xA45CFF).alpha(0.0F, 1.0F).fadeIn(0.3F).spawn();
                }
            } else if (r.nextFloat() < 0.7F) {
                p(pos.add(randomDir().scale(0.3)), FxAtlas.GLINT, 8).vel(back.scale(0.05)).size(0.08F, 0.0F, 1.0F).color(0xE8D8FF, 0xA45CFF)
                        .roll(r.nextFloat() * 6.28F, 0.1F).alpha(1.0F, 0.0F).spawn();
            }
        } else if (e instanceof SlashWave) {
            if (r.nextFloat() < 0.6F) {
                p(pos.add(randomDir().scale(0.6)), FxAtlas.GLINT, 8).vel(back.scale(0.04)).size(0.1F, 0.0F, 1.0F).color(0xFFE0F0, 0xFF2E7E)
                        .roll(r.nextFloat() * 6.28F, 0.0F).alpha(1.0F, 0.0F).spawn();
            }
        }
    }

    public static void droneTick(Drone drone) {
        if (level() == null || drone.tickCount % 2 != 0) return;
        Vec3 pos = drone.position();
        for (int i = 0; i < 2; i++) {
            Vec3 at = pos.add((rnd().nextFloat() - 0.5) * 0.5, -0.1, (rnd().nextFloat() - 0.5) * 0.5);
            p(at, FxAtlas.EMBER, 6).vel(new Vec3(0, -0.06, 0)).size(0.05F, 0.0F, 1.0F).color(0xFFFFFF, 0xFFA235).alpha(0.8F, 0.0F).spawn();
        }
    }
}
