package com.proyectox.client.fx;

import com.proyectox.client.Reticle;
import com.proyectox.client.fx.FxParticle.Mode;
import com.proyectox.entity.Drone;
import com.proyectox.entity.EnergyBolt;
import com.proyectox.entity.Field;
import com.proyectox.entity.Grenade;
import com.proyectox.entity.MicroRocket;
import com.proyectox.entity.Orb;
import com.proyectox.entity.Piercer;
import com.proyectox.entity.PXProjectile;
import com.proyectox.entity.PlasmaBolt;
import com.proyectox.entity.SawDisc;
import com.proyectox.entity.Singularity;
import com.proyectox.entity.SlashWave;
import com.proyectox.entity.Sticky;
import com.proyectox.fx.Fx;
import com.proyectox.item.GunItem;
import com.proyectox.network.FxPayload;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Composición de los efectos visuales en el cliente: cada aviso del servidor ({@link FxPayload})
 * se convierte en un conjunto de partículas HD, haces y anillos con el estilo de su arma.
 */
public final class FxEffects {
    private FxEffects() {}

    private static final Vec3 UP = new Vec3(0, 1, 0);

    @Nullable
    private static ClientLevel level() {
        return Minecraft.getInstance().level;
    }

    private static RandomSource rnd() {
        ClientLevel l = level();
        return l != null ? l.random : RandomSource.create();
    }

    /** Partícula nueva (sin añadir todavía). */
    private static FxParticle p(Vec3 pos, FxAtlas.Sprite s, int life) {
        return new FxParticle(level(), pos, s, life);
    }

    private static float rf(float a, float b) {
        return a + rnd().nextFloat() * (b - a);
    }

    private static Vec3 randomDir() {
        RandomSource r = rnd();
        double z = r.nextDouble() * 2.0 - 1.0;
        double t = r.nextDouble() * Math.PI * 2.0;
        double s = Math.sqrt(1.0 - z * z);
        return new Vec3(s * Math.cos(t), z, s * Math.sin(t));
    }

    /** Dirección dentro de un cono de {@code deg} grados alrededor de {@code dir}. */
    private static Vec3 cone(Vec3 dir, double deg) {
        Vec3 n = dir.lengthSqr() < 1.0E-8 ? UP : dir.normalize();
        Vec3 a = Math.abs(n.y) < 0.99 ? UP : new Vec3(1, 0, 0);
        Vec3 u = n.cross(a).normalize();
        Vec3 v = n.cross(u).normalize();
        RandomSource r = rnd();
        double ang = r.nextDouble() * Math.PI * 2.0;
        double mag = Math.tan(Math.toRadians(deg)) * Math.sqrt(r.nextDouble());
        return n.add(u.scale(Math.cos(ang) * mag)).add(v.scale(Math.sin(ang) * mag)).normalize();
    }

    // ================================================================ entrada desde la red

    public static void play(FxPayload f) {
        ClientLevel level = level();
        if (level == null) return;
        Vec3 a = f.from();
        Vec3 b = f.to();
        switch (f.kind()) {
            case Fx.MUZZLE -> muzzle(f.style(), a, b, level.getEntity(f.entity()));
            case Fx.BEAM -> rail(a, b, f.value(), level.getEntity(f.entity()));
            case Fx.IMPACT -> impact(f.style(), a, b, f.value());
            case Fx.EXPLOSION -> explosion(f.style(), a, f.value());
            case Fx.ARC -> arc(f.style(), a, b, f.value(), f.entity() >= 0 ? level.getEntity(f.entity()) : null);
            case Fx.TRACER -> tracer(f.style(), a, b, level.getEntity(f.entity()));
            case Fx.FLAME -> flame(a, b, f.value(), level.getEntity(f.entity()));
            case Fx.LASER -> laser(a, b, f.value(), level.getEntity(f.entity()));
            case Fx.ROPE -> rope(a, b, f.value(), level.getEntity(f.entity()), f.other() >= 0 ? level.getEntity(f.other()) : null);
            case Fx.DRILL -> drill(a, b, (int) f.value());
            case Fx.LOCK -> lock(level.getEntity(f.entity()), (int) f.value());
            case Fx.MELEE -> melee(f.style(), a, b, f.value());
            case Fx.SHIELD -> shield(a, b);
            case Fx.HITMARK -> Reticle.hit(f.style() == 1);
            case Fx.DRONE -> drone(a, b);
            case Fx.VORTEX -> vortexOpen(a, f.value());
            case Fx.PRISM -> prism(a, b, f.value(), f.entity() >= 0 ? level.getEntity(f.entity()) : null);
            case Fx.LIGHTNING -> lightning(a, b, f.value(), f.entity() >= 0 ? level.getEntity(f.entity()) : null);
            case Fx.SWEEP -> sweep(a, b, f.value(), level.getEntity(f.entity()));
            case Fx.THRUST -> thrust(a, b, f.value(), level.getEntity(f.entity()));
            case Fx.DISINTEGRATE -> disintegrate(a, f.value(), level.getEntity(f.entity()));
            case Fx.STORM -> stormForm(a, f.value());
            default -> {}
        }
    }

    // ================================================================ piezas básicas

    /** Destello: halo de color y núcleo blanco. */
    private static void flash(Vec3 pos, int color, int hot, float size, int life) {
        p(pos, FxAtlas.GLOW, life + 1).size(size, size * 1.3F, 1.0F).color(color).alpha(0.9F, 0.0F).spawn();
        p(pos, FxAtlas.CORE, life).size(size * 0.4F, size * 0.2F, 1.0F).color(hot).alpha(1.0F, 0.0F).spawn();
    }

    private static void sparks(Vec3 pos, Vec3 dir, double coneDeg, int n, int color, float speed, float size, int life, double gravity) {
        for (int i = 0; i < n; i++) {
            Vec3 d = coneDeg >= 180.0 ? randomDir() : cone(dir, coneDeg);
            float s = speed * rf(0.4F, 1.0F);
            p(pos, FxAtlas.SPARK, (int) (life * rf(0.6F, 1.2F))).mode(Mode.VELOCITY).vel(d.scale(s)).drag(0.86).gravity(gravity)
                    .size(size, size * 0.4F, 1.0F).aspect(3.0F).stretch(1.6F).color(0xFFFFFF, color).alpha(1.0F, 0.0F).spawn();
        }
    }

    private static void smoke(Vec3 pos, int n, float size, int life, int shade, Vec3 drift, float spread) {
        for (int i = 0; i < n; i++) {
            Vec3 at = pos.add(randomDir().scale(spread * rnd().nextFloat()));
            Vec3 v = drift.add(randomDir().scale(0.02));
            p(at, FxAtlas.SMOKE[rnd().nextInt(FxAtlas.SMOKE.length)], (int) (life * rf(0.7F, 1.3F))).soft().vel(v).drag(0.92)
                    .size(size * rf(0.6F, 1.0F), size * rf(1.8F, 2.6F), 0.6F).color(shade, Palette.mix(shade, 0x101010, 0.3F))
                    .alpha(rf(0.35F, 0.6F), 0.0F).fadeIn(0.1F).roll(rf(0.0F, 6.28F), rf(-0.03F, 0.03F)).spawn();
        }
    }

    private static void ring(Vec3 pos, Vec3 normal, FxAtlas.Sprite sprite, int color, float from, float to, int life, float alpha) {
        p(pos, sprite, life).mode(Mode.FIXED).axis(normal).size(from, to, 0.5F).color(color).alpha(alpha, 0.0F).roll(rf(0.0F, 6.28F), 0.0F).spawn();
    }

    private static void embers(Vec3 pos, int n, int color, float speed, int life) {
        for (int i = 0; i < n; i++) {
            p(pos, FxAtlas.EMBER, (int) (life * rf(0.5F, 1.4F))).vel(randomDir().scale(speed * rf(0.3F, 1.0F)).add(0, 0.03, 0)).drag(0.9).gravity(-0.002)
                    .size(rf(0.03F, 0.07F), 0.0F, 1.0F).color(0xFFFFFF, color).alpha(1.0F, 0.2F).spawn();
        }
    }

    // ================================================================ fogonazos

    private static void muzzle(int style, Vec3 pos, Vec3 dir, @Nullable Entity shooter) {
        Vec3 d = dir.lengthSqr() < 1.0E-6 ? UP : dir.normalize();
        int main = Palette.main(style);
        int hot = Palette.hot(style);
        boolean local = shooter != null && Muzzle.firstPerson(shooter);
        boolean inHand = false;
        if (local && shooter instanceof Player player && player.getMainHandItem().getItem() instanceof GunItem gun) {
            // en primera persona el fogonazo grande se dibuja pegado al arma (GunHands)
            Muzzle.fired(style, gun.kick());
            inHand = gun.aims() && com.proyectox.client.GunGeometry.of(gun.key()) != null;
            pos = Muzzle.world(shooter, 1.0F);
        }
        float big = switch (style) {
            case Fx.REMACHE, Fx.ECO, Fx.MORTERO, Fx.SOLAR -> 1.4F;
            case Fx.AGUJA, Fx.TRITURADORA, Fx.VORTICE, Fx.COLMENA, Fx.CENTELLA, Fx.ARPON, Fx.CENIZA -> 1.15F;
            case Fx.ROTOR, Fx.COLIBRI, Fx.HALCON, Fx.CAUSTICA, Fx.SAETA -> 0.7F;
            default -> 0.9F;
        };
        if (!inHand) {
            // estrella frontal + lengua lateral + halo
            p(pos, style % 2 == 0 ? FxAtlas.STAR4 : FxAtlas.STAR6, 2).size(0.32F * big, 0.42F * big, 1.0F).color(hot, main)
                    .roll(rf(0.0F, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
            p(pos, FxAtlas.FLASH_SIDE, 2).mode(Mode.AXIS).axis(d).size(0.16F * big).aspect(2.2F).color(hot, main).alpha(1.0F, 0.0F).spawn();
            p(pos, FxAtlas.GLOW, 3).size(0.6F * big, 0.8F * big, 1.0F).color(main).alpha(0.55F, 0.0F).spawn();
        }
        switch (style) {
            case Fx.AGUJA -> {
                ring(pos.add(d.scale(0.2)), d, FxAtlas.RING, main, 0.08F, 0.7F, 7, 0.9F);
                ring(pos.add(d.scale(0.5)), d, FxAtlas.RING_NOISE, hot, 0.05F, 0.45F, 5, 0.7F);
                p(pos, FxAtlas.LENS, 3).size(0.12F, 0.05F, 1.0F).aspect(9.0F).color(main).alpha(0.8F, 0.0F).spawn();
                sparks(pos, d, 35, 6, Palette.spark(style), 0.35F, 0.05F, 6, 0.0);
            }
            case Fx.REMACHE -> {
                sparks(pos, d, 28, 14, 0xFFB050, 0.7F, 0.06F, 7, 0.02);
                smoke(pos.add(d.scale(0.4)), 4, 0.18F, 26, 0x9A9692, d.scale(0.05).add(0, 0.01, 0), 0.2F);
                ring(pos.add(d.scale(0.3)), d, FxAtlas.SHOCK, 0xFFD8A0, 0.1F, 0.9F, 5, 0.5F);
            }
            case Fx.COLMENA -> {
                // escape trasero del lanzacohetes
                smoke(pos.subtract(d.scale(0.9)), 5, 0.25F, 30, 0xB0ACA8, d.scale(-0.08).add(0, 0.015, 0), 0.3F);
                p(pos.subtract(d.scale(0.6)), FxAtlas.FLASH_SIDE, 3).mode(Mode.AXIS).axis(d.reverse()).size(0.22F).aspect(2.4F)
                        .color(0xFFE0A0, 0xFF5A20).alpha(0.9F, 0.0F).spawn();
                sparks(pos, d, 20, 5, 0xFFB060, 0.4F, 0.05F, 6, 0.01);
            }
            case Fx.TRITURADORA -> {
                ring(pos.add(d.scale(0.2)), d, FxAtlas.SHOCK, 0xE8F0A0, 0.1F, 0.8F, 6, 0.6F);
                smoke(pos.add(d.scale(0.3)), 4, 0.2F, 28, 0xA8A89A, d.scale(0.04).add(0, 0.01, 0), 0.2F);
            }
            case Fx.VORTICE -> {
                ring(pos.add(d.scale(0.3)), d, FxAtlas.ACCRETION, main, 0.9F, 0.15F, 8, 0.9F);
                ring(pos.add(d.scale(0.3)), d, FxAtlas.RING, hot, 0.1F, 1.0F, 6, 0.7F);
            }
            case Fx.ECO -> {
                for (int i = 0; i < 3; i++) {
                    ring(pos.add(d.scale(0.4 + i * 0.5)), d, FxAtlas.SOUNDWAVE, main, 0.2F + i * 0.1F, 1.3F + i * 0.4F, 8 + i * 2, 0.8F - i * 0.2F);
                }
            }
            case Fx.ESCARCHA -> {
                p(pos, FxAtlas.SNOW, 8).vel(d.scale(0.12).add(randomDir().scale(0.03))).size(0.08F, 0.02F, 1.0F).color(0xFFFFFF, main)
                        .roll(rf(0, 6.28F), rf(-0.3F, 0.3F)).alpha(1.0F, 0.0F).spawn();
                smoke(pos.add(d.scale(0.2)), 1, 0.12F, 14, 0xD8F4FF, d.scale(0.05), 0.05F);
            }
            case Fx.COLIBRI -> p(pos, FxAtlas.GLINT, 3).size(0.18F, 0.05F, 1.0F).color(main).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
            case Fx.SIERRA -> {
                ring(pos.add(d.scale(0.25)), d, FxAtlas.SAW_BLUR, main, 0.15F, 0.55F, 5, 0.8F);
                sparks(pos, d, 40, 6, Palette.spark(style), 0.4F, 0.05F, 6, 0.02);
            }
            case Fx.BASTION -> ring(pos.add(d.scale(0.2)), d, FxAtlas.HEX, main, 0.12F, 0.4F, 4, 0.7F);
            case Fx.CIZALLA -> p(pos.add(d.scale(0.5)), FxAtlas.CRESCENT, 5).mode(Mode.FIXED).axis(d).size(0.6F, 1.0F, 0.5F).color(hot, main)
                    .alpha(1.0F, 0.0F).spawn();
            case Fx.AVISPON_HOT -> embers(pos, 2, 0xFF7A20, 0.08F, 10);
            case Fx.ROTOR -> {
                if (rnd().nextFloat() < 0.4F) smoke(pos.add(d.scale(0.2)), 1, 0.1F, 16, 0xA0A0A0, d.scale(0.04), 0.05F);
            }
            case Fx.CENTELLA -> {
                ring(pos.add(d.scale(0.25)), d, FxAtlas.RING, main, 0.08F, 0.75F, 6, 0.9F);
                sparks(pos, d, 30, 8, 0xFFD070, 0.5F, 0.05F, 7, 0.02);
                smoke(pos.add(d.scale(0.4)), 2, 0.16F, 22, 0xB0A890, d.scale(0.04).add(0, 0.01, 0), 0.15F);
                p(pos, FxAtlas.LENS, 3).size(0.16F, 0.06F, 1.0F).aspect(8.0F).color(main).alpha(0.8F, 0.0F).spawn();
            }
            case Fx.ARPON -> {
                ring(pos.add(d.scale(0.3)), d, FxAtlas.RING_NOISE, main, 0.1F, 0.7F, 7, 0.8F);
                smoke(pos.add(d.scale(0.2)), 3, 0.15F, 20, 0xDDEEF4, d.scale(0.05).add(0, 0.01, 0), 0.12F);
            }
            case Fx.MORTERO -> {
                ring(pos.add(d.scale(0.3)), d, FxAtlas.SHOCK, 0xFFD8A0, 0.15F, 1.2F, 7, 0.7F);
                smoke(pos.add(d.scale(0.5)), 7, 0.3F, 40, 0x9A948C, d.scale(0.08).add(0, 0.02, 0), 0.35F);
                sparks(pos, d, 25, 10, 0xFFB060, 0.6F, 0.06F, 8, 0.03);
            }
            case Fx.PRISMA -> {
                p(pos, FxAtlas.LENS, 4).size(0.25F, 0.1F, 1.0F).aspect(9.0F).color(0xFFFFFF).alpha(0.9F, 0.0F).spawn();
                for (int i = 0; i < 5; i++) {
                    p(pos.add(randomDir().scale(0.15)), FxAtlas.GLINT, 6 + i).size(0.1F, 0.0F, 1.0F).color(Palette.RAINBOW[i])
                            .roll(rf(0, 6.28F), 0.2F).alpha(1.0F, 0.0F).spawn();
                }
            }
            case Fx.ENJAMBRE -> {
                sparks(pos, d, 35, 8, 0xFFC840, 0.35F, 0.04F, 8, 0.0);
                smoke(pos.add(d.scale(0.3)), 2, 0.12F, 18, 0xC8B080, d.scale(0.04), 0.1F);
            }
            case Fx.CAUSTICA -> {
                for (int i = 0; i < 3; i++) {
                    p(pos, FxAtlas.EMBER, 8 + rnd().nextInt(5)).vel(cone(d, 25).scale(rf(0.1F, 0.25F))).gravity(0.02).size(0.04F, 0.02F, 1.0F)
                            .color(0xE0FF90, main).alpha(1.0F, 0.0F).spawn();
                }
                if (rnd().nextFloat() < 0.4F) smoke(pos.add(d.scale(0.2)), 1, 0.1F, 16, 0xB8E890, d.scale(0.03).add(0, 0.01, 0), 0.05F);
            }
            case Fx.SOLAR -> {
                p(pos, FxAtlas.CORONA, 6).size(0.5F, 1.1F, 0.6F).color(0xFFF0B0, main).roll(rf(0, 6.28F), 0.05F).alpha(1.0F, 0.0F).spawn();
                ring(pos.add(d.scale(0.3)), d, FxAtlas.SHOCK, 0xFFE8A0, 0.2F, 1.4F, 8, 0.7F);
                p(pos, FxAtlas.LENS, 5).size(0.35F, 0.12F, 1.0F).aspect(9.0F).color(0xFFD060).alpha(0.9F, 0.0F).spawn();
                embers(pos, 6, 0xFFB020, 0.15F, 14);
            }
            case Fx.TEMPESTAD -> {
                for (int i = 0; i < 3; i++) {
                    Vec3 end = pos.add(cone(d, 50).scale(rf(0.5F, 1.1F)));
                    new FxBeam(level(), pos, end, 3).sprite(FxAtlas.BEAM_THIN).jagged(0.15F, 1, rnd().nextLong()).taper(0.3F).width(0.035F, 0.015F)
                            .color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
                }
            }
            case Fx.ESQUIRLA -> {
                for (int i = 0; i < 5; i++) {
                    p(pos, FxAtlas.SHARD, 8 + rnd().nextInt(6)).soft().vel(cone(d, 30).scale(rf(0.15F, 0.35F))).gravity(0.02).drag(0.9)
                            .size(0.05F, 0.02F, 1.0F).color(0xF0E0FF, main).roll(rf(0, 6.28F), rf(-0.5F, 0.5F)).alpha(0.95F, 0.0F).spawn();
                }
                ring(pos.add(d.scale(0.2)), d, FxAtlas.RING, main, 0.06F, 0.5F, 5, 0.8F);
            }
            case Fx.CICLON -> {
                ring(pos.add(d.scale(0.3)), d, FxAtlas.VORTEX, main, 0.2F, 1.0F, 8, 0.8F);
                for (int i = 0; i < 6; i++) {
                    p(pos.add(randomDir().scale(0.2)), FxAtlas.SPARK, 8).mode(Mode.VELOCITY).vel(cone(d, 35).scale(rf(0.3F, 0.6F))).drag(0.85)
                            .size(0.04F, 0.01F, 1.0F).aspect(3.0F).stretch(1.4F).color(0xFFFFFF, main).alpha(0.8F, 0.0F).spawn();
                }
            }
            case Fx.MINADOR -> {
                smoke(pos.add(d.scale(0.3)), 3, 0.16F, 26, 0x8C8480, d.scale(0.05).add(0, 0.01, 0), 0.15F);
                ring(pos.add(d.scale(0.2)), d, FxAtlas.RING_NOISE, main, 0.08F, 0.5F, 5, 0.7F);
            }
            case Fx.CENIZA -> {
                ring(pos.add(d.scale(0.3)), d, FxAtlas.RING, main, 0.2F, 1.1F, 9, 0.95F);
                ring(pos.add(d.scale(0.6)), d, FxAtlas.ACCRETION, 0x20C070, 0.3F, 0.9F, 8, 0.7F);
            }
            case Fx.SAETA -> {
                for (int i = 0; i < 4; i++) {
                    p(pos.add(randomDir().scale(0.12)), FxAtlas.GLINT, 6 + i * 2).size(0.08F, 0.0F, 1.0F).color(0xFFF4C8, main)
                            .roll(rf(0, 6.28F), 0.1F).alpha(1.0F, 0.0F).spawn();
                }
                ring(pos.add(d.scale(0.25)), d, FxAtlas.RING, main, 0.05F, 0.45F, 5, 0.8F);
            }
            default -> {}
        }
    }

    // ================================================================ impactos

    private static void impact(int style, Vec3 pos, Vec3 normal, float strength) {
        Vec3 n = normal.lengthSqr() < 1.0E-6 ? UP : normal.normalize();
        int main = Palette.main(style);
        int hot = Palette.hot(style);
        int spark = Palette.spark(style);
        Vec3 at = pos.add(n.scale(0.05));
        switch (style) {
            case Fx.AGUJA -> {
                flash(at, main, hot, 0.7F, 5);
                ring(at, n, FxAtlas.RING, main, 0.1F, 1.0F, 8, 0.9F);
                sparks(at, n, 70, 14, spark, 0.5F, 0.05F, 9, 0.01);
                for (int i = 0; i < 4; i++) {
                    p(at.add(randomDir().scale(0.3)), FxAtlas.GLINT, 10 + rnd().nextInt(8)).size(0.12F, 0.0F, 1.0F).color(hot, main)
                            .roll(rf(0, 6.28F), 0.0F).vel(randomDir().scale(0.02)).alpha(1.0F, 0.0F).spawn();
                }
            }
            case Fx.AVISPON, Fx.AVISPON_HOT -> {
                flash(at, main, hot, 0.35F, 3);
                ring(at, n, FxAtlas.RING_NOISE, main, 0.05F, 0.45F, 6, 0.8F);
                for (int i = 0; i < 6; i++) {
                    p(at, FxAtlas.EMBER, 10 + rnd().nextInt(8)).vel(cone(n, 60).scale(rf(0.08F, 0.22F))).gravity(0.02).drag(0.9)
                            .size(0.05F, 0.0F, 1.0F).color(hot, main).alpha(1.0F, 0.3F).spawn();
                }
                if (style == Fx.AVISPON_HOT) {
                    p(at, FxAtlas.FLAME[0], 10).frames(FxAtlas.FLAME, true).size(0.15F, 0.3F, 1.0F).vel(n.scale(0.02).add(0, 0.03, 0))
                            .color(0xFFE0A0, 0xFF4010).alpha(0.9F, 0.0F).spawn();
                }
            }
            case Fx.CHISPA -> {
                flash(at, main, hot, 0.4F, 3);
                sparks(at, n, 80, 8, 0xEAF2FF, 0.45F, 0.04F, 6, 0.02);
                for (int i = 0; i < 2; i++) {
                    Vec3 end = at.add(cone(n, 70).scale(rf(0.6F, 1.4F)));
                    new FxBeam(level(), at, end, 3).sprite(FxAtlas.BEAM_THIN).jagged(0.15F, 1, rnd().nextLong()).width(0.04F, 0.02F)
                            .color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
                }
            }
            case Fx.ESCARCHA -> {
                flash(at, main, hot, 0.35F, 3);
                for (int i = 0; i < 6; i++) {
                    p(at, FxAtlas.SHARD, 14 + rnd().nextInt(10)).soft().vel(cone(n, 70).scale(rf(0.1F, 0.25F))).gravity(0.03).drag(0.93)
                            .size(rf(0.05F, 0.1F), 0.02F, 1.0F).color(0xFFFFFF, 0xC8F4FF).roll(rf(0, 6.28F), rf(-0.4F, 0.4F)).alpha(0.95F, 0.0F).spawn();
                }
                p(at, FxAtlas.SNOW, 12).size(0.15F, 0.05F, 1.0F).color(0xFFFFFF, main).roll(rf(0, 6.28F), 0.15F).alpha(1.0F, 0.0F).spawn();
                smoke(at, 2, 0.15F, 18, 0xE0F6FF, n.scale(0.02), 0.1F);
            }
            case Fx.COLIBRI -> {
                flash(at, main, hot, 0.25F, 3);
                for (int i = 0; i < 4; i++) {
                    p(at, FxAtlas.SHARD, 10 + rnd().nextInt(6)).soft().vel(cone(n, 70).scale(rf(0.08F, 0.2F))).gravity(0.03)
                            .size(0.04F, 0.01F, 1.0F).color(0xFFD8F0, main).roll(rf(0, 6.28F), rf(-0.5F, 0.5F)).alpha(0.9F, 0.0F).spawn();
                }
            }
            case Fx.REMACHE -> {
                p(at, FxAtlas.CORE, 3).size(0.2F, 0.05F, 1.0F).color(0xFFE8C0).alpha(1.0F, 0.0F).spawn();
                sparks(at, n, 70, 5, 0xFFA040, 0.35F, 0.035F, 8, 0.04);
                if (rnd().nextFloat() < 0.5F) smoke(at, 1, 0.1F, 16, 0x8C847C, n.scale(0.02), 0.05F);
            }
            case Fx.ROTOR, Fx.HALCON, Fx.BASTION -> {
                flash(at, main, hot, 0.25F, 2);
                sparks(at, n, 70, 4, spark, 0.3F, 0.035F, 6, 0.03);
            }
            case Fx.SIERRA -> {
                flash(at, main, hot, 0.3F, 3);
                sparks(at, n, 80, 10, 0xFFE0A0, 0.45F, 0.035F, 8, 0.05);
                sparks(at, n, 60, 5, spark, 0.3F, 0.04F, 6, 0.0);
            }
            case Fx.CIZALLA -> {
                flash(at, main, hot, 0.5F, 4);
                p(at, FxAtlas.CRESCENT, 5).size(0.5F, 0.8F, 0.5F).color(hot, main).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
                sparks(at, n, 80, 8, spark, 0.4F, 0.04F, 7, 0.0);
            }
            case Fx.CENTELLA -> {
                flash(at, main, hot, 0.6F, 4);
                ring(at, n, FxAtlas.RING_NOISE, main, 0.1F, 0.9F, 7, 0.9F);
                sparks(at, n, 70, 12, 0xFFD070, 0.5F, 0.05F, 9, 0.03);
                embers(at, 5, 0xFFA020, 0.12F, 14);
            }
            case Fx.ARPON -> {
                flash(at, main, hot, 0.4F, 3);
                sparks(at, n, 60, 10, spark, 0.45F, 0.045F, 8, 0.04);
            }
            case Fx.ESQUIRLA -> {
                flash(at, main, hot, 0.3F, 3);
                for (int i = 0; i < 5; i++) {
                    p(at, FxAtlas.SHARD, 12 + rnd().nextInt(8)).soft().vel(cone(n, 70).scale(rf(0.08F, 0.22F))).gravity(0.03).drag(0.93)
                            .size(rf(0.04F, 0.08F), 0.02F, 1.0F).color(0xF6E8FF, main).roll(rf(0, 6.28F), rf(-0.4F, 0.4F)).alpha(0.95F, 0.0F).spawn();
                }
            }
            case Fx.CENIZA -> {
                flash(at, main, hot, 0.6F, 5);
                ring(at, n, FxAtlas.RING, main, 0.2F, 1.4F, 9, 0.9F);
                ash(at, 10, 0.5F);
            }
            case Fx.SAETA -> {
                flash(at, main, hot, 0.4F, 3);
                ring(at, n, FxAtlas.RING, main, 0.05F, 0.6F, 6, 0.9F);
                sparks(at, n, 70, 6, 0xFFF0C0, 0.35F, 0.04F, 7, 0.02);
                for (int i = 0; i < 3; i++) {
                    p(at.add(randomDir().scale(0.2)), FxAtlas.GLINT, 8 + rnd().nextInt(6)).size(0.1F, 0.0F, 1.0F).color(0xFFFFFF, main)
                            .roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
                }
            }
            case Fx.MINADOR -> {
                smoke(at, 2, 0.15F, 24, 0x6A6460, n.scale(0.02), 0.1F);
                sparks(at, n, 80, 4, 0xFF6040, 0.2F, 0.03F, 6, 0.03);
            }
            default -> {
                flash(at, main, hot, 0.35F * Math.max(0.5F, strength), 3);
                sparks(at, n, 70, 6, spark, 0.35F, 0.04F, 7, 0.02);
            }
        }
    }

    // ================================================================ explosiones

    private static void explosion(int style, Vec3 pos, float radius) {
        int main = Palette.main(style);
        switch (style) {
            case Fx.VORTICE -> {
                collapse(pos, radius);
                return;
            }
            case Fx.SOLAR -> {
                nova(pos, radius);
                return;
            }
            case Fx.ARPON -> {
                fusion(pos, radius);
                return;
            }
            case Fx.CAUSTICA -> {
                acidSplash(pos, radius);
                return;
            }
            case Fx.ESQUIRLA -> {
                crystalBurst(pos, radius);
                return;
            }
            case Fx.ENJAMBRE -> {
                podBurst(pos, radius);
                return;
            }
            default -> {}
        }
        float k = radius / 3.0F;
        int fireballs = style == Fx.BOMBLET ? 3 : style == Fx.TRITURADORA ? 9 : style == Fx.MORTERO ? 12 : 6;
        // destello que ilumina todo
        p(pos, FxAtlas.GLOW, 6).size(radius * 1.4F, radius * 2.2F, 0.5F).color(0xFFE6B0, 0xFF7020).alpha(1.0F, 0.0F).spawn();
        p(pos, FxAtlas.LENS, 5).size(radius * 0.6F, radius * 0.2F, 1.0F).aspect(6.0F).color(0xFFD090).alpha(0.8F, 0.0F).spawn();
        // bolas de fuego
        for (int i = 0; i < fireballs; i++) {
            Vec3 at = pos.add(randomDir().scale(radius * 0.35 * rnd().nextFloat()));
            p(at, FxAtlas.FIRE[0], 12 + rnd().nextInt(8)).frames(FxAtlas.FIRE, false).vel(randomDir().scale(0.04 * k).add(0, 0.03, 0)).drag(0.88)
                    .size(radius * rf(0.25F, 0.4F), radius * rf(0.55F, 0.8F), 0.4F).color(0xFFF4D0, style == Fx.TRITURADORA ? 0xFF5A10 : 0xFF3A10)
                    .roll(rf(0, 6.28F), rf(-0.05F, 0.05F)).alpha(1.0F, 0.0F).alphaPow(1.6F).spawn();
        }
        // onda de choque y anillo en el suelo
        ring(pos, UP, FxAtlas.SHOCK, style == Fx.TRITURADORA ? 0xF0FFB0 : 0xFFE0B0, radius * 0.2F, radius * 1.6F, 9, 0.9F);
        ring(pos.add(0, 0.05, 0), UP, FxAtlas.RING, main, radius * 0.3F, radius * 2.0F, 12, 0.6F);
        p(pos, FxAtlas.SHOCK, 7).size(radius * 0.2F, radius * 1.5F, 0.5F).color(0xFFF0D0).alpha(0.6F, 0.0F).spawn();
        // chispas, escombros, ascuas y humo
        sparks(pos, UP, 180.0, style == Fx.BOMBLET ? 8 : 22, 0xFFB050, 0.6F * k + 0.3F, 0.06F, 12, 0.03);
        int debris = style == Fx.BOMBLET ? 3 : style == Fx.TRITURADORA ? 14 : style == Fx.MORTERO ? 18 : 8;
        for (int i = 0; i < debris; i++) {
            p(pos, FxAtlas.DEBRIS, 24 + rnd().nextInt(16)).soft().vel(cone(UP, 75).scale(rf(0.25F, 0.6F) * k)).gravity(0.045).drag(0.97)
                    .size(rf(0.05F, 0.12F)).color(0x3A3430).roll(rf(0, 6.28F), rf(-0.4F, 0.4F)).alpha(1.0F, 0.6F).spawn();
        }
        embers(pos, style == Fx.BOMBLET ? 6 : 18, 0xFF6020, 0.25F * k, 30);
        smoke(pos.add(0, radius * 0.2, 0), style == Fx.BOMBLET ? 3 : style == Fx.MORTERO ? 14 : 9, radius * 0.35F, 55, 0x5C5650,
                new Vec3(0, 0.035, 0), radius * 0.5F);
        if (style == Fx.MINADOR) ring(pos.add(0, 0.1, 0), UP, FxAtlas.RING_NOISE, 0xFF5030, radius * 0.4F, radius * 1.6F, 10, 0.8F);
    }

    /** SOLAR: nova dorada con corona, anillos y lluvia de ascuas. */
    private static void nova(Vec3 pos, float radius) {
        int main = Palette.main(Fx.SOLAR);
        float k = radius / 3.0F;
        p(pos, FxAtlas.GLOW, 10).size(radius * 1.2F, radius * 2.6F, 0.5F).color(0xFFFFF0, 0xFF8A10).alpha(1.0F, 0.0F).spawn();
        p(pos, FxAtlas.CORONA, 12).size(radius * 0.6F, radius * 1.6F, 0.5F).color(0xFFF4C0, 0xFFA020).roll(rf(0, 6.28F), 0.03F)
                .alpha(1.0F, 0.0F).spawn();
        p(pos, FxAtlas.CORE, 8).size(radius * 0.5F, radius * 0.1F, 1.0F).color(0xFFFFFF).alpha(1.0F, 0.0F).spawn();
        p(pos, FxAtlas.LENS, 8).size(radius, radius * 0.3F, 1.0F).aspect(8.0F).color(0xFFD060).alpha(0.9F, 0.0F).spawn();
        ring(pos, UP, FxAtlas.SHOCK, 0xFFF0C0, radius * 0.3F, radius * 2.0F, 10, 0.9F);
        ring(pos, randomDir(), FxAtlas.RING, 0xFFE080, radius * 0.2F, radius * 1.8F, 12, 0.8F);
        ring(pos, randomDir(), FxAtlas.RING, 0xFFB040, radius * 0.2F, radius * 1.5F, 14, 0.6F);
        for (int i = 0; i < 10; i++) {
            Vec3 at = pos.add(randomDir().scale(radius * 0.3 * rnd().nextFloat()));
            p(at, FxAtlas.FIRE[0], 14 + rnd().nextInt(8)).frames(FxAtlas.FIRE, false).vel(randomDir().scale(0.05 * k)).drag(0.9)
                    .size(radius * rf(0.25F, 0.4F), radius * rf(0.5F, 0.75F), 0.4F).color(0xFFFFF0, main).roll(rf(0, 6.28F), rf(-0.05F, 0.05F))
                    .alpha(1.0F, 0.0F).alphaPow(1.5F).spawn();
        }
        sparks(pos, UP, 180.0, 30, 0xFFE080, 0.8F * k, 0.06F, 14, 0.02);
        embers(pos, 24, 0xFFB020, 0.3F * k, 34);
        smoke(pos.add(0, radius * 0.2, 0), 5, radius * 0.3F, 50, 0x8A7A60, new Vec3(0, 0.03, 0), radius * 0.5F);
    }

    /** ARPÓN: estallido de fusión celeste con arcos de plasma. */
    private static void fusion(Vec3 pos, float radius) {
        int main = Palette.main(Fx.ARPON);
        p(pos, FxAtlas.GLOW, 8).size(radius * 1.2F, radius * 2.0F, 0.5F).color(0xE8FFFF, main).alpha(1.0F, 0.0F).spawn();
        p(pos, FxAtlas.CORE, 6).size(radius * 0.4F, radius * 0.1F, 1.0F).color(0xFFFFFF).alpha(1.0F, 0.0F).spawn();
        p(pos, FxAtlas.LENS, 6).size(radius * 0.8F, radius * 0.25F, 1.0F).aspect(7.0F).color(main).alpha(0.8F, 0.0F).spawn();
        ring(pos, UP, FxAtlas.SHOCK, 0xC8F8FF, radius * 0.2F, radius * 1.7F, 9, 0.9F);
        ring(pos, randomDir(), FxAtlas.RING, main, radius * 0.2F, radius * 1.6F, 11, 0.8F);
        for (int i = 0; i < 6; i++) {
            Vec3 at = pos.add(randomDir().scale(radius * 0.3 * rnd().nextFloat()));
            p(at, FxAtlas.FIRE[0], 10 + rnd().nextInt(6)).frames(FxAtlas.FIRE, false).vel(randomDir().scale(0.05)).drag(0.88)
                    .size(radius * rf(0.2F, 0.3F), radius * rf(0.45F, 0.6F), 0.4F).color(0xE8FFFF, 0x1A70FF).roll(rf(0, 6.28F), 0.0F)
                    .alpha(1.0F, 0.0F).alphaPow(1.5F).spawn();
        }
        for (int i = 0; i < 5; i++) {
            Vec3 end = pos.add(randomDir().scale(radius * rf(0.6F, 1.1F)));
            new FxBeam(level(), pos, end, 4).sprite(FxAtlas.BEAM_THIN).jagged(0.3F, 1, rnd().nextLong()).taper(0.3F).width(0.06F, 0.02F)
                    .color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
        }
        sparks(pos, UP, 180.0, 20, 0xC8F8FF, 0.6F, 0.05F, 10, 0.02);
        smoke(pos.add(0, radius * 0.2, 0), 5, radius * 0.3F, 45, 0xB8C8CC, new Vec3(0, 0.03, 0), radius * 0.4F);
    }

    /** CÁUSTICA: salpicadura de ácido con gotas y burbujas. */
    private static void acidSplash(Vec3 pos, float radius) {
        int main = Palette.main(Fx.CAUSTICA);
        p(pos, FxAtlas.GLOW, 5).size(radius * 0.5F, radius * 0.9F, 0.6F).color(0xD8FF80, main).alpha(0.8F, 0.0F).spawn();
        ring(pos, UP, FxAtlas.RING_NOISE, main, radius * 0.2F, radius * 1.1F, 7, 0.7F);
        for (int i = 0; i < 10; i++) {
            p(pos, FxAtlas.EMBER, 12 + rnd().nextInt(10)).vel(cone(UP, 80).scale(rf(0.12F, 0.3F))).gravity(0.04).drag(0.95)
                    .size(rf(0.04F, 0.07F), 0.02F, 1.0F).color(0xE8FFA0, main).alpha(1.0F, 0.2F).spawn();
        }
        for (int i = 0; i < 3; i++) {
            p(pos.add(randomDir().scale(radius * 0.4)), FxAtlas.BUBBLE, 14 + rnd().nextInt(10)).vel(new Vec3(0, rf(0.01F, 0.03F), 0))
                    .size(rf(0.06F, 0.12F), rf(0.1F, 0.18F), 1.0F).color(0xD8FF80).alpha(0.9F, 0.0F).spawn();
        }
        smoke(pos, 1, 0.25F, 26, 0xA8D860, new Vec3(0, 0.02, 0), 0.2F);
    }

    /** ESQUIRLA: el cristal estalla en fragmentos violetas. */
    private static void crystalBurst(Vec3 pos, float radius) {
        int main = Palette.main(Fx.ESQUIRLA);
        p(pos, FxAtlas.GLOW, 5).size(radius * 0.6F, radius * 1.2F, 0.6F).color(0xF6E8FF, main).alpha(0.9F, 0.0F).spawn();
        p(pos, FxAtlas.LENS, 4).size(radius * 0.6F, radius * 0.2F, 1.0F).aspect(7.0F).color(main).alpha(0.8F, 0.0F).spawn();
        ring(pos, randomDir(), FxAtlas.RING, main, radius * 0.1F, radius * 1.0F, 7, 0.9F);
        for (int i = 0; i < 12; i++) {
            p(pos, FxAtlas.SHARD, 14 + rnd().nextInt(10)).soft().vel(randomDir().scale(rf(0.12F, 0.3F))).gravity(0.03).drag(0.93)
                    .size(rf(0.05F, 0.1F), 0.02F, 1.0F).color(0xF6E8FF, main).roll(rf(0, 6.28F), rf(-0.5F, 0.5F)).alpha(0.95F, 0.0F).spawn();
        }
        for (int i = 0; i < 8; i++) {
            p(pos.add(randomDir().scale(radius * 0.6 * rnd().nextFloat())), FxAtlas.GLINT, 8 + rnd().nextInt(10)).size(0.12F, 0.0F, 1.0F)
                    .color(0xFFFFFF, main).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
        }
    }

    /** ENJAMBRE: la cápsula se abre y los nanobots se dispersan. */
    private static void podBurst(Vec3 pos, float radius) {
        int main = Palette.main(Fx.ENJAMBRE);
        p(pos, FxAtlas.GLOW, 6).size(radius * 0.6F, radius * 1.2F, 0.6F).color(0xFFF0B0, main).alpha(0.9F, 0.0F).spawn();
        ring(pos, randomDir(), FxAtlas.RING_NOISE, main, radius * 0.2F, radius * 1.2F, 8, 0.8F);
        for (int i = 0; i < 18; i++) {
            p(pos, FxAtlas.EMBER, 10 + rnd().nextInt(10)).vel(randomDir().scale(rf(0.1F, 0.35F))).drag(0.85).size(0.05F, 0.02F, 1.0F)
                    .color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
        }
        smoke(pos, 2, 0.2F, 24, 0xB0A080, new Vec3(0, 0.02, 0), 0.2F);
    }

    /** Ceniza que sube (motas oscuras y chispas verdes). */
    private static void ash(Vec3 pos, int n, float spread) {
        for (int i = 0; i < n; i++) {
            Vec3 at = pos.add(randomDir().scale(spread * rnd().nextFloat()));
            p(at, FxAtlas.DEBRIS, 20 + rnd().nextInt(20)).soft().vel(new Vec3(rf(-0.02F, 0.02F), rf(0.02F, 0.06F), rf(-0.02F, 0.02F))).drag(0.96)
                    .gravity(-0.002).size(rf(0.03F, 0.06F), 0.0F, 1.0F).color(0x202420).roll(rf(0, 6.28F), rf(-0.2F, 0.2F)).alpha(1.0F, 0.0F).spawn();
            if (i % 2 == 0) {
                p(at, FxAtlas.EMBER, 12 + rnd().nextInt(10)).vel(new Vec3(0, rf(0.01F, 0.05F), 0)).size(0.05F, 0.0F, 1.0F).color(0xD8FFE8, 0x3CFF9E)
                        .alpha(1.0F, 0.0F).spawn();
            }
        }
    }

    /** Colapso del VÓRTICE: implosión violeta y estallido. */
    private static void collapse(Vec3 pos, float radius) {
        int main = Palette.main(Fx.VORTICE);
        p(pos, FxAtlas.GLOW, 8).size(radius * 1.6F, radius * 0.4F, 0.6F).color(0xF4E8FF, main).alpha(1.0F, 0.0F).spawn();
        p(pos, FxAtlas.CORE, 6).size(radius * 0.6F, radius * 0.1F, 1.0F).color(0xFFFFFF).alpha(1.0F, 0.0F).spawn();
        p(pos, FxAtlas.LENS, 6).size(radius * 0.8F, radius * 0.3F, 1.0F).aspect(7.0F).color(main).alpha(0.9F, 0.0F).spawn();
        ring(pos, UP, FxAtlas.SHOCK, main, radius * 1.8F, radius * 0.2F, 7, 0.9F);
        ring(pos, UP, FxAtlas.RING, 0xF0D8FF, radius * 0.2F, radius * 2.2F, 12, 0.8F);
        ring(pos, randomDir(), FxAtlas.ACCRETION, main, radius * 0.4F, radius * 1.4F, 10, 0.8F);
        p(pos, FxAtlas.VORTEX, 12).size(radius * 1.2F, radius * 0.1F, 0.7F).color(main).roll(0.0F, 0.5F).alpha(1.0F, 0.0F).spawn();
        for (int i = 0; i < 24; i++) {
            Vec3 d = randomDir();
            p(pos.add(d.scale(radius * 1.2)), FxAtlas.SPARK, 6).mode(Mode.VELOCITY).vel(d.scale(-radius * 0.2)).size(0.06F, 0.02F, 1.0F)
                    .aspect(3.0F).stretch(1.4F).color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
        }
        sparks(pos, UP, 180.0, 16, 0xD8B8FF, 0.6F, 0.05F, 12, 0.0);
    }

    private static void vortexOpen(Vec3 pos, float radius) {
        int main = Palette.main(Fx.VORTICE);
        p(pos, FxAtlas.GLOW, 8).size(1.0F, 2.5F, 0.5F).color(0xF4E8FF, main).alpha(1.0F, 0.0F).spawn();
        ring(pos, UP, FxAtlas.SHOCK, main, 0.4F, radius * 1.1F, 10, 0.8F);
        ring(pos, UP, FxAtlas.RING, 0xF0D8FF, radius, 0.3F, 12, 0.7F);
    }

    // ================================================================ haces

    /** Rayo de riel de la AGUJA: núcleo blanco, resplandor celeste y una hélice que se desvanece. */
    private static void rail(Vec3 from, Vec3 to, float charge, @Nullable Entity shooter) {
        ClientLevel level = level();
        Vec3 start = shooter != null ? Muzzle.world(shooter, 1.0F) : from;
        float k = 0.6F + 0.4F * charge;
        int main = Palette.main(Fx.AGUJA);
        new FxBeam(level, start, to, 14).sprite(FxAtlas.BEAM_THIN).width(0.07F * k, 0.0F).color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
        new FxBeam(level, start, to, 18).sprite(FxAtlas.BEAM).width(0.28F * k, 0.06F).color(main, 0x1E7CFF).alpha(0.85F, 0.0F).alphaPow(0.7F).spawn();
        new FxBeam(level, start, to, 24).sprite(FxAtlas.BEAM_THIN).helix(0.16F + 0.08F * charge, 0.55F, 0.25F, rf(0, 6.28F))
                .width(0.035F, 0.0F).color(0xB8F8FF, 0x2A70FF).alpha(0.9F, 0.0F).spawn();
        new FxBeam(level, start, to, 10).sprite(FxAtlas.BEAM_NOISE).tile(2.0F, 0.6F).width(0.12F * k, 0.02F).color(0xDFFFFF, main)
                .alpha(0.8F, 0.0F).spawn();
        // destellos a lo largo del recorrido
        Vec3 d = to.subtract(start);
        double len = d.length();
        int n = Mth.clamp((int) (len / 1.6), 2, 70);
        for (int i = 0; i < n; i++) {
            Vec3 at = start.add(d.scale(rnd().nextDouble()));
            p(at, FxAtlas.GLINT, 8 + rnd().nextInt(14)).size(rf(0.05F, 0.12F), 0.0F, 1.0F).color(0xFFFFFF, main)
                    .vel(randomDir().scale(0.015)).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
        }
    }

    /** Rayo eléctrico de la CHISPA: resplandor azul y núcleo blanco con la misma forma en zigzag. */
    private static void arc(int style, Vec3 from, Vec3 to, float thickness, @Nullable Entity shooter) {
        ClientLevel level = level();
        if (shooter != null && Muzzle.firstPerson(shooter)) Muzzle.fired(style, 0.04F);
        long seed = rnd().nextLong();
        double len = from.distanceTo(to);
        float jag = (float) Mth.clamp(0.12 + len * 0.035, 0.15, 0.9);
        new FxBeam(level, from, to, 3).anchor(shooter).sprite(FxAtlas.BEAM).jagged(jag, 1, seed).taper(0.1F)
                .width(0.22F * thickness, 0.12F * thickness).color(0x7FA8FF, 0x4060FF).alpha(0.8F, 0.0F).spawn();
        new FxBeam(level, from, to, 3).anchor(shooter).sprite(FxAtlas.BEAM_THIN).jagged(jag, 1, seed).taper(0.1F)
                .width(0.06F * thickness, 0.03F * thickness).color(0xFFFFFF, 0xFFF4C0).alpha(1.0F, 0.2F).spawn();
        // ramas cortas
        if (rnd().nextFloat() < 0.6F) {
            Vec3 a = from.add(to.subtract(from).scale(rf(0.2F, 0.8F)));
            Vec3 b = a.add(randomDir().scale(rf(0.5F, 1.6F)));
            new FxBeam(level, a, b, 2).sprite(FxAtlas.BEAM_THIN).jagged(0.2F, 1, rnd().nextLong()).taper(0.3F).width(0.03F, 0.01F)
                    .color(0xE8F0FF, 0x6080FF).alpha(0.9F, 0.0F).spawn();
        }
        p(to, FxAtlas.GLOW, 3).size(0.35F * thickness, 0.5F * thickness, 1.0F).color(0x9CC8FF).alpha(0.7F, 0.0F).spawn();
        if (shooter == null) p(from, FxAtlas.GLOW, 3).size(0.3F * thickness).color(0x9CC8FF).alpha(0.6F, 0.0F).spawn();
    }

    /** Remache: trazo rapidísimo desde la boca del cañón hasta el punto de impacto. */
    private static void tracer(int style, Vec3 from, Vec3 to, @Nullable Entity shooter) {
        Vec3 start = shooter != null ? Muzzle.world(shooter, 1.0F) : from;
        Vec3 d = to.subtract(start);
        double len = d.length();
        if (len < 0.3) return;
        double speed = 9.0;
        int life = Math.max(1, (int) Math.ceil(len / speed));
        p(start, FxAtlas.SPARK, life + 1).mode(Mode.VELOCITY).vel(d.scale(speed / len)).size(0.035F).aspect(4.0F).stretch(0.8F)
                .color(0xFFF0D0, Palette.main(style)).alpha(1.0F, 0.6F).spawn();
    }

    /** Chorro del SOPLETE: llamas de plasma que nacen azules en la boquilla y se vuelven fuego. */
    private static void flame(Vec3 from, Vec3 to, float range, @Nullable Entity shooter) {
        if (shooter != null && Muzzle.firstPerson(shooter)) Muzzle.fired(Fx.SOPLETE, 0.03F);
        Vec3 start = shooter != null ? Muzzle.world(shooter, 1.0F) : from;
        Vec3 d = to.subtract(start);
        double len = Math.max(1.0, d.length());
        Vec3 dir = d.scale(1.0 / len);
        p(start, FxAtlas.GLOW, 3).size(0.25F, 0.3F, 1.0F).color(0x7FB8FF).alpha(0.9F, 0.0F).spawn();
        p(start, FxAtlas.FLASH_SIDE, 2).mode(Mode.AXIS).axis(dir).size(0.1F).aspect(2.0F).color(0xDDEEFF, 0x5A8CFF).alpha(1.0F, 0.0F).spawn();
        for (int i = 0; i < 7; i++) {
            Vec3 v = cone(dir, 6.0).scale(rf(0.75F, 1.0F) * 1.25);
            int life = (int) Mth.clamp(len / 1.25 * rf(0.85F, 1.05F), 4, 20);
            p(start.add(randomDir().scale(0.05)), FxAtlas.FLAME[0], life).frames(FxAtlas.FLAME, true).vel(v).drag(0.97)
                    .size(0.08F, rf(0.7F, 1.1F), 0.7F).color(0xA8D4FF, 0xFF5A14).roll(rf(0, 6.28F), rf(-0.15F, 0.15F))
                    .alpha(1.0F, 0.0F).alphaPow(1.4F).spawn();
        }
        if (rnd().nextFloat() < 0.7F) embers(start.add(dir.scale(len * rf(0.3F, 0.9F))), 1, 0xFF7020, 0.08F, 16);
        if (rnd().nextFloat() < 0.5F) smoke(start.add(dir.scale(len)), 1, 0.4F, 30, 0x4A4440, new Vec3(0, 0.04, 0), 0.4F);
    }

    /** Láser del TRUENO: celeste que se vuelve rojo al calentarse. */
    private static void laser(Vec3 from, Vec3 to, float heat, @Nullable Entity shooter) {
        ClientLevel level = level();
        if (shooter != null && Muzzle.firstPerson(shooter)) Muzzle.fired(Fx.TRUENO, 0.02F + heat * 0.04F);
        int color = Palette.mix(0x5FE6FF, 0xFF2A1A, heat);
        int core = Palette.mix(0xE8FDFF, 0xFFE0D0, heat);
        float w = 1.0F + heat;
        new FxBeam(level, from, to, 3).anchor(shooter).sprite(FxAtlas.BEAM_THIN).width(0.045F * w, 0.04F * w).color(core).alpha(1.0F, 0.6F).spawn();
        new FxBeam(level, from, to, 3).anchor(shooter).sprite(FxAtlas.BEAM).width(0.2F * w, 0.18F * w).color(color).alpha(0.75F, 0.4F).spawn();
        new FxBeam(level, from, to, 3).anchor(shooter).sprite(FxAtlas.BEAM_NOISE).tile(1.6F, 0.5F).width(0.12F * w, 0.1F * w).color(color)
                .alpha(0.7F, 0.3F).spawn();
        Vec3 start = shooter != null ? Muzzle.world(shooter, 1.0F) : from;
        p(start, FxAtlas.GLOW, 3).size(0.2F * w).color(color).alpha(0.8F, 0.0F).spawn();
        // punto de impacto incandescente
        Vec3 back = start.subtract(to);
        Vec3 n = back.lengthSqr() < 1.0E-6 ? UP : back.normalize();
        p(to, FxAtlas.GLOW, 3).size(0.4F * w, 0.5F * w, 1.0F).color(color).alpha(0.9F, 0.0F).spawn();
        p(to, FxAtlas.CORE, 2).size(0.12F * w).color(core).alpha(1.0F, 0.0F).spawn();
        if (rnd().nextFloat() < 0.6F) sparks(to, n, 70, 2 + (int) (heat * 4), Palette.mix(0xBFF8FF, 0xFFB060, heat), 0.3F, 0.03F, 6, 0.03);
        if (heat > 0.6F && rnd().nextFloat() < 0.4F) smoke(to, 1, 0.15F, 22, 0x605A56, new Vec3(0, 0.03, 0), 0.05F);
    }

    /** Cuerda azul de la SERPENTINA: une el látigo con el enemigo mientras lo arrastra. */
    private static void rope(Vec3 from, Vec3 to, float ticks, @Nullable Entity shooter, @Nullable Entity target) {
        ClientLevel level = level();
        int life = Math.max(4, (int) ticks);
        boolean miss = target == null;
        new FxBeam(level, from, to, life).anchor(shooter).target(target).sprite(FxAtlas.ROPE).jagged(0.25F, 1, 0L)
                .shape(FxBeam.Shape.WAVE).tile(0.9F, 0.0F).width(0.07F, 0.05F).color(0x6C8CFF, 0x3050FF).alpha(1.0F, miss ? 0.0F : 0.7F)
                .grow(miss ? 3.0F : 2.0F).spawn();
        new FxBeam(level, from, to, life).anchor(shooter).target(target).sprite(FxAtlas.BEAM).width(0.16F, 0.1F).color(0x3A5CFF)
                .alpha(0.55F, miss ? 0.0F : 0.3F).grow(miss ? 3.0F : 2.0F).spawn();
        if (target != null) {
            p(target.position().add(0, target.getBbHeight() * 0.55, 0), FxAtlas.RING, 8).follow(target, new Vec3(0, target.getBbHeight() * 0.55, 0))
                    .size(0.6F, 0.9F, 1.0F).color(0x7090FF).alpha(0.8F, 0.0F).spawn();
            sparks(target.getBoundingBox().getCenter(), UP, 180.0, 8, 0xD8E4FF, 0.3F, 0.04F, 6, 0.0);
        }
    }

    private static void drill(Vec3 pos, Vec3 dir, int stage) {
        int color = stage == 2 ? 0xFF5020 : stage == 1 ? 0xFFA020 : 0xFFE060;
        Vec3 n = dir.lengthSqr() < 1.0E-6 ? UP : dir.normalize().reverse();
        p(pos, FxAtlas.DRILL, 4).mode(Mode.FIXED).axis(n).size(0.25F + stage * 0.08F).color(color).roll(rf(0, 6.28F), 0.8F).alpha(0.9F, 0.0F).spawn();
        p(pos, FxAtlas.GLOW, 3).size(0.3F + stage * 0.15F).color(color).alpha(0.8F, 0.0F).spawn();
        sparks(pos, n, 75, 4 + stage * 5, color, 0.35F + stage * 0.12F, 0.04F, 7, 0.04);
        if (stage == 2) {
            embers(pos, 3, 0xFF4010, 0.12F, 14);
            if (rnd().nextFloat() < 0.4F) smoke(pos, 1, 0.12F, 18, 0x5A5450, new Vec3(0, 0.02, 0), 0.05F);
        }
    }

    private static void lock(@Nullable Entity target, int count) {
        if (target == null) return;
        Vec3 off = new Vec3(0, target.getBbHeight() * 0.55, 0);
        float size = Math.max(0.45F, target.getBbWidth() * 0.7F);
        p(target.position().add(off), FxAtlas.LOCK, 40).follow(target, off).size(size * 1.6F, size, 0.3F).color(0xFF4A3A)
                .alpha(1.0F, 0.6F).spawn();
        p(target.position().add(off), FxAtlas.RING, 8).follow(target, off).size(size * 2.0F, size * 0.6F, 0.5F).color(0xFF6A4A)
                .alpha(0.9F, 0.0F).spawn();
    }

    private static void melee(int style, Vec3 pos, Vec3 dir, float power) {
        Vec3 d = dir.lengthSqr() < 1.0E-6 ? UP : dir.normalize();
        int main = Palette.main(style);
        int hot = Palette.hot(style);
        switch (style) {
            case Fx.MARTINETE -> {
                flash(pos, main, hot, 0.6F, 4);
                ring(pos, d, FxAtlas.SHOCK, 0xFFD8A0, 0.2F, 1.4F, 7, 0.8F);
                sparks(pos, d.reverse(), 80, 10, 0xFFB050, 0.5F, 0.05F, 9, 0.04);
                smoke(pos, 3, 0.2F, 24, 0x9A928A, d.scale(0.03), 0.3F);
            }
            case Fx.CIZALLA -> {
                p(pos, FxAtlas.CRESCENT, 6).size(0.7F, 1.1F, 0.5F).color(hot, main).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
                flash(pos, main, hot, 0.45F, 3);
                sparks(pos, d, 70, 8, Palette.spark(style), 0.4F, 0.04F, 7, 0.0);
            }
            case Fx.SERPENTINA -> {
                float k = power > 1.5F ? 1.8F : 1.0F;
                flash(pos, main, hot, 0.45F * k, 4);
                for (int i = 0; i < (int) (3 * k); i++) {
                    Vec3 end = pos.add(randomDir().scale(rf(0.6F, 1.4F) * k));
                    new FxBeam(level(), pos, end, 3).sprite(FxAtlas.BEAM_THIN).jagged(0.15F, 1, rnd().nextLong()).taper(0.3F).width(0.04F, 0.02F)
                            .color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
                }
                if (k > 1.0F) ring(pos, d, FxAtlas.RING_NOISE, main, 0.2F, 1.6F, 8, 0.9F);
            }
            case Fx.GUADANA -> {
                p(pos, FxAtlas.CRESCENT, 6).size(0.6F, 1.0F, 0.5F).color(hot, main).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
                flash(pos, main, hot, 0.45F, 3);
                sparks(pos, d, 70, 10, Palette.spark(style), 0.45F, 0.045F, 8, 0.02);
                embers(pos, 4, 0xFF2040, 0.1F, 12);
            }
            case Fx.PICA -> {
                flash(pos, main, hot, 0.5F, 4);
                ring(pos, d, FxAtlas.RING, main, 0.1F, 0.9F, 7, 0.9F);
                sparks(pos, d, 40, 10, Palette.spark(style), 0.55F, 0.045F, 8, 0.0);
            }
            default -> {
                flash(pos, main, hot, 0.4F, 3);
                sparks(pos, d, 70, 6, Palette.spark(style), 0.35F, 0.04F, 7, 0.02);
            }
        }
    }

    private static void shield(Vec3 pos, Vec3 dir) {
        int main = Palette.main(Fx.BASTION);
        Vec3 d = dir.lengthSqr() < 1.0E-6 ? UP : dir.normalize();
        p(pos, FxAtlas.HEX, 9).mode(Mode.FIXED).axis(d).size(0.5F, 0.9F, 0.5F).color(0xFFF0D8, main).alpha(1.0F, 0.0F).spawn();
        ring(pos, d, FxAtlas.RING, main, 0.2F, 1.0F, 7, 0.8F);
        sparks(pos, d, 70, 8, 0xFFD8A0, 0.35F, 0.04F, 7, 0.03);
    }

    private static void drone(Vec3 pos, Vec3 dir) {
        int main = Palette.main(Fx.HALCON);
        flash(pos, main, 0xFFF0D8, 0.5F, 4);
        ring(pos, UP, FxAtlas.RING, main, 0.2F, 1.2F, 8, 0.8F);
        sparks(pos, UP, 180.0, 8, 0xFFD090, 0.3F, 0.04F, 7, 0.02);
    }

    // ================================================================ serie PX-2x / PX-3x

    /** PRISMA: haz blanco hasta el cristal (valor -1) y los cinco rayos de colores (valor 0–4). */
    private static void prism(Vec3 from, Vec3 to, float value, @Nullable Entity shooter) {
        ClientLevel level = level();
        int idx = Math.round(value);
        if (idx < 0) {
            Vec3 start = shooter != null ? Muzzle.world(shooter, 1.0F) : from;
            new FxBeam(level, start, to, 6).anchor(shooter).sprite(FxAtlas.BEAM).width(0.24F, 0.05F).color(0xFFFFFF, 0xD8E0FF).alpha(0.9F, 0.0F).spawn();
            new FxBeam(level, start, to, 5).anchor(shooter).sprite(FxAtlas.BEAM_THIN).width(0.07F, 0.0F).color(0xFFFFFF).alpha(1.0F, 0.0F).spawn();
            p(to, FxAtlas.STAR6, 5).size(0.35F, 0.6F, 1.0F).color(0xFFFFFF).roll(rf(0, 6.28F), 0.1F).alpha(1.0F, 0.0F).spawn();
            p(to, FxAtlas.GLOW, 6).size(0.5F, 0.9F, 1.0F).color(0xF0F4FF).alpha(0.9F, 0.0F).spawn();
            p(to, FxAtlas.LENS, 5).size(0.4F, 0.15F, 1.0F).aspect(9.0F).color(0xFFFFFF).alpha(0.8F, 0.0F).spawn();
            return;
        }
        int c = Palette.RAINBOW[Mth.clamp(idx, 0, Palette.RAINBOW.length - 1)];
        int core = Palette.mix(c, 0xFFFFFF, 0.6F);
        new FxBeam(level, from, to, 8).sprite(FxAtlas.BEAM).width(0.2F, 0.04F).color(c).alpha(0.85F, 0.0F).alphaPow(0.8F).spawn();
        new FxBeam(level, from, to, 6).sprite(FxAtlas.BEAM_THIN).width(0.05F, 0.0F).color(core).alpha(1.0F, 0.0F).spawn();
        new FxBeam(level, from, to, 8).sprite(FxAtlas.BEAM_NOISE).tile(2.0F, 0.8F).width(0.1F, 0.02F).color(c).alpha(0.6F, 0.0F).spawn();
        Vec3 back = from.subtract(to);
        Vec3 n = back.lengthSqr() < 1.0E-6 ? UP : back.normalize();
        flash(to, c, core, 0.35F, 4);
        sparks(to, n, 70, 5, c, 0.35F, 0.04F, 7, 0.02);
        double len = from.distanceTo(to);
        int k = Mth.clamp((int) (len / 3.0), 1, 20);
        for (int i = 0; i < k; i++) {
            Vec3 at = from.add(to.subtract(from).scale(rnd().nextDouble()));
            p(at, FxAtlas.GLINT, 6 + rnd().nextInt(8)).size(rf(0.04F, 0.09F), 0.0F, 1.0F).color(core, c).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
        }
    }

    /** TEMPESTAD: rayo que cae de la nube (valor 1) o que sube desde el cañón a formarla (valor &lt; 1). */
    private static void lightning(Vec3 from, Vec3 to, float value, @Nullable Entity shooter) {
        ClientLevel level = level();
        long seed = rnd().nextLong();
        double len = from.distanceTo(to);
        float jag = (float) Mth.clamp(0.15 + len * 0.05, 0.3, 1.4);
        float w = 0.6F + 0.4F * value;
        new FxBeam(level, from, to, 5).anchor(shooter).sprite(FxAtlas.BEAM).jagged(jag, 2, seed).width(0.5F * w, 0.3F * w).color(0x9AB8FF, 0x5A70FF)
                .alpha(0.9F, 0.0F).spawn();
        new FxBeam(level, from, to, 5).anchor(shooter).sprite(FxAtlas.BEAM_THIN).jagged(jag, 2, seed).width(0.12F * w, 0.08F * w).color(0xFFFFFF, 0xE0E8FF)
                .alpha(1.0F, 0.0F).spawn();
        for (int i = 0; i < 3; i++) {
            Vec3 a = from.add(to.subtract(from).scale(rf(0.2F, 0.85F)));
            Vec3 b = a.add(randomDir().scale(rf(0.8F, 2.2F))).add(0, -rf(0.3F, 1.2F), 0);
            new FxBeam(level, a, b, 3).sprite(FxAtlas.BEAM_THIN).jagged(0.3F, 1, rnd().nextLong()).taper(0.4F).width(0.05F, 0.02F)
                    .color(0xE8F0FF, 0x7090FF).alpha(0.9F, 0.0F).spawn();
        }
        if (value >= 0.99F) {
            p(to, FxAtlas.GLOW, 6).size(1.2F, 2.0F, 0.5F).color(0xE0E8FF, 0x6A80FF).alpha(1.0F, 0.0F).spawn();
            p(to, FxAtlas.CORE, 4).size(0.4F, 0.1F, 1.0F).color(0xFFFFFF).alpha(1.0F, 0.0F).spawn();
            ring(to.add(0, 0.1, 0), UP, FxAtlas.SHOCK, 0xC8D8FF, 0.3F, 2.2F, 8, 0.8F);
            sparks(to, UP, 75, 12, 0xD8E4FF, 0.5F, 0.045F, 8, 0.04);
            smoke(to, 2, 0.3F, 30, 0x5A5A66, new Vec3(0, 0.03, 0), 0.3F);
        }
        p(from, FxAtlas.GLOW, 4).size(1.5F, 2.5F, 0.6F).color(0xC8D8FF).alpha(0.7F, 0.0F).spawn();
    }

    /** TEMPESTAD: la nube se forma (destello y cúmulos que se expanden). */
    private static void stormForm(Vec3 pos, float radius) {
        p(pos, FxAtlas.GLOW, 10).size(1.0F, radius * 1.6F, 0.5F).color(0xB8C8FF, 0x4A5AA0).alpha(0.8F, 0.0F).spawn();
        for (int i = 0; i < 8; i++) {
            Vec3 off = randomDir().multiply(1.0, 0.3, 1.0).scale(radius * 0.4);
            p(pos.add(off), FxAtlas.CLOUD[rnd().nextInt(FxAtlas.CLOUD.length)], 20 + rnd().nextInt(10)).soft().vel(off.scale(0.04)).drag(0.9)
                    .size(0.6F, 1.8F, 0.5F).color(0x6A7490).alpha(0.8F, 0.0F).fadeIn(0.2F).roll(rf(0, 6.28F), rf(-0.02F, 0.02F)).spawn();
        }
        ring(pos, UP, FxAtlas.SHOCK, 0xA8B8FF, 0.5F, radius * 1.2F, 10, 0.7F);
    }

    /** GUADAÑA: media luna roja enorme delante del atacante y chispas a lo largo del arco. */
    private static void sweep(Vec3 center, Vec3 dir, float radius, @Nullable Entity attacker) {
        Vec3 l = new Vec3(dir.x, 0.0, dir.z);
        l = l.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : l.normalize();
        float size = radius / 1.05F;
        Vec3 c = center.add(l.scale(0.55 * size));
        // la curva del sprite (abajo en la textura) mira hacia delante
        float roll = (float) Math.atan2(l.z, -l.x);
        int main = Palette.main(Fx.GUADANA);
        int hot = Palette.hot(Fx.GUADANA);
        p(c, FxAtlas.CRESCENT, 6).mode(Mode.FIXED).axis(UP).size(size * 0.9F, size, 0.5F).color(hot, main).roll(roll, 0.0F).alpha(1.0F, 0.0F).spawn();
        p(c.add(0, 0.15, 0), FxAtlas.CRESCENT, 8).mode(Mode.FIXED).axis(UP).size(size * 0.85F, size * 1.05F, 0.5F).color(main, 0x600010).roll(roll, 0.0F)
                .alpha(0.7F, 0.0F).spawn();
        for (int i = 0; i < 14; i++) {
            double a = Math.toRadians(-72.0 + 144.0 * i / 13.0);
            Vec3 d = new Vec3(l.x * Math.cos(a) - l.z * Math.sin(a), 0.0, l.x * Math.sin(a) + l.z * Math.cos(a));
            Vec3 at = center.add(d.scale(radius * rf(0.8F, 1.0F)));
            Vec3 tangent = new Vec3(-d.z, 0.0, d.x);
            p(at, FxAtlas.SPARK, 6 + rnd().nextInt(4)).mode(Mode.VELOCITY).vel(tangent.scale(rf(0.2F, 0.4F))).drag(0.8).size(0.05F, 0.01F, 1.0F)
                    .aspect(3.0F).stretch(1.5F).color(0xFFFFFF, main).alpha(1.0F, 0.0F).spawn();
        }
        if (attacker != null && Muzzle.firstPerson(attacker)) Muzzle.swung(Fx.GUADANA, 9);
    }

    /** PICA: lanza de plasma que sale disparada hasta la punta de la estocada. */
    private static void thrust(Vec3 from, Vec3 to, float hitWall, @Nullable Entity attacker) {
        ClientLevel level = level();
        Vec3 start = attacker != null ? Muzzle.world(attacker, 1.0F) : from;
        int main = Palette.main(Fx.PICA);
        new FxBeam(level, start, to, 5).sprite(FxAtlas.BEAM).width(0.3F, 0.0F).taper(0.6F).color(0xE8F4FF, main).alpha(0.9F, 0.0F).spawn();
        new FxBeam(level, start, to, 4).sprite(FxAtlas.BEAM_THIN).width(0.08F, 0.0F).color(0xFFFFFF).alpha(1.0F, 0.0F).spawn();
        new FxBeam(level, start, to, 6).sprite(FxAtlas.BEAM_THIN).helix(0.12F, 0.8F, 0.4F, rf(0, 6.28F)).width(0.03F, 0.0F).color(0xB8DCFF, main)
                .alpha(0.9F, 0.0F).spawn();
        Vec3 d = to.subtract(start);
        Vec3 n = d.lengthSqr() < 1.0E-6 ? UP : d.normalize();
        ring(to, n, FxAtlas.RING, main, 0.1F, 0.8F, 6, 0.9F);
        p(to, FxAtlas.STAR4, 4).size(0.3F, 0.15F, 1.0F).color(0xFFFFFF, main).roll(rf(0, 6.28F), 0.0F).alpha(1.0F, 0.0F).spawn();
        if (hitWall > 0.5F) sparks(to, n.reverse(), 70, 8, Palette.spark(Fx.PICA), 0.4F, 0.04F, 7, 0.03);
        if (attacker != null && Muzzle.firstPerson(attacker)) Muzzle.swung(Fx.PICA, 8);
    }

    /** CENIZA: la criatura alcanzada se deshace en ceniza y chispas verdes. */
    private static void disintegrate(Vec3 pos, float height, @Nullable Entity target) {
        int main = Palette.main(Fx.CENIZA);
        float h = Math.max(0.5F, height);
        p(pos, FxAtlas.GLOW, 8).size(h * 0.6F, h, 0.6F).color(0xC8FFE0, main).alpha(0.9F, 0.0F).spawn();
        ring(pos, UP, FxAtlas.RING, main, h * 0.2F, h * 0.9F, 10, 0.9F);
        for (int i = 0; i < 18; i++) {
            Vec3 at = pos.add((rnd().nextFloat() - 0.5) * 0.8, (rnd().nextFloat() - 0.5) * h, (rnd().nextFloat() - 0.5) * 0.8);
            p(at, FxAtlas.DEBRIS, 20 + rnd().nextInt(20)).soft().vel(new Vec3(rf(-0.02F, 0.02F), rf(0.02F, 0.06F), rf(-0.02F, 0.02F))).drag(0.96)
                    .gravity(-0.002).size(rf(0.03F, 0.06F), 0.0F, 1.0F).color(0x202420).roll(rf(0, 6.28F), rf(-0.2F, 0.2F)).alpha(1.0F, 0.0F).spawn();
            if (i % 2 == 0) {
                p(at, FxAtlas.EMBER, 12 + rnd().nextInt(10)).vel(new Vec3(0, rf(0.01F, 0.05F), 0)).size(0.05F, 0.0F, 1.0F).color(0xD8FFE8, main)
                        .alpha(1.0F, 0.0F).spawn();
            }
        }
        if (target != null) {
            Vec3 off = new Vec3(0, h * 0.5, 0);
            p(target.position().add(off), FxAtlas.GLOW, 10).follow(target, off).size(h * 0.7F, h * 0.4F, 1.0F).color(main).alpha(0.6F, 0.0F).spawn();
        }
    }

    // ================================================================ estelas de los proyectiles (cada tick en el cliente)

    public static void projectileTick(PXProjectile e) {
        if (level() == null) return;
        RandomSource r = rnd();
        Vec3 pos = e.position();
        Vec3 back = e.heading().reverse();
        if (e instanceof PlasmaBolt bolt) {
            int c = bolt.isHot() ? 0xFF7A20 : 0x9CFF3A;
            p(pos.add(back.scale(0.3)), FxAtlas.EMBER, 6 + r.nextInt(4)).vel(randomDir().scale(0.01)).size(0.05F, 0.0F, 1.0F).color(0xFFFFFF, c)
                    .alpha(0.9F, 0.0F).spawn();
            if (bolt.isHot() && r.nextFloat() < 0.5F) embers(pos, 1, 0xFF5010, 0.03F, 10);
        } else if (e instanceof EnergyBolt bolt) {
            switch (bolt.style()) {
                case EnergyBolt.FROST -> {
                    if (r.nextFloat() < 0.6F) {
                        p(pos.add(back.scale(0.4)), FxAtlas.SNOW, 10 + r.nextInt(6)).vel(randomDir().scale(0.01)).size(0.06F, 0.0F, 1.0F)
                                .color(0xFFFFFF, 0x9FEFFF).roll(r.nextFloat() * 6.28F, 0.2F).alpha(1.0F, 0.0F).spawn();
                    }
                    if (r.nextFloat() < 0.3F) smoke(pos, 1, 0.06F, 12, 0xE8FAFF, Vec3.ZERO, 0.02F);
                }
                case EnergyBolt.NEEDLE -> {
                    if (r.nextFloat() < 0.4F) {
                        p(pos, FxAtlas.GLINT, 5).size(0.07F, 0.0F, 1.0F).color(0xFFB0E0).roll(r.nextFloat() * 6.28F, 0.0F).alpha(1.0F, 0.0F).spawn();
                    }
                }
                case EnergyBolt.SLUG -> {
                    p(pos.add(back.scale(0.3)), FxAtlas.EMBER, 8 + r.nextInt(4)).vel(randomDir().scale(0.015)).size(0.06F, 0.0F, 1.0F).color(0xFFFFFF, 0xFFC83A)
                            .alpha(0.9F, 0.0F).spawn();
                    if (r.nextFloat() < 0.3F) embers(pos, 1, 0xFFA020, 0.03F, 10);
                }
                case EnergyBolt.DRONE, EnergyBolt.BULLET -> {
                    if (r.nextFloat() < 0.5F) {
                        p(pos.add(back.scale(0.3)), FxAtlas.EMBER, 5).size(0.04F, 0.0F, 1.0F).color(0xFFFFFF, Palette.main(bolt.style() == EnergyBolt.DRONE ? Fx.HALCON : Fx.BASTION))
                                .alpha(0.9F, 0.0F).spawn();
                    }
                }
                default -> {}
            }
        } else if (e instanceof MicroRocket) {
            Vec3 tail = pos.add(back.scale(0.35));
            smoke(tail, 1, 0.12F, 30, 0xB4B0AA, back.scale(0.02).add(0, 0.008, 0), 0.05F);
            p(tail, FxAtlas.GLOW, 3).size(0.3F, 0.15F, 1.0F).color(0xFF8A30).alpha(0.8F, 0.0F).spawn();
            if (r.nextFloat() < 0.5F) embers(tail, 1, 0xFF7020, 0.04F, 8);
        } else if (e instanceof Grenade g) {
            boolean small = g.kind() == Grenade.BOMBLET;
            p(pos, FxAtlas.EMBER, 6).vel(randomDir().scale(0.02)).size(small ? 0.03F : 0.05F, 0.0F, 1.0F).color(0xFFFFFF, 0xFFA040).alpha(1.0F, 0.0F).spawn();
            if (!small && r.nextFloat() < 0.35F) smoke(pos, 1, 0.08F, 18, 0x9A9890, new Vec3(0, 0.01, 0), 0.02F);
        } else if (e instanceof SawDisc) {
            if (r.nextFloat() < 0.3F) sparks(pos, UP, 180.0, 1, 0x9FFFD6, 0.15F, 0.03F, 5, 0.03);
        } else if (e instanceof Singularity s) {
            if (s.isOpen()) {
                // la materia cae en espiral hacia el centro
                for (int i = 0; i < 3; i++) {
                    double ang = r.nextDouble() * Math.PI * 2.0;
                    double rad = Singularity.PULL_RADIUS * (0.6 + 0.4 * r.nextDouble());
                    Vec3 at = pos.add(Math.cos(ang) * rad, (r.nextDouble() - 0.5) * 2.0, Math.sin(ang) * rad);
                    Vec3 to = pos.subtract(at);
                    Vec3 swirl = to.cross(UP).normalize().scale(0.25);
                    p(at, FxAtlas.SPARK, 14).mode(Mode.VELOCITY).vel(to.scale(0.07).add(swirl)).drag(0.98).size(0.05F, 0.01F, 1.0F).aspect(3.0F)
                            .stretch(2.0F).color(0xF0E0FF, 0xA45CFF).alpha(0.0F, 1.0F).fadeIn(0.3F).spawn();
                }
            } else if (r.nextFloat() < 0.7F) {
                p(pos.add(randomDir().scale(0.3)), FxAtlas.GLINT, 8).vel(back.scale(0.05)).size(0.08F, 0.0F, 1.0F).color(0xE8D8FF, 0xA45CFF)
                        .roll(r.nextFloat() * 6.28F, 0.1F).alpha(1.0F, 0.0F).spawn();
            }
        } else if (e instanceof Orb o) {
            switch (o.kind()) {
                case Orb.SHELL -> {
                    smoke(pos.add(back.scale(0.3)), 1, 0.14F, 34, 0xA8A49E, back.scale(0.01).add(0, 0.006, 0), 0.04F);
                    if (r.nextFloat() < 0.5F) embers(pos, 1, 0xFF7020, 0.03F, 8);
                }
                case Orb.SOLAR -> {
                    embers(pos, 2, 0xFFB020, 0.06F, 14);
                    if (r.nextFloat() < 0.4F) {
                        p(pos.add(randomDir().scale(0.4)), FxAtlas.FLAME[0], 10).frames(FxAtlas.FLAME, true).size(0.15F, 0.3F, 1.0F).vel(randomDir().scale(0.02))
                                .color(0xFFF0B0, 0xFF6010).alpha(0.8F, 0.0F).spawn();
                    }
                }
                case Orb.POD -> {
                    if (r.nextFloat() < 0.6F) {
                        p(pos.add(back.scale(0.2)), FxAtlas.EMBER, 8).vel(randomDir().scale(0.02)).size(0.04F, 0.0F, 1.0F).color(0xFFFFFF, 0xFFB800)
                                .alpha(0.9F, 0.0F).spawn();
                    }
                }
                case Orb.ACID -> {
                    if (r.nextFloat() < 0.5F) {
                        p(pos, FxAtlas.EMBER, 10).vel(new Vec3(0, -0.02, 0)).gravity(0.01).size(0.035F, 0.015F, 1.0F).color(0xE0FF90, 0x8CFF10)
                                .alpha(0.9F, 0.0F).spawn();
                    }
                }
                case Orb.CRYSTAL -> {
                    if (r.nextFloat() < 0.6F) {
                        p(pos.add(randomDir().scale(0.15)), FxAtlas.GLINT, 8).vel(back.scale(0.04)).size(0.07F, 0.0F, 1.0F).color(0xF0E0FF, 0xC07CFF)
                                .roll(r.nextFloat() * 6.28F, 0.1F).alpha(1.0F, 0.0F).spawn();
                    }
                }
                default -> {}
            }
        } else if (e instanceof Sticky s) {
            if (s.isStuck()) {
                if (s.kind() == Sticky.HARPOON) {
                    if (r.nextFloat() < 0.5F) sparks(pos, UP, 180.0, 1, 0xA8F0FF, 0.12F, 0.03F, 5, 0.02);
                    if (s.stuckTicks() % 5 == 0) ring(pos, randomDir(), FxAtlas.RING, 0x39D6FF, 0.1F, 0.6F, 5, 0.7F);
                }
            } else if (s.kind() == Sticky.HARPOON) {
                if (r.nextFloat() < 0.4F) smoke(pos.add(back.scale(0.6)), 1, 0.06F, 14, 0xE0F0F4, Vec3.ZERO, 0.02F);
            } else if (r.nextFloat() < 0.3F) {
                smoke(pos, 1, 0.06F, 14, 0x8A8480, Vec3.ZERO, 0.02F);
            }
        } else if (e instanceof Piercer pc) {
            if (pc.kind() == Piercer.RING) {
                Vec3 h = pc.heading();
                Vec3 u = h.cross(UP);
                u = u.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : u.normalize();
                Vec3 v = u.cross(h).normalize();
                for (int i = 0; i < 2; i++) {
                    double ang = r.nextDouble() * Math.PI * 2.0;
                    Vec3 at = pos.add(u.scale(Math.cos(ang) * Piercer.RING_RADIUS)).add(v.scale(Math.sin(ang) * Piercer.RING_RADIUS));
                    p(at, FxAtlas.EMBER, 10 + r.nextInt(8)).vel(back.scale(0.03).add(0, 0.01, 0)).size(0.045F, 0.0F, 1.0F).color(0xD8FFE8, 0x3CFF9E)
                            .alpha(1.0F, 0.0F).spawn();
                }
                if (r.nextFloat() < 0.3F) ash(pos, 1, 0.8F);
            } else if (r.nextFloat() < 0.6F) {
                p(pos.add(back.scale(0.3)), FxAtlas.GLINT, 6).size(0.07F, 0.0F, 1.0F).color(0xFFF4C8).roll(r.nextFloat() * 6.28F, 0.0F).alpha(1.0F, 0.0F).spawn();
            }
        } else if (e instanceof SlashWave) {
            if (r.nextFloat() < 0.6F) {
                p(pos.add(randomDir().scale(0.6)), FxAtlas.GLINT, 8).vel(back.scale(0.04)).size(0.1F, 0.0F, 1.0F).color(0xFFE0F0, 0xFF2E7E)
                        .roll(r.nextFloat() * 6.28F, 0.0F).alpha(1.0F, 0.0F).spawn();
            }
        }
    }

    /** Partículas de ambiente de las zonas (cada tick en el cliente). */
    public static void fieldTick(Field f) {
        if (level() == null) return;
        RandomSource r = rnd();
        Vec3 pos = f.position();
        switch (f.type()) {
            case Field.ACID_POOL -> {
                float rad = f.size();
                if (r.nextFloat() < 0.7F) {
                    double a = r.nextDouble() * Math.PI * 2.0;
                    double d = Math.sqrt(r.nextDouble()) * rad;
                    p(pos.add(Math.cos(a) * d, 0.05, Math.sin(a) * d), FxAtlas.BUBBLE, 10 + r.nextInt(10)).vel(new Vec3(0, 0.01, 0))
                            .size(0.03F, 0.09F, 1.0F).color(0xD8FF80).alpha(0.9F, 0.0F).spawn();
                }
                if (r.nextFloat() < 0.15F) {
                    smoke(pos.add((r.nextFloat() - 0.5) * rad, 0.1, (r.nextFloat() - 0.5) * rad), 1, 0.2F, 30, 0x9ACC40, new Vec3(0, 0.02, 0), 0.1F);
                }
            }
            case Field.STORM -> {
                for (int i = 0; i < 2; i++) {
                    Vec3 at = pos.add((r.nextFloat() - 0.5) * 6.0, -0.8, (r.nextFloat() - 0.5) * 6.0);
                    p(at, FxAtlas.SPARK, 14).mode(Mode.VELOCITY).vel(new Vec3(0, -0.6, 0)).size(0.02F, 0.015F, 1.0F).aspect(3.0F).stretch(1.5F)
                            .color(0xA8B8D8).alpha(0.5F, 0.3F).spawn();
                }
            }
            case Field.TORNADO -> {
                for (int i = 0; i < 2; i++) {
                    double a = r.nextDouble() * Math.PI * 2.0;
                    double h = r.nextDouble() * 4.5;
                    double rad = 0.6 + h * 0.35;
                    Vec3 at = pos.add(Math.cos(a) * rad, h, Math.sin(a) * rad);
                    Vec3 tangent = new Vec3(-Math.sin(a), 0.12, Math.cos(a)).scale(0.35);
                    p(at, FxAtlas.SMOKE[r.nextInt(FxAtlas.SMOKE.length)], 16 + r.nextInt(10)).soft().vel(tangent).drag(0.92).size(0.25F, 0.6F, 0.6F)
                            .color(0xB8C8C0).alpha(0.45F, 0.0F).roll(r.nextFloat() * 6.28F, 0.05F).spawn();
                }
                if (r.nextFloat() < 0.6F) {
                    double a = r.nextDouble() * Math.PI * 2.0;
                    double rad = 1.0 + r.nextDouble() * 1.2;
                    p(pos.add(Math.cos(a) * rad, r.nextDouble() * 3.0, Math.sin(a) * rad), FxAtlas.DEBRIS, 20).soft()
                            .vel(new Vec3(-Math.sin(a) * 0.4, 0.08, Math.cos(a) * 0.4)).drag(0.95).size(0.06F).color(0x4A4038)
                            .roll(r.nextFloat() * 6.28F, 0.4F).alpha(1.0F, 0.5F).spawn();
                }
                if (r.nextFloat() < 0.5F) {
                    double a = r.nextDouble() * Math.PI * 2.0;
                    Vec3 at = pos.add(Math.cos(a) * 2.0, 0.5 + r.nextDouble() * 3.5, Math.sin(a) * 2.0);
                    p(at, FxAtlas.SPARK, 8).mode(Mode.VELOCITY).vel(new Vec3(-Math.sin(a) * 0.5, 0.05, Math.cos(a) * 0.5)).drag(0.9)
                            .size(0.03F, 0.01F, 1.0F).aspect(3.0F).stretch(1.6F).color(0xE8FFFA, 0x7FE8D8).alpha(0.7F, 0.0F).spawn();
                }
            }
            default -> {
                if (r.nextFloat() < 0.5F) {
                    p(pos.add(randomDir().scale(0.8)), FxAtlas.EMBER, 8).vel(randomDir().scale(0.03)).size(0.04F, 0.0F, 1.0F).color(0xFFFFFF, 0xFFB800)
                            .alpha(0.8F, 0.0F).spawn();
                }
            }
        }
    }

    public static void droneTick(Drone drone) {
        if (level() == null || drone.tickCount % 2 != 0) return;
        Vec3 pos = drone.position();
        for (int i = 0; i < 2; i++) {
            Vec3 at = pos.add((rnd().nextFloat() - 0.5) * 0.5, -0.1, (rnd().nextFloat() - 0.5) * 0.5);
            p(at, FxAtlas.EMBER, 6).vel(new Vec3(0, -0.06, 0)).size(0.05F, 0.0F, 1.0F).color(0xFFFFFF, 0xFFA235).alpha(0.8F, 0.0F).spawn();
        }
    }
}
