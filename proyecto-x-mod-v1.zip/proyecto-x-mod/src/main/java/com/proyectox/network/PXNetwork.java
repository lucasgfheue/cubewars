package com.proyectox.network;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Red: un único paquete (gatillo) y el estado del gatillo de cada jugador en el servidor. */
public final class PXNetwork {
    private PXNetwork() {}

    /** Último tick en que cada jugador confirmó el gatillo pulsado. */
    private static final Map<UUID, Long> TRIGGER = new ConcurrentHashMap<>();

    public static void register(RegisterPayloadHandlersEvent event) {
        event.registrar("1").playToServer(TriggerPayload.TYPE, TriggerPayload.CODEC, PXNetwork::onTrigger);
    }

    private static void onTrigger(TriggerPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            Player player = context.player();
            if (payload.down()) {
                TRIGGER.put(player.getUUID(), player.level().getGameTime());
            } else {
                TRIGGER.remove(player.getUUID());
            }
        });
    }

    /** El cliente reenvía el estado cada 2 ticks; si deja de llegar, el gatillo se considera suelto. */
    public static boolean triggerHeld(Player player, long now) {
        Long last = TRIGGER.get(player.getUUID());
        return last != null && now - last <= 4L;
    }

    public static void forget(Player player) {
        TRIGGER.remove(player.getUUID());
    }
}
