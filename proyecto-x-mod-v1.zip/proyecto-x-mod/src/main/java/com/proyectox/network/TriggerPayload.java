package com.proyectox.network;

import com.proyectox.ProyectoX;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** El cliente avisa de que mantiene (o suelta) el gatillo de un arma automática. */
public record TriggerPayload(boolean down) implements CustomPacketPayload {
    public static final Type<TriggerPayload> TYPE = new Type<>(ProyectoX.id("gatillo"));
    public static final StreamCodec<ByteBuf, TriggerPayload> CODEC = ByteBufCodecs.BOOL.map(TriggerPayload::new, TriggerPayload::down);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
