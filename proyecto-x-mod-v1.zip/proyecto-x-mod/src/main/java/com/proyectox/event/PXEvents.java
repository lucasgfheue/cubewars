package com.proyectox.event;

import com.proyectox.ProyectoX;
import com.proyectox.item.BastionItem;
import com.proyectox.item.ColmenaItem;
import com.proyectox.item.PXWeapon;
import com.proyectox.item.RotorItem;
import com.proyectox.item.TaladroItem;
import com.proyectox.network.PXNetwork;
import com.proyectox.util.FallGuard;
import com.proyectox.util.Scheduler;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.entity.living.LivingShieldBlockEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/** Eventos del juego (bus principal de NeoForge). */
@EventBusSubscriber(modid = ProyectoX.MODID)
public final class PXEvents {
    private PXEvents() {}

    /** Ancla, retroceso y embestida: sin daño por caída durante unos segundos. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (FallGuard.active(event.getEntity())) {
            event.setDamageMultiplier(0.0F);
            event.setDistance(0.0F);
        }
    }

    /** BASTIÓN: la energía de cada golpe bloqueado se almacena en el acumulador cinético. */
    @SubscribeEvent
    public static void onShieldBlock(LivingShieldBlockEvent event) {
        LivingEntity holder = event.getEntity();
        if (!event.getBlocked() || holder.level().isClientSide) return;
        ItemStack using = holder.getUseItem();
        if (using.getItem() instanceof BastionItem bastion) bastion.absorb(using, holder, event.getBlockedDamage());
    }

    /** Con un arma de fuego en la mano, el clic derecho dispara: no abre comercios ni monta animales. */
    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getItemStack().getItem() instanceof PXWeapon weapon && weapon.guardsInteractions()) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.FAIL);
        }
    }

    @SubscribeEvent
    public static void onInteractSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        if (event.getItemStack().getItem() instanceof PXWeapon weapon && weapon.guardsInteractions()) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.FAIL);
        }
    }

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent.Post event) {
        if (event.getLevel() instanceof ServerLevel level) Scheduler.tick(level);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        Scheduler.clear();
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        Player player = event.getEntity();
        PXNetwork.forget(player);
        ColmenaItem.forget(player);
        RotorItem.forget(player);
        TaladroItem.forget(player);
        FallGuard.forget(player);
    }
}
