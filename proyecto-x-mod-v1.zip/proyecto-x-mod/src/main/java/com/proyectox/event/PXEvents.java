package com.proyectox.event;

import com.proyectox.ProyectoX;
import com.proyectox.item.ColmenaItem;
import com.proyectox.item.PXWeapon;
import com.proyectox.item.VorticeItem;
import com.proyectox.network.PXNetwork;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingFallEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/** Eventos del juego (bus principal de NeoForge). */
@EventBusSubscriber(modid = ProyectoX.MODID)
public final class PXEvents {
    private PXEvents() {}

    /** Ancla gravitacional del VÓRTICE: sin daño por caída durante 3 s. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof Player player && VorticeItem.fallProtected(player)) {
            event.setDamageMultiplier(0.0F);
            event.setDistance(0.0F);
        }
    }

    /** Con un arma de fuego en la mano, el clic derecho dispara: no abre comercios ni monta animales. */
    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getItemStack().getItem() instanceof PXWeapon weapon && weapon.guardsInteractions()) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.FAIL);
        }
    }

    @SubscribeEvent
    public static void onInteractSpecific(PlayerInteractEvent.EntityInteractSpecific event) {
        if (event.getItemStack().getItem() instanceof PXWeapon weapon && weapon.guardsInteractions()) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.FAIL);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        Player player = event.getEntity();
        PXNetwork.forget(player);
        ColmenaItem.forget(player);
        VorticeItem.forget(player);
    }
}
