# Proyecto X — Arsenal experimental (NeoForge 1.21.1)

> *Año 2187. Tras el apagón de la red orbital, el Directorio Ferrum reconvirtió sus fundiciones
> y activó el Proyecto X: veinte prototipos que no dependen de munición, porque cada uno se
> alimenta de su propio núcleo de xeranio.*

Mod de armas futuristas para **Minecraft 1.21.1 + NeoForge 21.1**. Veinte armas con modelo 3D
poligonal (OBJ) y textura de 1024 × 1024, efectos visuales propios en alta resolución, su propio
sistema de energía (ninguna usa munición), sonidos, mensajes de muerte y recetas de fabricación.

## Versión 3.0

- **Controles de shooter**: el **clic izquierdo dispara** y el **clic derecho apunta** (el arma sube al
  centro de la vista, la cámara hace zoom, la dispersión se reduce y el ratón se vuelve más fino;
  la AGUJA mira por un visor de francotirador). El BASTIÓN usa el clic derecho para cubrirse y la
  SERPENTINA y la CIZALLA para su cuerda y su tajo.
- **Armas más grandes en la mano**, en primera y en tercera persona.
- **Efectos visuales nuevos en alta resolución** (atlas de 2048 px con filtrado suave): fogonazos
  pegados a la boca del cañón, retroceso, haces de riel con hélice, rayos eléctricos ramificados,
  láser que pasa de celeste a rojo, llamas de plasma animadas, explosiones con bolas de fuego, onda
  de choque, escombros y humo, vórtices, ondas sónicas, discos de sierra girando, estelas de cada
  proyectil, marcas de fijación y una retícula holográfica distinta para cada arma con marcador de
  aciertos.
- **Sin habilidades secundarias ni debilidades**: cada arma dispara su proyectil, hace mucho más
  daño, llega más lejos, no ralentiza, no se bloquea y tiene mucha más energía con recarga rápida.
- **Ninguna arma empuja a las entidades** (sin retroceso de golpes, balas ni explosiones).
- Las armas tampoco golpean cuerpo a cuerpo ni rompen bloques sin querer, y los endermans ya no
  esquivan sus disparos.

## Armas

| Código | Arma | Clase | Cómo dispara | Energía |
|---|---|---|---|---|
| PX-01 | **MARTINETE** | Mazo de ruptura hidráulico | Clic izquierdo: golpe de 32 de daño (0,9 golpes por segundo). No empuja al enemigo: puedes seguir golpeándolo. | No gasta energía. |
| PX-02 | **AGUJA** | Fusil de riel de precisión | Mantén clic izquierdo para cargar (1,5 s) y suelta: rayo celeste de 256 bloques que atraviesa paredes y a todos los enemigos. 15 de daño sin cargar, 30 con la carga completa. Clic derecho: apuntar con visor. Espera de 0,8 s entre disparos. | Batería de xeranio: 12 disparos; se recarga 1 cada 0,75 s. |
| PX-03 | **AVISPÓN** | Carabina de pulsos de plasma | Mantén clic izquierdo: fuego automático (10 pulsos por segundo). Cada pulso hace de 8 a 12 de daño: cuanto más rato disparas, más se calienta y más daño hace. Con más de la mitad de calor los pulsos incendian al enemigo. Nunca se bloquea. Clic derecho: apuntar. | Cámara de plasma: 200 pulsos; se rellena en 10 s sin disparar. |
| PX-04 | **COLMENA** | Lanzador de microcohetes | Mantén clic izquierdo para fijar hasta 6 objetivos cerca de la mira y suelta: salva de microcohetes dirigibles (20 de daño cada uno). Los cohetes sin objetivo siguen el punto al que apuntas. Espera de 1,2 s entre salvas. Clic derecho: apuntar. | Nanofábrica: 36 microcohetes; ensambla 1 cada 0,2 s sin disparar. |
| PX-05 | **VÓRTICE** | Proyector gravitacional | Clic izquierdo: singularidad que vuela hasta 260 bloques. Al tocar a una criatura estalla (20 de daño en radio 4). Contra un bloque abre un vórtice de 2 s que atrae a las criaturas y después colapsa (20 de daño). Nunca te atrae a ti. Clic derecho: apuntar. | Núcleo en suspensión: 10 singularidades; 1 cada segundo. |
| PX-06 | **CIZALLA** | Hoja de vibroenergía | Clic izquierdo: estocada de 22 de daño (1,8 golpes por segundo), sin empujar. Clic derecho: tajo de media luna que atraviesa a todos los enemigos que encuentra (26 de daño). | Celda de filo: 10 tajos; 1 cada 0,5 s. |
| PX-07 | **TALADRO** | Perforadora de asedio | Mantén clic izquierdo sobre una criatura: la broca gira y la perfora. Cuanto más tiempo, más daño: 3 → 10 (a 1,5 s) → 50 (a 3 s), cinco veces por segundo. Sobre los bloques excava como un pico y una pala de netherita a la vez (+1 bloque de alcance). | Motor de fusión: no gasta energía. |
| PX-08 | **SERPENTINA** | Látigo de cadena electrificada | Clic izquierdo: latigazo de 6 de daño con 3 bloques más de alcance. Clic derecho: cuerda azul de 24 bloques que atrapa al enemigo y lo arrastra hasta ti; tu primer golpe después hace 18 de daño. | Bobina superconductora: la cuerda se recarga en 0,8 s. |
| PX-09 | **CHISPA** | Pistola de arco eléctrico | Mantén clic izquierdo: rayos eléctricos continuos (40 bloques) que electrocutan al enemigo de la mira y saltan a 3 enemigos cercanos. 7 de daño a cada uno, cinco veces por segundo. Clic derecho: apuntar. | Condensador: 300 cargas (30 s de rayos); se recarga en 15 s. |
| PX-10 | **REMACHE** | Escopeta de remaches magnéticos | Clic izquierdo: 9 remaches de 10 de daño que llegan a 96 bloques sin perder fuerza. Clic derecho: apuntar (la dispersión se reduce a la mitad). | Tambor magnético: 24 disparos; 1 cada 0,5 s. |
| PX-11 | **TRITURADORA** | Lanzagranadas de racimo | Clic izquierdo: granada que rebota 2 veces y estalla (30 de daño en radio 4) soltando 4 bombetas de 10 de daño. No te daña ni empuja a nadie. Clic derecho: apuntar. | Forja de granadas: 12 granadas; 1 cada 0,8 s. |
| PX-12 | **ROTOR** | Ametralladora rotativa de energía | Mantén clic izquierdo: 20 trazadoras por segundo de 7 de daño, sin tiempo de arranque y sin frenarte. Clic derecho: apuntar (más precisión). | Cinta de energía: 500 disparos; se recarga 20 por segundo sin disparar. |
| PX-13 | **HALCÓN** | Lanzador de drones de combate | Clic izquierdo: despliega un dron de combate que caza enemigos en 32 bloques durante 40 s (12 de daño por pulso). Hasta 3 drones a la vez; uno nuevo releva al más antiguo. Clic derecho: apuntar. | Hangar: 3 drones; 1 cada 5 s. |
| PX-14 | **TRUENO** | Cañón láser térmico | Mantén clic izquierdo: láser continuo de 64 bloques que atraviesa a 3 criaturas. Empieza celeste: 10 de daño, cinco veces por segundo. Cuanto más tiempo sigue encendido más se calienta: a los 3 s es rojo y hace 50. Clic derecho: apuntar. | Celda láser: 400 cargas (20 s de láser); se recarga en 20 s. |
| PX-15 | **SOPLETE** | Lanzallamas de plasma | Mantén clic izquierdo: chorro de plasma de 20 bloques que hace 3 de daño diez veces por segundo y deja ardiendo 6 s. Quema también a las criaturas inmunes al fuego. Clic derecho: apuntar. | Tanque de gel: 300 unidades (15 s de chorro); se rellena en 15 s. |
| PX-16 | **ESCARCHA** | Proyector criogénico automático | Mantén clic izquierdo: ráfaga automática de pequeños láseres de hielo (10 por segundo, 4 de daño). Cada impacto ralentiza un poco más al enemigo hasta dejarlo inmóvil. Clic derecho: apuntar. | Criotanque: 300 láseres; se rellena en 15 s. |
| PX-17 | **ECO** | Cañón sónico | Clic izquierdo: onda expansiva que avanza 64 bloques atravesando paredes y criaturas mientras se ensancha. Hace 10 de daño en área (ignora la armadura) a todo lo que alcanza. Clic derecho: apuntar. | Resonador: 12 ondas; 1 cada 0,6 s. |
| PX-18 | **BASTIÓN** | Escudo de energía de asalto | Mantén clic derecho para cubrirte: bloquea el daño venga de donde venga (también por los flancos y la espalda). Clic izquierdo: balas cinéticas de 8 de daño (5 por segundo), también mientras te cubres. | Proyector de campo: 120 balas; se recarga en 12 s. |
| PX-19 | **COLIBRÍ** | Subfusil de agujas | Mantén clic izquierdo: 20 agujas de cristal por segundo de 4,5 de daño. Clic derecho: apuntar (más precisión). | Cargador de agujas: 240 agujas; se regenera 20 por segundo sin disparar. |
| PX-20 | **SIERRA** | Lanzadiscos de sierra | Clic izquierdo: disco de sierra de 22 de daño que atraviesa a todos los enemigos y rebota hasta 4 veces. Nunca te corta a ti. Clic derecho: apuntar. | Forja de discos: 20 discos; 1 cada 0,5 s. |

En el juego: pasa el ratón por encima del arma y mantén **Mayús** para ver los detalles.

## Fabricación

Todas las armas necesitan un **Núcleo de xeranio**. Recetas de mesa de trabajo (3 × 3, `·` = hueco):

| Objeto | Patrón | Ingredientes |
|---|---|---|
| Núcleo de xeranio | `ARA` / `RDR` / `ARA` | A fragmento de amatista · R redstone · D diamante |
| MARTINETE | `BPB` / `·X·` / `·N·` | B bloque de hierro · P pistón · X núcleo · N lingote de netherita |
| AGUJA | `SLL` / `CXC` / `IN·` | S catalejo · L pararrayos · C lingote de cobre · X núcleo · I lingote de hierro · N lingote de netherita |
| AVISPÓN | `FBF` / `IXI` / `·IR` | F carga ígnea · B vara de blaze · I lingote de hierro · X núcleo · R bloque de redstone |
| COLMENA | `RRR` / `DXD` / `IOI` | R cohete de fuegos artificiales · D dispensador · X núcleo · I bloque de hierro · O observador |
| VÓRTICE | `PEP` / `CXC` / `OIO` | P perla de ender · E ojo de ender · C obsidiana llorosa · X núcleo · O obsidiana · I lingote de hierro |
| CIZALLA | `·N·` / `·N·` / `IXI` | N lingote de netherita · I lingote de hierro · X núcleo |
| TALADRO | `·D·` / `DPD` / `IXI` | D diamante · P pistón · I bloque de hierro · X núcleo |
| SERPENTINA | `··C` / `·C·` / `XL·` | C cadena · X núcleo · L pararrayos |
| CHISPA | `CLC` / `·XI` / `··I` | C lingote de cobre · L pararrayos · X núcleo · I lingote de hierro |
| REMACHE | `III` / `CXC` / `·IB` | I lingote de hierro · C bloque de cobre · X núcleo · B bloque de hierro |
| TRITURADORA | `ITI` / `TXT` / `ITI` | I bloque de hierro · T dinamita · X núcleo |
| ROTOR | `III` / `LXR` / `III` | I lingote de hierro · L pararrayos · R bloque de redstone · X núcleo |
| HALCÓN | `P·P` / `IXI` / `P·P` | P membrana de phantom · I lingote de hierro · X núcleo |
| TRUENO | `·S·` / `LXL` / `IRI` | S catalejo · L pararrayos · X núcleo · I lingote de hierro · R bloque de redstone |
| SOPLETE | `FFF` / `BXB` / `·I·` | F carga ígnea · B vara de blaze · X núcleo · I lingote de hierro |
| ESCARCHA | `BBB` / `IXI` / `·I·` | B hielo azul · I lingote de hierro · X núcleo |
| ECO | `NIN` / `IXI` / `N·N` | N bloque musical · I lingote de hierro · X núcleo |
| BASTIÓN | `OIO` / `IXI` / `OIO` | O obsidiana · I lingote de hierro · X núcleo |
| COLIBRÍ | `··A` / `IXA` / `·I·` | A fragmento de amatista · I lingote de hierro · X núcleo |
| SIERRA | `·S·` / `IXI` / `·I·` | S cortapiedras · I lingote de hierro · X núcleo |

También aparecen en la pestaña creativa **Proyecto X · Arsenal**.

## Compilar en GitHub (sin instalar nada)

1. Crea un repositorio nuevo en GitHub (puede ser privado), o usa el de la versión anterior.
2. Sube **todo el contenido de esta carpeta**, incluidas las carpetas ocultas `.github` y `gradle`.
   Si actualizas el repositorio de la v2, **borra antes la carpeta `src`** del repositorio (esta versión
   elimina y renombra archivos) y sube la nueva.
   - Con Git: `git init && git add . && git commit -m "Proyecto X" && git branch -M main && git remote add origin <url> && git push -u origin main`
   - Desde la web: *Add file → Upload files* y arrastra los archivos y carpetas (comprueba que se suben `.github/workflows/build.yml` y `gradle/wrapper/gradle-wrapper.jar`).
3. Al subirlo se ejecuta solo el flujo **Compilar Proyecto X** (pestaña *Actions*). Si no arranca, entra en *Actions → Compilar Proyecto X → Run workflow*.
4. Cuando termine (la primera vez tarda unos minutos porque NeoForge prepara Minecraft), abre la ejecución y descarga el artefacto **proyectox-mod**: dentro está `proyectox-3.0.0.jar`.
5. Copia el `.jar` en la carpeta `mods` de una instalación de **NeoForge 21.1.x para Minecraft 1.21.1**.

## Compilar en tu ordenador

Necesitas **Java 21** (JDK). En la carpeta del proyecto:

```
./gradlew build          # Windows: gradlew.bat build
./gradlew runClient      # abre Minecraft con el mod para probarlo
```

El `.jar` queda en `build/libs/`.

## Estructura

```
src/main/java/com/proyectox/
  ProyectoX.java          clase principal (@Mod)
  item/                   las 20 armas: GunItem (armas de fuego), MeleeItem (cuerpo a cuerpo), PXWeapon (energía)
  entity/                 proyectiles, granadas, discos, dron, singularidad, onda sónica
  fx/                     avisos de efectos que el servidor envía a los clientes
  client/                 apuntado, retroceso, retícula, controles y renderizadores
  client/fx/              motor de efectos: partículas aditivas, haces, rayos, anillos y aspecto de cada proyectil
  network/                paquetes de controles (cliente → servidor) y de efectos (servidor → cliente)
  registry/               objetos, entidades, sonidos, componentes, tipos de daño, pestaña
  util/                   puntería, daño sin empuje, efectos de sonido, tareas diferidas
src/main/resources/
  assets/proyectox/models/item/   modelos OBJ + MTL + JSON (cargador neoforge:obj)
  assets/proyectox/textures/item/ texturas 1024 px de las armas
  assets/proyectox/textures/fx/   atlas de efectos 2048 px (filtrado lineal)
  assets/proyectox/sounds.json    sonidos (compuestos a partir de sonidos de Minecraft)
  assets/proyectox/lang/          español (es_*) e inglés (en_us)
  data/proyectox/                 recetas y tipos de daño
```

Notas:
- Los sonidos están definidos en `sounds.json` reutilizando sonidos de Minecraft con otro tono;
  puedes sustituirlos por archivos `.ogg` propios sin tocar el código.
- Las texturas de las armas son de 1024 × 1024 px: el atlas de bloques crece bastante (≈ 8192 × 4096).
  Cualquier gráfica de los últimos años lo admite sin problemas.
- Versión de NeoForge, nombre, autor, licencia y versión del mod se cambian en `gradle.properties`.
