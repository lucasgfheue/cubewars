# Proyecto X — Arsenal experimental (NeoForge 1.21.1)

> *Año 2187. Tras el apagón de la red orbital, el Directorio Ferrum reconvirtió sus fundiciones
> y activó el Proyecto X: prototipos que no dependen de munición, porque cada uno se alimenta de
> su propio núcleo de xeranio.*

Mod de armas futuristas para **Minecraft 1.21.1 + NeoForge 21.1**. Cada arma tiene un modelo 3D
poligonal (OBJ) con textura de 1024 × 1024, su propio sistema de energía (sin munición),
habilidades únicas, sonidos, partículas y mensajes de muerte propios.

## Armas

| Código | Arma | Clase | Controles | Energía |
|---|---|---|---|---|
| PX-01 | **MARTINETE** | Mazo de ruptura hidráulico | Golpear carga presión. Con 2+ cargas: mantener clic derecho 1 s y soltar → *Golpe de ruptura* (18 de daño en radio 3,5; derriba y anula escudos 5 s; radio +50 % con 4 cargas). | Acumulador de presión (máx. 4) |
| PX-02 | **AGUJA** | Fusil de riel de precisión | Mantener clic derecho para cargar 1,5 s (con zoom) y soltar. 6–26 de daño, 120 bloques; al 100 % atraviesa 3 enemigos. Los impactos marcan 8 s (Resplandor). | Batería: 5 disparos, 1 cada 3 s |
| PX-03 | **AVISPÓN** | Carabina de pulsos de plasma | Mantener clic derecho: fuego automático (10/s) sin frenarte. >60 % de calor incendia; al 100 % se bloquea 3 s. Agachado + clic derecho: *Purga de calor* en cono. | Cámara: 40 pulsos, se rellena en 6 s |
| PX-04 | **COLMENA** | Lanzador de microcohetes | Mantener clic derecho para fijar hasta 6 objetivos (1 cada 1,2 s); soltar para lanzar la salva. Los cohetes buscan su blanco y priorizan a los marcados. | Nanofábrica: 1 cohete cada 2 s (máx. 6) |
| PX-05 | **VÓRTICE** | Proyector gravitacional | Clic derecho: singularidad que abre un vórtice de 3 s y colapsa (8 de daño + levitación). Agachado + clic derecho a un bloque (32 m): *Ancla gravitacional*. | 3 singularidades, 1 cada 8 s |

Detalles en el juego: pasa el ratón por encima del arma y mantén **Mayús**.

**Sinergias:** AGUJA marca objetivos → COLMENA los prioriza. VÓRTICE agrupa enemigos →
MARTINETE y COLMENA los rematan.

## Fabricación

Todas las armas necesitan un **Núcleo de xeranio**. Recetas de mesa de trabajo (3 × 3, `·` = hueco):

| Objeto | Patrón | Ingredientes |
|---|---|---|
| Núcleo de xeranio | `ARA` / `RDR` / `ARA` | A fragmento de amatista · R redstone · D diamante |
| MARTINETE | `BPB` / `·X·` / `·N·` | B bloque de hierro · P pistón · X núcleo · N lingote de netherita |
| AGUJA | `SLL` / `CXC` / `IN·` | S catalejo · L pararrayos · C lingote de cobre · X núcleo · I lingote de hierro · N lingote de netherita |
| AVISPÓN | `FBF` / `IXI` / `·IR` | F carga ígnea · B vara de blaze · I lingote de hierro · X núcleo · R bloque de redstone |
| COLMENA | `RRR` / `DXD` / `IOI` | R cohete de fuegos artificiales · D dispensador · X núcleo · I bloque de hierro · O observador |
| VÓRTICE | `PEP` / `CXC` / `OIO` | P perla de ender · E ojo de ender · C obsidiana llorosa · X núcleo · O obsidiana · I lingote de hierro |

También aparecen en la pestaña creativa **Proyecto X · Arsenal**.

## Compilar en GitHub (sin instalar nada)

1. Crea un repositorio nuevo en GitHub (puede ser privado).
2. Sube **todo el contenido de esta carpeta**, incluidas las carpetas ocultas `.github` y `gradle`:
   - Con Git: `git init && git add . && git commit -m "Proyecto X" && git branch -M main && git remote add origin <url> && git push -u origin main`
   - Desde la web: *Add file → Upload files* y arrastra los archivos y carpetas (comprueba que se suben `.github/workflows/build.yml` y `gradle/wrapper/gradle-wrapper.jar`).
3. Al subirlo se ejecuta solo el flujo **Compilar Proyecto X** (pestaña *Actions*). Si no arranca, entra en *Actions → Compilar Proyecto X → Run workflow*.
4. Cuando termine (la primera vez tarda unos minutos porque NeoForge prepara Minecraft), abre la ejecución y descarga el artefacto **proyectox-mod**: dentro está `proyectox-1.0.0.jar`.
5. Copia el `.jar` en la carpeta `mods` de una instalación de **NeoForge 21.1.x para Minecraft 1.21.1**.

## Compilar en tu ordenador

Necesitas **Java 21** (JDK). En la carpeta del proyecto:

```
./gradlew build          # Windows: gradlew.bat build
./gradlew runClient      # abre Minecraft con el mod para probarlo
```

El `.jar` queda en `build/libs/`.

## Estructura

```
src/main/java/com/proyectox/
  ProyectoX.java          clase principal (@Mod)
  item/                   las armas (PXWeapon es la base con el sistema de energía)
  entity/                 pulsos de plasma, microcohetes, singularidad, estela del riel
  client/                 renderizadores, poses de brazos, gatillo automático, zoom
  network/                paquete del gatillo automático
  registry/               objetos, entidades, sonidos, componentes, tipos de daño, pestaña
src/main/resources/
  assets/proyectox/models/item/   modelos OBJ + MTL + JSON (cargador neoforge:obj)
  assets/proyectox/textures/      texturas 1024 px de las armas y de los efectos
  assets/proyectox/sounds.json    sonidos (compuestos a partir de sonidos de Minecraft)
  assets/proyectox/lang/          español (es_*) e inglés (en_us)
  data/proyectox/                 recetas y tipos de daño
```

Los sonidos están definidos en `sounds.json` reutilizando sonidos de Minecraft con otro tono;
puedes sustituirlos por archivos `.ogg` propios sin tocar el código.

Las características y parámetros (versión de NeoForge, nombre, autor, licencia) se cambian en
`gradle.properties`.
