# Proyecto X — Arsenal experimental (NeoForge 1.21.1)

> *Año 2187. Tras el apagón de la red orbital, el Directorio Ferrum reconvirtió sus fundiciones
> y activó el Proyecto X: veinte prototipos que no dependen de munición, porque cada uno se
> alimenta de su propio núcleo de xeranio.*

Mod de armas futuristas para **Minecraft 1.21.1 + NeoForge 21.1**. Veinte armas con modelo 3D
poligonal (OBJ) y textura de 1024 × 1024, su propio sistema de energía (ninguna usa munición),
habilidades únicas, sonidos, partículas, mensajes de muerte y recetas de fabricación.

## Armas

| Código | Arma | Clase | Controles | Energía |
|---|---|---|---|---|
| PX-01 | **MARTINETE** | Mazo de ruptura hidráulico · Cuerpo a cuerpo | Cada golpe que conecta suma 1 carga de presión (máx. 4). Con 2+ cargas: mantén clic derecho 1 s y suelta → Golpe de ruptura (18 de daño, derriba, anula escudos 5 s; radio +50 % con 4 cargas). | Acumulador de presión: se carga golpeando. No necesita munición. |
| PX-02 | **AGUJA** | Fusil de riel de precisión · Precisión | Mantén clic derecho para cargar (1,5 s) y suelta: 6–26 de daño, 120 bloques. Al 100 % atraviesa 3 enemigos. Cada impacto marca al objetivo 8 s (visible a través de paredes). COLMENA prioriza a los marcados. | Batería de xeranio de 5 disparos que se recarga sola (1 disparo cada 3 s). |
| PX-03 | **AVISPÓN** | Carabina de pulsos de plasma · Automática | Mantén clic derecho: fuego automático (10 pulsos/s) sin frenarte. Por encima del 60 % de calor incendia; al 100 % se bloquea 3 s. Agachado + clic derecho: Purga de calor en cono de 5 bloques; el daño crece con el calor y reinicia el medidor. | Cámara de plasma regenerativa: 40 pulsos que se recuperan en 6 s sin disparar. |
| PX-04 | **COLMENA** | Lanzador de microcohetes · Pesada · Explosiva | Mantén clic derecho para fijar hasta 6 objetivos (1 cada 1,2 s); suelta para lanzar la salva. Cohetes buscadores: 9 de daño + explosión. Priorizan objetivos con Resplandor. No arman a menos de 4 bloques. | Nanofábrica interna: ensambla 1 microcohete cada 2 s (salva completa en 12 s). |
| PX-05 | **VÓRTICE** | Proyector gravitacional · Táctica · Especial | Clic derecho: singularidad lenta que abre un vórtice de 3 s (atrae en radio 6) y colapsa (8 de daño, levitación). Agachado + clic derecho a un bloque (32 m): el ancla te lanza hacia él y anula el daño por caída 3 s. Recarga 6 s. | Núcleo de xeranio en suspensión: 3 singularidades que se regeneran (1 cada 8 s). |
| PX-06 | **CIZALLA** | Hoja de vibroenergía · Cuerpo a cuerpo · Espada | Clic derecho: tajo de media luna que atraviesa a todos los enemigos en 16 bloques (8 de daño). Cada tercer golpe seguido (en menos de 2 s) suma 4 de daño que ignora la armadura. | Celda de filo: 4 tajos de energía, 1 cada 4 s. |
| PX-07 | **TALADRO** | Perforadora de asedio · Cuerpo a cuerpo · Herramienta | Excava como un pico y una pala de netherita a la vez. Mantén clic derecho 0,75 s y suelta: embestida de 8 bloques (9 de daño y empuje; sin daño por caída). | Batería de par: 3 embestidas, 1 cada 5 s. |
| PX-08 | **SERPENTINA** | Látigo de cadena electrificada · Cuerpo a cuerpo · Alcance medio | +2 bloques de alcance; cada golpe salta en arco a 2 enemigos cercanos (3 de daño). Clic derecho: el látigo atrapa al primer enemigo a 12 bloques, lo arrastra hacia ti y lo frena 1,5 s. | Bobina de descarga: 3 latigazos, 1 cada 5 s. |
| PX-09 | **CHISPA** | Pistola de arco eléctrico · Pistola | Clic derecho: arco instantáneo (5 de daño) que salta a 2 enemigos más (3 de daño cada uno). Los objetivos en el agua o bajo la lluvia reciben un 50 % más de daño. | Condensador: 12 descargas, 1 cada 0,75 s. |
| PX-10 | **REMACHE** | Escopeta de remaches magnéticos · Escopeta | Clic derecho: 8 remaches (3 de daño cada uno, la mitad a más de 6 bloques). Con 4+ impactos el enemigo queda clavado. Agachado + clic derecho: salto de retroceso en dirección contraria (2 cargas, sin daño por caída). | Tambor magnético: 6 disparos, 1 cada 2 s. |
| PX-11 | **TRITURADORA** | Lanzagranadas de racimo · Explosiva | Clic derecho: granada que rebota 2 veces y estalla (7 de daño, radio 3) soltando 4 bombetas. Agachado + clic derecho: detonación remota de todas tus granadas en vuelo. | Forja de granadas: 4 granadas, 1 cada 3 s. |
| PX-12 | **ROTOR** | Ametralladora rotativa de energía · Pesada · Automática | Mantén clic derecho: los cañones giran 0,75 s y disparan 20 trazadoras por segundo (2 de daño). El fuego continuo gana precisión; las trazadoras marcan al objetivo 2 s. | Cinta de energía: 200 disparos, se recarga 10 por segundo sin disparar. |
| PX-13 | **HALCÓN** | Dron de combate desplegable · Táctica · Dron | Clic derecho: despliega el dron (mín. 5 s de batería). Si ya vuela, marca como objetivo al enemigo que apuntas. Agachado + clic derecho: el dron vuelve a la mano y devuelve la batería que le quede. | Batería de vuelo: hasta 30 s; se recarga 1 s cada 2 s mientras el dron no vuela. |
| PX-14 | **TRUENO** | Designador de ataque orbital · Artillería · Especial | Mantén clic derecho 2 s apuntando a un punto (96 m): 2 s después cae la lanza orbital (20 de daño en radio 4). Agachado + clic derecho: bengala que revela 10 s a las criaturas en 24 bloques (recarga 20 s). | Enlace orbital: 1 ataque, se recupera en 30 s. |
| PX-15 | **SOPLETE** | Lanzallamas de plasma · Lanzallamas | Mantén clic derecho: chorro de plasma en cono de 7 bloques que quema todo lo que toca. Agachado + clic derecho: globo de napalm que arde 4 s en el suelo (30 de gel). | Tanque de gel: 100 unidades (5 s de chorro), se rellena en 5 s sin disparar. |
| PX-16 | **ESCARCHA** | Proyector criogénico · Táctica · Control | Mantén clic derecho: rayo de 18 bloques que ralentiza y congela; congelado del todo, el objetivo queda inmóvil 2 s. Agachado + clic derecho: nova de hielo de radio 4 que congela y empuja (40 unidades). | Criotanque: 100 unidades (5 s de rayo), se rellena en 5 s sin disparar. |
| PX-17 | **ECO** | Cañón sónico · Especial · Perforante | Mantén clic derecho 1 s y suelta: onda de 24 bloques que atraviesa paredes (10 de daño que ignora armadura). Los alcanzados quedan desorientados 4 s (Debilidad II y náuseas) y salen despedidos. | Resonador: 3 descargas, 1 cada 6 s. |
| PX-18 | **BASTIÓN** | Escudo de energía de asalto · Defensiva | Mantén clic derecho para cubrirte: bloquea el daño frontal y cada golpe bloqueado carga el acumulador. Agachado + clic derecho con 30+ de carga: pulso cinético en cono de 6 bloques (4 a 16 de daño y derribo). | Acumulador cinético: se carga al bloquear (hasta 100). |
| PX-19 | **COLIBRÍ** | Subfusil de agujas · Subfusil | Mantén clic derecho: ráfaga de agujas de cristal (1,5 de daño, ≈13 por segundo). Cada 5 agujas en el mismo objetivo aplican Veneno 3 s (se acumula). +10 % de velocidad al empuñarla. | Cargador de agujas: 60 agujas, se regenera 20 por segundo sin disparar. |
| PX-20 | **SIERRA** | Lanzadiscos de sierra · Lanzador · Rebote | Clic derecho: disco que atraviesa enemigos (6 de daño) y rebota hasta 3 veces en las paredes. Agachado + clic derecho: tus discos vuelven cortando lo que encuentran y te devuelven su carga. | Forja de discos: 3 discos, 1 cada 3 s. |

En el juego: pasa el ratón por encima del arma y mantén **Mayús** para ver los detalles.
Las armas automáticas (AVISPÓN, ROTOR, SOPLETE, ESCARCHA, COLIBRÍ) disparan mientras mantienes
el clic derecho y no te frenan al disparar.

**Sinergias:** AGUJA, ROTOR, HALCÓN y la bengala de TRUENO marcan objetivos (Resplandor) → COLMENA
los fija primero. VÓRTICE agrupa enemigos → TRITURADORA, TRUENO y la ruptura de MARTINETE los rematan.
ESCARCHA los deja inmóviles → AGUJA y ECO no fallan.

## Fabricación

Todas las armas necesitan un **Núcleo de xeranio**. Recetas de mesa de trabajo (3 × 3, `·` = hueco):

| Objeto | Patrón | Ingredientes |
|---|---|---|
| Núcleo de xeranio | `ARA` / `RDR` / `ARA` | A fragmento de amatista · R redstone · D diamante |
| MARTINETE | `BPB` / `·X·` / `·N·` | B bloque de hierro · P pistón · X núcleo · N lingote de netherita |
| AGUJA | `SLL` / `CXC` / `IN·` | S catalejo · L pararrayos · C lingote de cobre · X núcleo · I lingote de hierro · N lingote de netherita |
| AVISPÓN | `FBF` / `IXI` / `·IR` | F carga ígnea · B vara de blaze · I lingote de hierro · X núcleo · R bloque de redstone |
| COLMENA | `RRR` / `DXD` / `IOI` | R cohete de fuegos artificiales · D dispensador · X núcleo · I bloque de hierro · O observador |
| VÓRTICE | `PEP` / `CXC` / `OIO` | P perla de ender · E ojo de ender · C obsidiana llorosa · X núcleo · O obsidiana · I lingote de hierro |
| CIZALLA | `·N·` / `·N·` / `IXI` | N lingote de netherita · I lingote de hierro · X núcleo |
| TALADRO | `·D·` / `DPD` / `IXI` | D diamante · P pistón · I bloque de hierro · X núcleo |
| SERPENTINA | `··C` / `·C·` / `XL·` | C cadena · X núcleo · L pararrayos |
| CHISPA | `CLC` / `·XI` / `··I` | C lingote de cobre · L pararrayos · X núcleo · I lingote de hierro |
| REMACHE | `III` / `CXC` / `·IB` | I lingote de hierro · C bloque de cobre · X núcleo · B bloque de hierro |
| TRITURADORA | `ITI` / `TXT` / `ITI` | I bloque de hierro · T dinamita · X núcleo |
| ROTOR | `III` / `LXR` / `III` | I lingote de hierro · L pararrayos · R bloque de redstone · X núcleo |
| HALCÓN | `P·P` / `IXI` / `P·P` | P membrana de phantom · I lingote de hierro · X núcleo |
| TRUENO | `·S·` / `LXL` / `IRI` | S catalejo · L pararrayos · X núcleo · I lingote de hierro · R bloque de redstone |
| SOPLETE | `FFF` / `BXB` / `·I·` | F carga ígnea · B vara de blaze · X núcleo · I lingote de hierro |
| ESCARCHA | `BBB` / `IXI` / `·I·` | B hielo azul · I lingote de hierro · X núcleo |
| ECO | `NIN` / `IXI` / `N·N` | N bloque musical · I lingote de hierro · X núcleo |
| BASTIÓN | `OIO` / `IXI` / `OIO` | O obsidiana · I lingote de hierro · X núcleo |
| COLIBRÍ | `··A` / `IXA` / `·I·` | A fragmento de amatista · I lingote de hierro · X núcleo |
| SIERRA | `·S·` / `IXI` / `·I·` | S cortapiedras · I lingote de hierro · X núcleo |

También aparecen en la pestaña creativa **Proyecto X · Arsenal**.

## Compilar en GitHub (sin instalar nada)

1. Crea un repositorio nuevo en GitHub (puede ser privado).
2. Sube **todo el contenido de esta carpeta**, incluidas las carpetas ocultas `.github` y `gradle`:
   - Con Git: `git init && git add . && git commit -m "Proyecto X" && git branch -M main && git remote add origin <url> && git push -u origin main`
   - Desde la web: *Add file → Upload files* y arrastra los archivos y carpetas (comprueba que se suben `.github/workflows/build.yml` y `gradle/wrapper/gradle-wrapper.jar`).
3. Al subirlo se ejecuta solo el flujo **Compilar Proyecto X** (pestaña *Actions*). Si no arranca, entra en *Actions → Compilar Proyecto X → Run workflow*.
4. Cuando termine (la primera vez tarda unos minutos porque NeoForge prepara Minecraft), abre la ejecución y descarga el artefacto **proyectox-mod**: dentro está `proyectox-2.0.0.jar`.
5. Copia el `.jar` en la carpeta `mods` de una instalación de **NeoForge 21.1.x para Minecraft 1.21.1**.

## Compilar en tu ordenador

Necesitas **Java 21** (JDK). En la carpeta del proyecto:

```
./gradlew build          # Windows: gradlew.bat build
./gradlew runClient      # abre Minecraft con el mod para probarlo
```

El `.jar` queda en `build/libs/`.

## Estructura

```
src/main/java/com/proyectox/
  ProyectoX.java          clase principal (@Mod)
  item/                   las 20 armas (PXWeapon es la base con el sistema de energía)
  entity/                 proyectiles, granadas, discos, dron, singularidad, estelas
  client/                 renderizadores, poses de brazos, gatillo automático, zoom
  network/                paquete del gatillo automático
  registry/               objetos, entidades, sonidos, componentes, tipos de daño, pestaña
  util/                   puntería, efectos, reloj, protección de caída, tareas diferidas
src/main/resources/
  assets/proyectox/models/item/   modelos OBJ + MTL + JSON (cargador neoforge:obj)
  assets/proyectox/textures/      texturas 1024 px de las armas y de los efectos
  assets/proyectox/sounds.json    sonidos (compuestos a partir de sonidos de Minecraft)
  assets/proyectox/lang/          español (es_*) e inglés (en_us)
  data/proyectox/                 recetas y tipos de daño
```

Notas:
- Los sonidos están definidos en `sounds.json` reutilizando sonidos de Minecraft con otro tono;
  puedes sustituirlos por archivos `.ogg` propios sin tocar el código.
- Las texturas de las armas son de 1024 × 1024 px: el atlas de bloques crece bastante (≈ 8192 × 4096).
  Cualquier gráfica de los últimos años lo admite sin problemas.
- Versión de NeoForge, nombre, autor, licencia y versión del mod se cambian en `gradle.properties`.
